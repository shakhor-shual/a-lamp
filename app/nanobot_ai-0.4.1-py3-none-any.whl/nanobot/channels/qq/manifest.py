from nanobot.channels._manifest import field, required_fields
from nanobot.channels.contracts import ChannelSetupSpec
from nanobot.channels.plugin import ChannelPlugin

SETUP_SPEC = ChannelSetupSpec(
    fields={
        "appId": field(),
        "secret": field("secret"),
        "allowFrom": field("list"),
        "msgFormat": field("enum", choices={"plain", "markdown"}, default="plain"),
        "ackMessage": field(default="⏳ Processing..."),
        "showCompactionNotices": field("bool", inheritable=True),
        "mediaDir": field(),
        "downloadChunkSize": field("int", default=1024 * 256),
        "downloadMaxBytes": field("int", default=1024 * 1024 * 200),
    },
    required=required_fields("appId", "secret"),
    official_url="https://q.qq.com/",
)

PLUGIN = ChannelPlugin(
    name="qq",
    display_name="QQ",
    runtime=f"{__package__}.runtime:QQChannel",
    connector=f"{__package__}.connect:QQConnectStore",
    setup=SETUP_SPEC,
    dependencies=(
        "aiohttp>=3.9.0,<4.0.0",
        "qq-botpy>=1.2.0,<2.0.0",
    ),
    webui="webui/index.tsx",
)
