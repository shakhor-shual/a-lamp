from __future__ import annotations

import asyncio
import re
import time
import unicodedata
from contextlib import suppress
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from typing import Any, Awaitable, Callable, Literal, TypeAlias, TypeVar, cast
from urllib.parse import urlparse

from pydantic import Field, field_validator, model_validator
from telegram import (
    BotCommand,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    MessageEntity,
    ReactionTypeEmoji,
    ReplyParameters,
    Update,
    User,
)
from telegram.error import BadRequest, InvalidToken, NetworkError, RetryAfter, TimedOut
from telegram.ext import Application, CallbackQueryHandler, ContextTypes, MessageHandler, filters
from telegram.request import BaseRequest, HTTPXRequest

from nanobot.bus.delivery import ChannelNotReadyError, DeliveryRejectedError
from nanobot.bus.events import OutboundMessage
from nanobot.bus.outbound_events import ProgressEvent
from nanobot.bus.queue import MessageBus
from nanobot.channels.base import BaseChannel
from nanobot.command.application import build_help_text
from nanobot.config.network import NetworkConfig
from nanobot.config.paths import get_media_dir
from nanobot.config_base import Base
from nanobot.events import ContextCompactionEvent
from nanobot.security.network import validate_url_target
from nanobot.utils.helpers import split_message
from nanobot.utils.logging_bridge import redirect_lib_logging

TELEGRAM_MAX_MESSAGE_LEN = 4000  # Telegram message character limit
# Telegram's actual API limit is 4096; we split raw markdown at 4000 as a
# safety margin for mid-stream edits (plain text).  On stream end, we split
# raw markdown into chunks whose rendered HTML fits Telegram's true 4096-char
# boundary so the final rendered message never overflows.
TELEGRAM_HTML_MAX_LEN = 4096
# Bot API rich messages accept up to 32,768 UTF-8 characters. Raw Markdown is
# counted conservatively here; Python's str length counts Unicode code points,
# so multibyte text must not be split at an encoded-byte boundary.
TELEGRAM_RICH_MAX_LEN = 32768
TELEGRAM_REPLY_CONTEXT_MAX_LEN = TELEGRAM_MAX_MESSAGE_LEN
TELEGRAM_RICH_DRAFT_MIN_INTERVAL = 0.75  # 40 draft updates per 30 seconds per chat
# Bound for in-flight compaction notices in case a terminal phase never arrives.
COMPACTION_NOTICES_MAX = 64

# python-telegram-bot exposes a six-parameter Application generic. Nanobot
# doesn't customize its context/data/job-queue types, so keep that SDK boundary
# explicit rather than allowing unspecialized generics to spread Unknown.
TelegramApplication: TypeAlias = Application[Any, Any, Any, Any, Any, Any]
_T = TypeVar("_T")

# A healthy getUpdates long poll completes every ~10s even with no traffic;
# PTB retries timeouts silently, so stalls must be detected here.
POLL_STALE_SECONDS = 120.0
POLL_WATCH_INTERVAL = 1.0
RESTART_BACKOFF_INITIAL_SECONDS = 5.0
RESTART_BACKOFF_MAX_SECONDS = 300.0
APP_RESTART_SEND_WAIT_SECONDS = 2.0


class _LivenessTrackedRequest(BaseRequest):
    """Wrap the getUpdates request pool, reporting each completed round trip."""

    __slots__ = ("inner", "_on_round_trip")

    def __init__(self, inner: BaseRequest, on_round_trip: Callable[[], None]) -> None:
        super().__init__()
        self.inner = inner
        self._on_round_trip = on_round_trip

    @property
    def read_timeout(self) -> float | None:
        return self.inner.read_timeout

    async def initialize(self) -> None:
        await self.inner.initialize()

    async def shutdown(self) -> None:
        await self.inner.shutdown()

    async def do_request(self, *args: Any, **kwargs: Any) -> tuple[int, bytes]:
        result = await self.inner.do_request(*args, **kwargs)
        self._on_round_trip()
        return result


_FENCE_OPEN_RE = re.compile(r'^[ \t]*(`{3,}|~{3,})(.*)$')
_INLINE_FENCE_RE = re.compile(r'```(?:[^\n]*\n)?([\s\S]*?)```')


def _opening_code_fence(line: str) -> str | None:
    match = _FENCE_OPEN_RE.match(line)
    if match and not (match.group(1)[0] == '`' and '`' in match.group(2)):
        return match.group(1)
    return None


def _closes_code_fence(line: str, fence: str) -> bool:
    closing = line.strip()
    return len(closing) >= len(fence) and closing == fence[0] * len(closing)


def _split_telegram_markdown(content: str, max_len: int) -> list[str]:
    if not content:
        return []
    content = content.lstrip()
    if not content:
        return []
    if len(content) <= max_len:
        return [content]

    def fence_line(fence_pos: int) -> str:
        line_end = content.find("\n", fence_pos)
        if line_end < 0:
            return content[fence_pos:]
        return content[fence_pos:line_end]

    def split_inside_fenced_code_block(pos: int) -> tuple[int, str, str] | None:
        fence = None
        opening = -1
        inline = False
        offset = 0
        for line in content[:pos].split("\n"):
            if fence is not None and not inline:
                if _closes_code_fence(line, fence):
                    fence = None
            else:
                marker = _opening_code_fence(line) if fence is None else None
                if marker is not None:
                    fence = marker
                    opening = offset
                    inline = False
                else:
                    # Keep the legacy renderer's inline triple-backtick blocks.
                    for match in re.finditer("```", line):
                        if fence is None:
                            fence = "```"
                            opening = offset + match.start()
                            inline = True
                        else:
                            fence = None
                            inline = False
            offset += len(line) + 1
        return (opening, fence_line(opening), fence) if fence is not None else None

    chunks: list[str] = []
    while content:
        if len(content) <= max_len:
            chunks.append(content)
            break

        cut = content[:max_len]
        pos = cut.rfind("\n")
        if pos <= 0:
            pos = cut.rfind(" ")
        if pos <= 0:
            pos = max_len

        active_fence = split_inside_fenced_code_block(pos)
        if active_fence is not None:
            opening, fence, marker = active_fence
            if opening > 0:
                pos = opening
            else:
                closing = "\n" + marker
                min_code_pos = len(fence)
                if content.startswith(fence + "\n"):
                    min_code_pos += 1
                # When the only break in range is the opening fence newline,
                # cutting there re-emits the same fence and never advances.
                if pos < min_code_pos:
                    if min_code_pos + len(closing) >= max_len:
                        chunks.append(content[:max_len])
                        content = content[max_len:].lstrip()
                        continue
                    budget = max_len - len(closing)
                    recut = content[:budget]
                    adjusted = recut.rfind("\n", min_code_pos)
                    if adjusted < min_code_pos:
                        adjusted = recut.rfind(" ", min_code_pos)
                    pos = adjusted if adjusted > min_code_pos else budget
                elif pos + len(closing) > max_len:
                    budget = max_len - len(closing)
                    if budget <= min_code_pos:
                        chunks.append(content[:max_len])
                        content = content[max_len:].lstrip()
                        continue
                    recut = content[:budget]
                    adjusted = recut.rfind("\n", min_code_pos)
                    if adjusted < min_code_pos:
                        adjusted = recut.rfind(" ", min_code_pos)
                    pos = adjusted if adjusted > min_code_pos else budget
                if pos <= min_code_pos:
                    chunks.append(content[:max_len])
                    content = content[max_len:].lstrip()
                    continue
                chunks.append(content[:pos] + closing)
                remainder = content[pos:]
                if remainder.startswith("\n"):
                    remainder = remainder[1:]
                content = f"{fence}\n{remainder}"
                continue

        chunks.append(content[:pos])
        content = content[pos:].lstrip()
    return chunks


def _escape_telegram_html(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _tool_hint_to_telegram_blockquote(text: str) -> str:
    return f"<blockquote expandable>{_escape_telegram_html(text)}</blockquote>" if text else ""


def _strip_md(s: str) -> str:
    s = re.sub(r'\*\*(.+?)\*\*', r'\1', s)
    s = re.sub(r'__(.+?)__', r'\1', s)
    s = re.sub(r'~~(.+?)~~', r'\1', s)
    s = re.sub(r'`([^`]+)`', r'\1', s)
    return s.strip()


def _replace_fenced_code(text: str, replace: Callable[[str], str]) -> str:
    """Replace fenced code blocks with ``replace(code)``.

    A block opens on a ``` or ~~~ line and closes on a line holding only a run
    of the same character that is at least as long, so tilde fences work and a
    ```` fence can show a ``` example. What remains (one-line ```code``` and
    unclosed fences) keeps the previous regex handling.
    """
    lines = text.split('\n')
    out: list[str] = []
    i = 0
    while i < len(lines):
        fence = _opening_code_fence(lines[i])
        if fence is not None:
            for j in range(i + 1, len(lines)):
                if _closes_code_fence(lines[j], fence):
                    out.append(replace(''.join(line + '\n' for line in lines[i + 1:j])))
                    i = j + 1
                    break
            else:
                out.append(lines[i])
                i += 1
            continue
        out.append(lines[i])
        i += 1
    text = '\n'.join(out)
    return _INLINE_FENCE_RE.sub(lambda m: replace(m.group(1)), text)


def _strip_md_block(text: str) -> str:
    text = _replace_fenced_code(text, lambda code: code)
    text = re.sub(r'^#{1,6}\s+(.+)$', r'\1', text, flags=re.MULTILINE)
    text = re.sub(r'^>\s*(.*)$', r'\1', text, flags=re.MULTILINE)
    text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
    text = re.sub(r'__(.+?)__', r'\1', text)
    text = re.sub(r'(?<![a-zA-Z0-9])_([^_]+)_(?![a-zA-Z0-9])', r'\1', text)
    text = re.sub(r'~~(.+?)~~', r'\1', text)
    text = re.sub(r'`([^`]+)`', r'\1', text)
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
    text = re.sub(r'^[-*]\s+', '• ', text, flags=re.MULTILINE)
    text = re.sub(r'^(\d+)\.\s+', r'\1. ', text, flags=re.MULTILINE)
    return text


def _render_table_box(table_lines: list[str]) -> str:

    def dw(s: str) -> int:
        return sum(2 if unicodedata.east_asian_width(c) in ('W', 'F') else 1 for c in s)

    rows: list[list[str]] = []
    has_sep = False
    for line in table_lines:
        cells = [_strip_md(c) for c in line.strip().strip('|').split('|')]
        if all(re.match(r'^:?-+:?$', c) for c in cells if c):
            has_sep = True
            continue
        rows.append(cells)
    if not rows or not has_sep:
        return '\n'.join(table_lines)

    ncols = max(len(r) for r in rows)
    for r in rows:
        r.extend([''] * (ncols - len(r)))
    widths = [max(dw(r[c]) for r in rows) for c in range(ncols)]

    def dr(cells: list[str]) -> str:
        return '  '.join(f'{c}{" " * (w - dw(c))}' for c, w in zip(cells, widths))

    out = [dr(rows[0])]
    out.append('  '.join('─' * w for w in widths))
    for row in rows[1:]:
        out.append(dr(row))
    return '\n'.join(out)


def _markdown_to_telegram_html(text: str) -> str:
    if not text:
        return ""

    # 1. Extract and protect code blocks (preserve content from other processing)
    code_blocks: list[str] = []
    def save_code_block(code: str) -> str:
        code_blocks.append(code)
        return f"\x00CB{len(code_blocks) - 1}\x00"

    text = _replace_fenced_code(text, save_code_block)

    lines = text.split('\n')
    rebuilt: list[str] = []
    li = 0
    while li < len(lines):
        if re.match(r'^\s*\|.+\|', lines[li]):
            tbl: list[str] = []
            while li < len(lines) and re.match(r'^\s*\|.+\|', lines[li]):
                tbl.append(lines[li])
                li += 1
            box = _render_table_box(tbl)
            if box != '\n'.join(tbl):
                code_blocks.append(box)
                rebuilt.append(f"\x00CB{len(code_blocks) - 1}\x00")
            else:
                rebuilt.extend(tbl)
        else:
            rebuilt.append(lines[li])
            li += 1
    text = '\n'.join(rebuilt)

    inline_codes: list[str] = []
    def save_inline_code(m: re.Match[str]) -> str:
        inline_codes.append(m.group(1))
        return f"\x00IC{len(inline_codes) - 1}\x00"

    text = re.sub(r'`([^`]+)`', save_inline_code, text)

    text = re.sub(r'^#{1,6}\s+(.+)$', r'⟪B⟫\1⟪/B⟫', text, flags=re.MULTILINE)

    text = re.sub(r'^>\s*(.*)$', r'\1', text, flags=re.MULTILINE)

    text = _escape_telegram_html(text)

    # 6. Links [text](url) - must be before bold/italic to handle nested cases.
    # Park the URL in a placeholder so later inline-formatting passes cannot
    # rewrite it (e.g. ``__init__.py`` must not become ``<b>init</b>.py``).
    link_urls: list[str] = []
    def save_link(m: re.Match[str]) -> str:
        link_urls.append(m.group(2).replace('"', "&quot;"))
        return f'<a href="\x00LK{len(link_urls) - 1}\x00">{m.group(1)}</a>'

    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', save_link, text)

    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    text = re.sub(r'__(.+?)__', r'<b>\1</b>', text)

    # 8. Italic _text_ (avoid matching inside words like some_var_name)
    text = re.sub(r'(?<![a-zA-Z0-9])_([^_]+)_(?![a-zA-Z0-9])', r'<i>\1</i>', text)

    text = re.sub(r'~~(.+?)~~', r'<s>\1</s>', text)

    text = re.sub(r'^[-*]\s+', '• ', text, flags=re.MULTILINE)

    text = re.sub(r'^(\d+)\.\s+', r'\1. ', text, flags=re.MULTILINE)

    for i, url in enumerate(link_urls):
        text = text.replace(f"\x00LK{i}\x00", url)

    for i, code in enumerate(inline_codes):
        escaped = _escape_telegram_html(code)
        text = text.replace(f"\x00IC{i}\x00", f"<code>{escaped}</code>")

    for i, code in enumerate(code_blocks):
        escaped = _escape_telegram_html(code)
        text = text.replace(f"\x00CB{i}\x00", f"<pre><code>{escaped}</code></pre>")

    text = text.replace('⟪B⟫', '<b>').replace('⟪/B⟫', '</b>')

    return text


def _split_telegram_markdown_html_chunks(
    content: str, max_html_len: int,
) -> list[tuple[str, str]]:
    chunks: list[tuple[str, str]] = []
    pending = _split_telegram_markdown(content, TELEGRAM_MAX_MESSAGE_LEN)
    while pending:
        chunk = pending.pop(0)
        html = _markdown_to_telegram_html(chunk)
        if len(html) <= max_html_len:
            chunks.append((chunk, html))
            continue

        # Markdown can expand when rendered as HTML (tags/entities). Re-split
        # the raw markdown with a smaller budget instead of slicing HTML tags.
        next_limit = max(1, int(len(chunk) * max_html_len / len(html)) - 8)
        next_limit = min(next_limit, len(chunk) - 1)
        if next_limit <= 0:
            raise ValueError("A rendered Telegram HTML token exceeds the message limit")
        parts = _split_telegram_markdown(chunk, next_limit)
        if len(parts) == 1 and parts[0] == chunk:
            raise ValueError("Unable to split Telegram Markdown within the HTML limit")
        pending = parts + pending
    return chunks


def _split_telegram_markdown_html(content: str, max_html_len: int) -> list[str]:
    return [html for _, html in _split_telegram_markdown_html_chunks(content, max_html_len)]


_SEND_MAX_RETRIES = 3
_SEND_RETRY_BASE_DELAY = 0.5
_STREAM_EDIT_INTERVAL_DEFAULT = 0.6


@dataclass
class _StreamBuf:
    """Per-chat streaming accumulator for progressive message editing."""
    text: str = ""
    message_id: int | None = None
    draft_id: int | None = None
    last_edit: float = 0.0
    stream_id: str | None = None


@dataclass
class _QueuedTelegramUpdate:
    """Telegram update staged for per-session ordered processing."""

    kind: Literal["command", "message"]
    update: Update
    sort_key: tuple[int, int]


class TelegramConfig(Base):
    """Telegram channel configuration."""

    enabled: bool = False
    token: str = ""
    mode: Literal["polling", "webhook"] = "polling"
    allow_from: list[str] = Field(default_factory=list)
    use_proxy: bool = False
    reply_to_message: bool = False
    react_emoji: str = "👀"
    group_policy: Literal["open", "mention"] = "mention"
    connection_pool_size: int = 32
    pool_timeout: float = 5.0
    streaming: bool = True
    inline_keyboards: bool = False
    # Opt in to Bot API 10.1 sendRichMessage for richer markdown rendering.
    rich_messages: bool = False
    stream_edit_interval: float = Field(default=_STREAM_EDIT_INTERVAL_DEFAULT, ge=0.1)
    webhook_url: str = ""
    webhook_listen_host: str = "127.0.0.1"
    webhook_listen_port: int = Field(default=8081, ge=1, le=65535)
    webhook_path: str = "/telegram"
    webhook_secret_token: str = ""
    webhook_max_connections: int = Field(default=4, ge=1, le=100)

    @field_validator("webhook_path")
    @classmethod
    def webhook_path_must_start_with_slash(cls, value: str) -> str:
        value = value.strip() or "/telegram"
        if not value.startswith("/"):
            raise ValueError('webhook_path must start with "/"')
        return value

    @model_validator(mode="after")
    def validate_webhook_config(self) -> "TelegramConfig":
        if self.mode != "webhook":
            return self

        url = self.webhook_url.strip()
        if not url:
            raise ValueError("webhook_url is required when Telegram mode is webhook")
        parsed = urlparse(url)
        if parsed.scheme != "https" or not parsed.netloc:
            raise ValueError("webhook_url must be a public HTTPS URL")
        secret = self.webhook_secret_token.strip()
        if not secret:
            raise ValueError("webhook_secret_token is required when Telegram mode is webhook")
        if len(secret) > 256 or re.match(r"^[A-Za-z0-9_-]+$", secret) is None:
            raise ValueError(
                "webhook_secret_token must be 1-256 characters using only A-Z, a-z, 0-9, _ and -"
            )
        return self


_TELEGRAM_COMMAND_ALIASES = {
    "/dream_log": "/dream-log",
    "/dream_restore": "/dream-restore",
    "/dream_prompt": "/dream-prompt",
    "/evaluator_prompt": "/evaluator-prompt",
}
_TELEGRAM_DISPLAY_COMMAND_RE = re.compile(
    r"(?<![\w/.-])/(?:dream-log|dream-restore|dream-prompt|evaluator-prompt)(?![\w/.-])"
)


def _telegram_command_text(text: str) -> str:
    display_names = {value: key for key, value in _TELEGRAM_COMMAND_ALIASES.items()}
    lines: list[str] = []
    fence: str | None = None
    for line in text.splitlines(keepends=True):
        stripped = line.lstrip()
        if fence is not None:
            if stripped.startswith(fence):
                fence = None
        elif stripped.startswith(("```", "~~~")):
            fence = stripped[:3]
        else:
            line = _TELEGRAM_DISPLAY_COMMAND_RE.sub(lambda match: display_names[match[0]], line)
            # Inline code is not tappable as a Telegram command.
            line = re.sub(
                r"`(/(?:dream_log|dream_restore|dream_prompt|evaluator_prompt)(?: [^`\n]*)?)`",
                r"\1",
                line,
            )
        lines.append(line)
    return "".join(lines)


class TelegramChannel(BaseChannel):
    """
    Telegram channel using long polling or webhook mode.

    Long polling is the default. Webhook mode requires a public HTTPS URL and a
    Telegram secret token.
    """

    name = "telegram"
    display_name = "Telegram"
    uses_shared_proxy = True

    BOT_COMMANDS: list[BotCommand] = [
        BotCommand("start", "Start the bot"),
        BotCommand("new", "Start a new conversation"),
        BotCommand("compact", "Compact this chat's context"),
        BotCommand("stop", "Stop the current task"),
        BotCommand("restart", "Restart the bot"),
        BotCommand("status", "Show bot status"),
        BotCommand("history", "Show recent conversation messages"),
        BotCommand("goal", "Start a sustained objective (long-running task)"),
        BotCommand("trigger", "Create a named local trigger"),
        BotCommand("pairing", "Manage DM pairing (approve/deny/list)"),
        BotCommand("model", "Switch runtime model preset"),
        BotCommand("skill", "List enabled skills"),
        BotCommand("dream", "Run Dream memory consolidation now"),
        BotCommand("dream_log", "Show the latest Dream memory change"),
        BotCommand("dream_restore", "Restore Dream memory to an earlier version"),
        BotCommand("dream_prompt", "Tell Dream how to organize memory"),
        BotCommand("evaluator_prompt", "Customize the heartbeat evaluator prompt"),
        BotCommand("help", "Show available commands"),
    ]

    # Regex for slash commands routed to AgentLoop via ``_forward_command``.
    # Telegram-safe aliases are normalized before reaching the core router.
    # Canonical hyphenated commands stay on a separate handler (below).
    TELEGRAM_BUS_SLASH_COMMAND_RE = re.compile(
        r"^/(?:new|compact|stop|restart|status|dream|history|goal|trigger|pairing|model|skill"
        r"|dream_log|dream_restore|dream_prompt|evaluator_prompt|evaluator-prompt)(?:@\w+)?(?:\s+[\s\S]*)?$"
    )

    @classmethod
    def default_config(cls) -> dict[str, Any]:
        return TelegramConfig().model_dump(by_alias=True)

    def __init__(
        self, config: Any, bus: MessageBus, *, network: NetworkConfig | None = None,
    ):
        if isinstance(config, dict):
            config = TelegramConfig.model_validate(config)
        super().__init__(config, bus, network=network)
        self.config: TelegramConfig = config
        self._proxy = self.network.resolve_proxy(self.config.use_proxy)
        self._app: TelegramApplication | None = None
        self._typing_tasks: dict[str, asyncio.Task[None]] = {}
        self._media_group_buffers: dict[str, dict[str, Any]] = {}
        self._media_group_tasks: dict[str, asyncio.Task[None]] = {}
        self._message_threads: dict[tuple[str, int], int] = {}
        self._bot_user_id: int | None = None
        self._bot_username: str | None = None
        self._stream_bufs: dict[str, _StreamBuf] = {}
        self._compaction_notices: dict[tuple[str, str], int] = {}
        self._inbound_buffers: dict[str, list[_QueuedTelegramUpdate]] = {}
        self._inbound_workers: dict[str, asyncio.Task[None]] = {}
        self._rich_send_disabled: bool = False  # Latch off if Bot API < 10.1
        self._last_poll_ok: float = 0.0  # monotonic time of last getUpdates round trip
        self._app_ready = asyncio.Event()  # cleared while the app is being rebuilt
        self._teardown_lock = asyncio.Lock()

    def _require_app(self) -> TelegramApplication:
        if self._app is None:
            raise RuntimeError("Telegram application is not started")
        return self._app

    def is_allowed(self, sender_id: str) -> bool:
        """Preserve Telegram's legacy id|username allowlist matching."""
        if super().is_allowed(sender_id):
            return True

        allow_list = getattr(self.config, "allow_from", [])
        if not allow_list or "*" in allow_list:
            return False

        sender_str = str(sender_id)
        if sender_str.count("|") != 1:
            return False

        sid, username = sender_str.split("|", 1)
        if not sid.isdigit() or not username:
            return False

        return sid in allow_list or username in allow_list

    @staticmethod
    def _normalize_telegram_command(content: str) -> str:
        """Map Telegram-safe command aliases back to canonical nanobot commands."""
        if not content.startswith("/"):
            return content
        command = content.split(maxsplit=1)[0]
        canonical = _TELEGRAM_COMMAND_ALIASES.get(command, command)
        return canonical + content[len(command):]

    async def start(self) -> None:
        """Start the Telegram bot, rebuilding the app whenever polling stalls."""
        if not self.config.token:
            self.logger.error("bot token not configured")
            return

        redirect_lib_logging("telegram")
        redirect_lib_logging("httpx", level="WARNING")

        self._running = True
        backoff = RESTART_BACKOFF_INITIAL_SECONDS
        while self._running:
            try:
                await self._start_app()
            except InvalidToken:
                # A config error, not a blip: fail the channel. The scrubbed
                # re-raise keeps PTB's token-bearing message out of the log.
                await self._teardown_app()
                self._running = False
                self.logger.error("bot token rejected by Telegram")
                raise RuntimeError("Telegram bot token was rejected by the server") from None
            except Exception as e:
                await self._teardown_app()
                if not self._running:
                    break
                if not self._is_transient_startup_error(e):
                    # Never heals on its own: fail instead of retrying forever
                    # while ChannelManager keeps reporting the channel running.
                    self._running = False
                    self.logger.error("startup failed: {}", self._format_telegram_error(e))
                    raise
                self.logger.error(
                    "startup failed: {}; retrying in {:.0f}s",
                    self._format_telegram_error(e),
                    backoff,
                )
                await self._idle(backoff)
                backoff = min(backoff * 2, RESTART_BACKOFF_MAX_SECONDS)
                continue

            backoff = RESTART_BACKOFF_INITIAL_SECONDS
            if not self._running:
                # stop() ran while _start_app() was mid-flight and tore down the
                # previous (possibly None) app; this one would leak otherwise.
                await self._teardown_app()
                break
            stalled = await self._watch_polling()
            if not stalled or not self._running:
                break
            self.logger.warning(
                "polling stalled: no getUpdates round trip for {:.0f}s; "
                "rebuilding connection pools and restarting",
                time.monotonic() - self._last_poll_ok,
            )
            await self._teardown_app()

    async def _start_app(self) -> None:
        proxy = self._proxy

        # Separate pools so long-polling (getUpdates) never starves outbound sends.
        api_request = HTTPXRequest(
            connection_pool_size=self.config.connection_pool_size,
            pool_timeout=self.config.pool_timeout,
            connect_timeout=30.0,
            read_timeout=30.0,
            proxy=proxy,
        )
        poll_request = HTTPXRequest(
            connection_pool_size=4,
            pool_timeout=self.config.pool_timeout,
            connect_timeout=30.0,
            read_timeout=30.0,
            proxy=proxy,
        )
        builder = (
            Application.builder()
            .token(self.config.token)
            .request(api_request)
            .get_updates_request(_LivenessTrackedRequest(poll_request, self._note_poll_ok))
        )
        self._app = builder.build()
        self._app.add_error_handler(self._on_error)

        # Add command handlers (using Regex to support @username suffixes before bot initialization)
        self._app.add_handler(MessageHandler(filters.Regex(r"^/start(?:@\w+)?$"), self._on_start))
        self._app.add_handler(
            MessageHandler(
                filters.Regex(TelegramChannel.TELEGRAM_BUS_SLASH_COMMAND_RE),
                self._forward_command,
            )
        )
        self._app.add_handler(
            MessageHandler(
                filters.Regex(
                    r"^/(?:dream-log|dream-restore|dream-prompt)(?:@\w+)?(?:\s+[\s\S]*)?$"
                ),
                self._forward_command,
            )
        )
        self._app.add_handler(MessageHandler(filters.Regex(r"^/help(?:@\w+)?$"), self._on_help))

        self._app.add_handler(
            MessageHandler(
                (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.VIDEO_NOTE
                 | filters.ANIMATION | filters.VOICE | filters.AUDIO
                 | filters.Document.ALL | filters.LOCATION)
                & ~filters.COMMAND,
                self._on_message
            )
        )

        if self.config.inline_keyboards:
            self._app.add_handler(CallbackQueryHandler(self._on_callback_query))
            allowed_updates = ["message", "callback_query"]
            self.logger.debug("inline keyboards enabled")
        else:
            allowed_updates = ["message"]

        if self.config.mode == "webhook":
            self.logger.info("Starting bot (webhook mode)...")
        else:
            self.logger.info("Starting bot (polling mode)...")

        await self._app.initialize()
        await self._app.start()

        bot_info = await self._app.bot.get_me()
        self._bot_user_id = getattr(bot_info, "id", None)
        self._bot_username = getattr(bot_info, "username", None)
        self.logger.info("bot @{} connected", bot_info.username)

        try:
            await self._app.bot.set_my_commands(self.BOT_COMMANDS)
            self.logger.debug("bot commands registered")
        except Exception as e:
            self.logger.warning("Failed to register bot commands: {}", e)

        if self.config.mode == "webhook":
            # ``url_path`` is the local HTTP route. ``webhook_url`` is the
            # public HTTPS URL Telegram calls; reverse proxies may rewrite it.
            await cast(Any, self._app.updater).start_webhook(
                listen=self.config.webhook_listen_host,
                port=self.config.webhook_listen_port,
                url_path=self.config.webhook_path.lstrip("/"),
                webhook_url=self.config.webhook_url.strip(),
                allowed_updates=allowed_updates,
                drop_pending_updates=False,
                secret_token=self.config.webhook_secret_token.strip(),
                max_connections=self.config.webhook_max_connections,
            )
        else:
            self._last_poll_ok = time.monotonic()
            await cast(Any, self._app.updater).start_polling(
                allowed_updates=allowed_updates,
                drop_pending_updates=False,
                error_callback=self._on_polling_error,
            )

        self._app_ready.set()

    @staticmethod
    def _is_transient_startup_error(exc: Exception) -> bool:
        """Report whether a startup failure is worth retrying.

        HTTPXRequest wraps every httpx failure into NetworkError/TimedOut, so
        anything else is terminal: a bad proxy raises ValueError, an already
        bound webhook port raises OSError.
        """
        return isinstance(exc, NetworkError | TimedOut | asyncio.TimeoutError)

    async def _wait_for_app(self) -> TelegramApplication | None:
        """Return the live app, briefly waiting out an in-flight rebuild.

        Returning quietly while ``start()`` rebuilds would let the manager count
        the message as delivered, so raise once the wait runs out. None means the
        channel is stopped: nothing left to deliver.
        """
        if self._app_ready.is_set() and self._app is not None:
            return self._app
        if not self._running:
            return None
        with suppress(asyncio.TimeoutError):
            await asyncio.wait_for(self._app_ready.wait(), APP_RESTART_SEND_WAIT_SECONDS)
        if not self._app_ready.is_set() or self._app is None:
            raise ChannelNotReadyError("Telegram application is restarting; message not delivered")
        return self._app

    def _note_poll_ok(self) -> None:
        # HTTP error statuses count too: the watchdog detects transport stalls,
        # not logical failures.
        self._last_poll_ok = time.monotonic()

    async def _watch_polling(self) -> bool:
        watch = self.config.mode != "webhook"
        while self._running:
            await asyncio.sleep(POLL_WATCH_INTERVAL)
            if watch and time.monotonic() - self._last_poll_ok > POLL_STALE_SECONDS:
                return True
        return False

    async def _idle(self, seconds: float) -> None:
        deadline = time.monotonic() + seconds
        while self._running and time.monotonic() < deadline:
            await asyncio.sleep(POLL_WATCH_INTERVAL)

    async def _teardown_app(self) -> None:
        async with self._teardown_lock:
            app, self._app = self._app, None
            self._app_ready.clear()
            if not app:
                return
            for step in (cast(Any, app.updater).stop, app.stop, app.shutdown):
                try:
                    await step()
                except Exception as e:
                    self.logger.debug("teardown step failed: {}", e)
            # Application.shutdown() skips the HTTPX pools unless initialize()
            # finished, so a failed startup leaks one per retry. This is idempotent.
            try:
                await app.bot.shutdown()
            except Exception as e:
                self.logger.debug("bot shutdown failed: {}", e)

    async def stop(self) -> None:
        """Stop the Telegram bot."""
        self._running = False

        for chat_id in list(self._typing_tasks):
            self._stop_typing(chat_id)

        for task in self._media_group_tasks.values():
            task.cancel()
        self._media_group_tasks.clear()
        self._media_group_buffers.clear()

        for task in self._inbound_workers.values():
            task.cancel()
        self._inbound_workers.clear()
        self._inbound_buffers.clear()

        if self._app:
            self.logger.info("Stopping bot...")
        # Join an in-flight supervisor teardown before ChannelManager cancels
        # start(), otherwise cancellation can strand the old HTTPX pools.
        await self._teardown_app()

    @staticmethod
    def _get_media_type(path: str) -> str:
        """Guess media type from file extension."""
        filename = urlparse(path).path if path.startswith(("http://", "https://")) else path
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext in ("jpg", "jpeg", "png", "gif", "webp"):
            return "photo"
        if ext in ("mp4", "mov", "avi", "mkv", "webm", "3gp"):
            return "video"
        if ext == "ogg":
            return "voice"
        if ext in ("mp3", "m4a", "wav", "aac"):
            return "audio"
        return "document"

    @staticmethod
    def _is_remote_media_url(path: str) -> bool:
        return path.startswith(("http://", "https://"))

    @staticmethod
    def _is_rich_capability_error(exc: Exception) -> bool:
        """True when the Bot API does not support rich-message endpoints."""
        err = str(exc).lower()
        return (
            "method not found" in err
            or "unknown method" in err
            or ("endpoint" in err and "not found" in err)
            or "bad request: invalid parameter" in err
            or "unsupported" in err
            or "not implemented" in err
        )

    def _rich_streaming_enabled(self) -> bool:
        return self.config.rich_messages and not self._rich_send_disabled

    @staticmethod
    def _rich_message_payload(content: str) -> dict[str, str]:
        return {"markdown": content}

    def _mark_rich_unavailable(self, exc: Exception, operation: str) -> bool:
        if not self._is_rich_capability_error(exc):
            return False
        self._rich_send_disabled = True
        self.logger.debug("{} unavailable, disabling rich messages: {}", operation, exc)
        return True

    async def _try_send_rich(
        self,
        chat_id: int,
        content: str,
        reply_params: ReplyParameters | dict[str, int | bool] | None = None,
        thread_kwargs: dict[str, int] | None = None,
        reply_markup: InlineKeyboardMarkup | None = None,
    ) -> bool:
        if not self._app:
            return False

        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "rich_message": self._rich_message_payload(content),
        }
        if reply_params is not None:
            # sendRichMessage uses reply_parameters (object), not reply_to_message_id.
            if hasattr(reply_params, "message_id"):
                payload["reply_parameters"] = {
                    "message_id": cast(ReplyParameters, reply_params).message_id,
                    "allow_sending_without_reply": True,
                }
            else:
                payload["reply_parameters"] = reply_params
        if thread_kwargs:
            payload.update({
                k: v
                for k, v in thread_kwargs.items()
                if v is not None  # pyright: ignore[reportUnnecessaryComparison]
            })
        if reply_markup is not None:
            payload["reply_markup"] = reply_markup

        try:
            await self._call_with_retry(
                self._app.bot.do_api_request,
                "sendRichMessage",
                api_kwargs=payload,
            )
            return True
        except BadRequest as exc:
            if not self._mark_rich_unavailable(exc, "sendRichMessage"):
                self.logger.debug("sendRichMessage rejected: {}", exc)
            return False
        except Exception as exc:
            if self._mark_rich_unavailable(exc, "sendRichMessage"):
                return False
            err_str = str(exc).lower()
            is_timeout = "timed out" in err_str or isinstance(exc, TimedOut)
            if is_timeout:
                self.logger.debug("sendRichMessage timeout, falling back to legacy path")
                return False
            self.logger.debug("sendRichMessage failed: {}", exc)
            return False

    @staticmethod
    def _new_rich_draft_id() -> int:
        """Return a non-zero Bot API Integer suitable for one live draft."""
        return time.time_ns() % 2_147_483_647 or 1

    async def _try_send_rich_draft(
        self,
        chat_id: int,
        draft_id: int,
        content: str,
        thread_kwargs: dict[str, int],
    ) -> bool:
        app = self._require_app()
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "draft_id": draft_id,
            "rich_message": self._rich_message_payload(content),
            **thread_kwargs,
        }
        try:
            await self._call_with_retry(
                app.bot.do_api_request,
                "sendRichMessageDraft",
                api_kwargs=payload,
            )
            return True
        except BadRequest as exc:
            if not self._mark_rich_unavailable(exc, "sendRichMessageDraft"):
                self.logger.debug("Rich draft rejected: {}", exc)
            return False
        except Exception as exc:
            if self._mark_rich_unavailable(exc, "sendRichMessageDraft"):
                return False
            raise

    async def _try_send_stream_rich(
        self,
        chat_id: int,
        content: str,
        thread_kwargs: dict[str, int],
    ) -> bool:
        """Persist one completed rich stream chunk.

        ``False`` means Telegram rejected rich formatting before delivery and the
        caller may use the legacy path. A timeout is treated as an ambiguous
        success: retrying this non-idempotent method could duplicate a message
        that Telegram already stored.
        """
        app = self._require_app()
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "rich_message": self._rich_message_payload(content),
            **thread_kwargs,
        }
        try:
            await app.bot.do_api_request(
                "sendRichMessage",
                api_kwargs=payload,
            )
        except BadRequest as exc:
            if not self._mark_rich_unavailable(exc, "sendRichMessage"):
                self.logger.debug("Stream rich send rejected: {}", exc)
            return False
        except TimedOut as exc:
            self.logger.warning(
                "Stream rich send timed out; delivery is ambiguous, not retrying: {}", exc
            )
            return True
        except Exception as exc:
            if self._mark_rich_unavailable(exc, "sendRichMessage"):
                return False
            raise
        return True

    async def _start_legacy_stream(
        self,
        chat_id: int,
        buf: "_StreamBuf",
        thread_kwargs: dict[str, int],
    ) -> None:
        app = self._require_app()
        chunks = _split_telegram_markdown_html_chunks(buf.text, TELEGRAM_HTML_MAX_LEN)
        for index, (markdown, _) in enumerate(chunks[:-1]):
            await self._send_text(chat_id, markdown, thread_kwargs=thread_kwargs)
            buf.text = "\n".join(markdown for markdown, _ in chunks[index + 1:])
        tail = chunks[-1][0]
        sent = await self._call_with_retry(
            app.bot.send_message,
            chat_id=chat_id,
            text=_strip_md_block(tail),
            **thread_kwargs,
        )
        buf.text = tail
        buf.message_id = sent.message_id
        buf.draft_id = None

    def should_retry_send_error(self, error: Exception) -> bool:
        # Per-part API retries belong to this adapter. Whole-message replay is safe
        # only before submission; otherwise it may duplicate a successful prefix.
        return isinstance(error, ChannelNotReadyError)

    async def send(self, msg: OutboundMessage) -> None:
        """Send a message through Telegram."""
        if isinstance(msg.event, ContextCompactionEvent) and not (
            msg.event.notify or self.show_compaction_notices
        ):
            return
        app = await self._wait_for_app()
        if app is None:
            raise ChannelNotReadyError("Telegram bot not running")

        progress_event = msg.event if isinstance(msg.event, ProgressEvent) else None

        if progress_event is None:
            self._stop_typing(msg.chat_id)
            if reply_to_message_id := msg.metadata.get("message_id"):
                with suppress(ValueError):
                    await self._remove_reaction(msg.chat_id, int(reply_to_message_id))

        try:
            chat_id = int(msg.chat_id)
        except ValueError:
            raise DeliveryRejectedError("Invalid Telegram chat_id") from None
        reply_to_message_id = msg.metadata.get("message_id")
        message_thread_id = msg.metadata.get("message_thread_id")
        if message_thread_id is None and reply_to_message_id is not None:
            message_thread_id = self._message_threads.get((msg.chat_id, reply_to_message_id))
        thread_kwargs: dict[str, int] = {}
        if message_thread_id is not None:
            thread_kwargs["message_thread_id"] = message_thread_id

        reply_params = None
        if self.config.reply_to_message:
            if reply_to_message_id:
                reply_params = ReplyParameters(
                    message_id=reply_to_message_id,
                    allow_sending_without_reply=True
                )

        # Compaction notices collapse into one message: the started phase sends
        # it, a terminal phase edits it in place instead of posting a new one.
        if isinstance(msg.event, ContextCompactionEvent):
            await self._send_compaction_notice(
                chat_id, msg, msg.event, reply_params, thread_kwargs,
            )
            return

        for media_path in (msg.media or []):
            try:
                media_type = self._get_media_type(media_path)
                sender = {
                    "photo": app.bot.send_photo,
                    "video": app.bot.send_video,
                    "voice": app.bot.send_voice,
                    "audio": app.bot.send_audio,
                }.get(media_type, app.bot.send_document)
                param = {
                    "photo": "photo",
                    "video": "video",
                    "voice": "voice",
                    "audio": "audio",
                }.get(media_type, "document")
                extra: dict[str, Any] = {}
                if media_type == "video":
                    extra["supports_streaming"] = True

                # Telegram Bot API accepts HTTP(S) URLs directly for media params.
                if self._is_remote_media_url(media_path):
                    ok, error = validate_url_target(media_path)
                    if not ok:
                        raise ValueError(f"unsafe media URL: {error}")
                    await self._call_with_retry(
                        sender,
                        chat_id=chat_id,
                        **{param: media_path},
                        reply_parameters=reply_params,
                        **thread_kwargs,
                        **extra,
                    )
                    continue

                media_bytes = Path(media_path).read_bytes()
                filename = Path(media_path).name
                send_kwargs = {param: media_bytes, "filename": filename}
                await self._call_with_retry(
                    sender,
                    chat_id=chat_id,
                    reply_parameters=reply_params,
                    **thread_kwargs,
                    **extra,
                    **send_kwargs,
                )
            except Exception:
                filename = media_path.rsplit("/", 1)[-1]
                self.logger.exception("Failed to send media {}", media_path)
                await app.bot.send_message(
                    chat_id=chat_id,
                    text=f"[Failed to send: {filename}]",
                    reply_parameters=reply_params,
                    **thread_kwargs,
                )

        if msg.content and msg.content != "[empty message]":
            render_as_blockquote = bool(progress_event and progress_event.tool_hint)
            buttons = cast(list[list[str]], getattr(msg, "buttons", None) or [])
            reply_markup = self._build_keyboard(buttons) if buttons else None
            text = msg.content
            if msg.metadata.get("render_as") == "text":
                text = _telegram_command_text(text)
            # Fallback: no native keyboard → splice labels into the message so the choices survive.
            if buttons and reply_markup is None:
                text = f"{text}\n\n{self._buttons_as_text(buttons)}"

            # Bot API 10.1 rich fast-path: send raw markdown via sendRichMessage.
            # All non-blockquote content tries rich first; _rich_send_disabled
            # latches off permanently if the server doesn't support it.
            if (
                not render_as_blockquote
                and self.config.rich_messages
                and not getattr(self, "_rich_send_disabled", False)
            ):
                rich_ok = await self._try_send_rich(
                    chat_id, text, reply_params, thread_kwargs, reply_markup,
                )
                if rich_ok:
                    return

            chunks = _split_telegram_markdown(text, TELEGRAM_MAX_MESSAGE_LEN)
            for i, chunk in enumerate(chunks):
                is_last = (i == len(chunks) - 1)
                await self._send_text(
                    chat_id, chunk, reply_params, thread_kwargs,
                    render_as_blockquote=render_as_blockquote,
                    reply_markup=reply_markup if is_last else None,
                )

    async def _call_with_retry(
        self,
        fn: Callable[..., Awaitable[_T]],
        *args: Any,
        **kwargs: Any,
    ) -> _T:
        for attempt in range(1, _SEND_MAX_RETRIES + 1):
            try:
                return await fn(*args, **kwargs)
            except TimedOut:
                if attempt == _SEND_MAX_RETRIES:
                    raise
                delay = _SEND_RETRY_BASE_DELAY * (2 ** (attempt - 1))
                self.logger.warning(
                    "timeout (attempt {}/{}), retrying in {:.1f}s",
                    attempt, _SEND_MAX_RETRIES, delay,
                )
                await asyncio.sleep(delay)
            except RetryAfter as e:
                if attempt == _SEND_MAX_RETRIES:
                    raise
                retry_after = e.retry_after
                delay = (
                    retry_after.total_seconds()
                    if isinstance(retry_after, timedelta)
                    else float(retry_after)
                )
                self.logger.warning(
                    "Flood Control (attempt {}/{}), retrying in {:.1f}s",
                    attempt, _SEND_MAX_RETRIES, delay,
                )
                await asyncio.sleep(delay)
        raise RuntimeError("Telegram retry loop exited unexpectedly")

    async def _send_text(
        self,
        chat_id: int,
        text: str,
        reply_params: ReplyParameters | None = None,
        thread_kwargs: dict[str, int] | None = None,
        render_as_blockquote: bool = False,
        reply_markup: InlineKeyboardMarkup | None = None,
    ) -> None:
        app = self._require_app()
        try:
            html = _tool_hint_to_telegram_blockquote(text) if render_as_blockquote else _markdown_to_telegram_html(text)
            await self._call_with_retry(
                app.bot.send_message,
                chat_id=chat_id, text=html, parse_mode="HTML",
                reply_parameters=reply_params,
                reply_markup=reply_markup,
                **(thread_kwargs or {}),
            )
        except BadRequest as e:
            self.logger.warning("HTML parse failed, falling back to plain text: {}", e)
            try:
                await self._call_with_retry(
                    app.bot.send_message,
                    chat_id=chat_id,
                    text=text,
                    reply_parameters=reply_params,
                    reply_markup=reply_markup,
                    **(thread_kwargs or {}),
                )
            except Exception:
                self.logger.exception("Error sending message")
                raise

    @staticmethod
    def _is_not_modified_error(exc: Exception) -> bool:
        return isinstance(exc, BadRequest) and "message is not modified" in str(exc).lower()

    async def _send_compaction_notice(
        self,
        chat_id: int,
        msg: OutboundMessage,
        event: ContextCompactionEvent,
        reply_params: ReplyParameters | None,
        thread_kwargs: dict[str, int],
    ) -> None:
        app = self._require_app()
        key = (msg.chat_id, event.compaction_id)
        if event.phase == "started":
            sent = await self._call_with_retry(
                app.bot.send_message,
                chat_id=chat_id,
                text=msg.content,
                reply_parameters=reply_params,
                **thread_kwargs,
            )
            while len(self._compaction_notices) >= COMPACTION_NOTICES_MAX:
                self._compaction_notices.pop(next(iter(self._compaction_notices)))
            self._compaction_notices[key] = sent.message_id
            return

        message_id = self._compaction_notices.pop(key, None)
        if message_id is None or not msg.content:
            await self._send_text(chat_id, msg.content, thread_kwargs=thread_kwargs)
            return
        try:
            await self._call_with_retry(
                app.bot.edit_message_text,
                chat_id=chat_id,
                message_id=message_id,
                text=msg.content,
            )
        except Exception as exc:
            if self._is_not_modified_error(exc):
                return
            self.logger.warning("Compaction notice edit failed, sending anew: {}", exc)
            await self._send_text(chat_id, msg.content, thread_kwargs=thread_kwargs)

    async def send_delta(
        self,
        chat_id: str,
        delta: str,
        metadata: dict[str, Any] | None = None,
        *,
        stream_id: str | None = None,
        stream_end: bool = False,
        resuming: bool = False,
        merge_next: bool = False,
    ) -> None:
        """Stream a rich draft in private chats, then persist the final message."""
        app = await self._wait_for_app()
        if app is None:
            return
        meta = metadata or {}
        int_chat_id = int(chat_id)

        if stream_end and merge_next:
            if not delta:
                return
            stream_end = False
        if stream_end:
            buf = self._stream_bufs.get(chat_id)
            if not buf or not buf.text or (buf.message_id is None and buf.draft_id is None):
                return
            if stream_id is not None and buf.stream_id is not None and buf.stream_id != stream_id:
                return
            self._stop_typing(chat_id)
            if reply_to_message_id := meta.get("message_id"):
                with suppress(ValueError):
                    await self._remove_reaction(chat_id, int(reply_to_message_id))
            thread_kwargs: dict[str, int] = {}
            if message_thread_id := meta.get("message_thread_id"):
                thread_kwargs["message_thread_id"] = message_thread_id
            raw_text = buf.text

            if buf.draft_id is not None:
                rich_chunks = _split_telegram_markdown(raw_text, TELEGRAM_RICH_MAX_LEN)
                for index, rich_chunk in enumerate(rich_chunks):
                    if self._rich_streaming_enabled() and await self._try_send_stream_rich(
                        int_chat_id, rich_chunk, thread_kwargs,
                    ):
                        buf.text = "\n".join(rich_chunks[index + 1:])
                        continue
                    legacy_chunks = [
                        chunk
                        for remaining in rich_chunks[index:]
                        for chunk in _split_telegram_markdown(remaining, TELEGRAM_MAX_MESSAGE_LEN)
                    ]
                    for legacy_index, legacy_chunk in enumerate(legacy_chunks):
                        await self._send_text(
                            int_chat_id, legacy_chunk, thread_kwargs=thread_kwargs,
                        )
                        buf.text = "\n".join(legacy_chunks[legacy_index + 1:])
                    break
                self._stream_bufs.pop(chat_id, None)
                return

            # Group chats and streams that rejected drafts keep the established
            # HTML/plain finalization path. Native rich drafts are private-only.
            html_chunks = _split_telegram_markdown_html(raw_text, TELEGRAM_HTML_MAX_LEN)
            primary_html = html_chunks[0]
            extra_html_chunks = html_chunks[1:]
            try:
                await self._call_with_retry(
                    app.bot.edit_message_text,
                    chat_id=int_chat_id, message_id=buf.message_id,
                    text=primary_html, parse_mode="HTML",
                )
            except BadRequest as e:
                if self._is_not_modified_error(e):
                    self.logger.debug("Final stream edit already applied for {}", chat_id)
                    self._stream_bufs.pop(chat_id, None)
                    return
                self.logger.debug("Final stream edit failed (HTML), trying plain: {}", e)
                primary_plain = (
                    split_message(raw_text, TELEGRAM_MAX_MESSAGE_LEN)[0]
                    if len(raw_text) > TELEGRAM_MAX_MESSAGE_LEN
                    else raw_text
                )
                try:
                    await self._call_with_retry(
                        app.bot.edit_message_text,
                        chat_id=int_chat_id, message_id=buf.message_id,
                        text=primary_plain,
                    )
                except Exception as e2:
                    if self._is_not_modified_error(e2):
                        self.logger.debug("Final stream plain edit already applied for {}", chat_id)
                    else:
                        self.logger.warning("Final stream edit failed: {}", e2)
                        raise
            for extra_html_chunk in extra_html_chunks:
                try:
                    await self._call_with_retry(
                        app.bot.send_message,
                        chat_id=int_chat_id, text=extra_html_chunk,
                        parse_mode="HTML",
                        **thread_kwargs,
                    )
                except Exception:
                    await self._send_text(
                        int_chat_id,
                        extra_html_chunk,
                        thread_kwargs=thread_kwargs,
                    )
            self._stream_bufs.pop(chat_id, None)
            return

        buf = self._stream_bufs.get(chat_id)
        if buf is None or (
            stream_id is not None
            and buf.stream_id is not None
            and buf.stream_id != stream_id
        ):
            buf = _StreamBuf(stream_id=stream_id)
            self._stream_bufs[chat_id] = buf
        elif buf.stream_id is None:
            buf.stream_id = stream_id
        buf.text += delta

        if not buf.text.strip():
            return

        now = time.monotonic()
        stream_thread_kwargs: dict[str, int] = {}
        if message_thread_id := meta.get("message_thread_id"):
            stream_thread_kwargs["message_thread_id"] = message_thread_id
        rich_draft_allowed = (
            self._rich_streaming_enabled() and meta.get("is_group") is False
        )
        if buf.message_id is None and buf.draft_id is None:
            try:
                if rich_draft_allowed and len(buf.text) <= TELEGRAM_RICH_MAX_LEN:
                    buf.draft_id = self._new_rich_draft_id()
                    if not await self._try_send_rich_draft(
                        int_chat_id,
                        buf.draft_id,
                        buf.text,
                        stream_thread_kwargs,
                    ):
                        buf.draft_id = None
                if buf.draft_id is None:
                    await self._start_legacy_stream(
                        int_chat_id, buf, stream_thread_kwargs,
                    )
                buf.last_edit = now
            except Exception as e:
                self.logger.warning("Stream initial send failed: {}", e)
                raise
        else:
            edit_interval = (
                max(self.config.stream_edit_interval, TELEGRAM_RICH_DRAFT_MIN_INTERVAL)
                if buf.draft_id is not None
                else self.config.stream_edit_interval
            )
            if (now - buf.last_edit) < edit_interval:
                return
            overflow_limit = TELEGRAM_RICH_MAX_LEN if buf.draft_id is not None else TELEGRAM_MAX_MESSAGE_LEN
            if len(buf.text) > overflow_limit:
                try:
                    await self._flush_stream_overflow(
                        int_chat_id, buf, stream_thread_kwargs,
                    )
                except (NetworkError, RetryAfter) as exc:
                    self.logger.warning(
                        "Stream overflow flush paused with unsent content: {}", exc
                    )
                    # Persisted chunks have already been removed from ``buf``.
                    # Let the next delta or stream_end resume that tail; manager
                    # retry would append this same delta a second time.
                    return
                buf.last_edit = now
                return
            try:
                if buf.draft_id is not None:
                    if await self._try_send_rich_draft(
                        int_chat_id,
                        buf.draft_id,
                        buf.text,
                        stream_thread_kwargs,
                    ):
                        buf.last_edit = now
                        return
                    await self._start_legacy_stream(
                        int_chat_id, buf, stream_thread_kwargs,
                    )
                    buf.last_edit = now
                    return
                preview = _strip_md_block(buf.text)
                await self._call_with_retry(
                    app.bot.edit_message_text,
                    chat_id=int_chat_id, message_id=buf.message_id,
                    text=preview,
                )
                buf.last_edit = now
            except Exception as e:
                if self._is_not_modified_error(e):
                    buf.last_edit = now
                    return
                self.logger.warning("Stream edit failed: {}", e)
                raise

    async def _flush_stream_overflow(
        self,
        chat_id: int,
        buf: "_StreamBuf",
        thread_kwargs: dict[str, int],
    ) -> None:
        if buf.draft_id is not None:
            if not self._rich_streaming_enabled():
                await self._start_legacy_stream(chat_id, buf, thread_kwargs)
                return
            chunks = _split_telegram_markdown(buf.text, TELEGRAM_RICH_MAX_LEN)
            if len(chunks) <= 1:
                return

            for index, markdown in enumerate(chunks[:-1]):
                if await self._try_send_stream_rich(chat_id, markdown, thread_kwargs):
                    buf.text = "\n".join(chunks[index + 1:])
                    continue
                buf.text = "\n".join(chunks[index:])
                await self._start_legacy_stream(chat_id, buf, thread_kwargs)
                return

            buf.draft_id = self._new_rich_draft_id()
            if await self._try_send_rich_draft(
                chat_id, buf.draft_id, buf.text, thread_kwargs,
            ):
                return
            await self._start_legacy_stream(chat_id, buf, thread_kwargs)
            return

        await self._flush_stream_overflow_legacy(chat_id, buf, thread_kwargs)

    async def _flush_stream_overflow_legacy(
        self,
        chat_id: int,
        buf: "_StreamBuf",
        thread_kwargs: dict[str, int],
    ) -> None:
        chunks = _split_telegram_markdown_html_chunks(buf.text, TELEGRAM_HTML_MAX_LEN)
        if len(chunks) <= 1:
            return
        app = self._require_app()
        first_markdown, first_html = chunks[0]
        try:
            await self._call_with_retry(
                app.bot.edit_message_text,
                chat_id=chat_id, message_id=buf.message_id,
                text=first_html,
                parse_mode="HTML",
            )
        except BadRequest as e:
            if not self._is_not_modified_error(e):
                self.logger.warning(
                    "Stream overflow HTML edit failed, falling back to plain text: {}", e
                )
                try:
                    await self._call_with_retry(
                        app.bot.edit_message_text,
                        chat_id=chat_id, message_id=buf.message_id,
                        text=first_markdown,
                    )
                except Exception as plain_error:
                    if not self._is_not_modified_error(plain_error):
                        self.logger.warning("Stream overflow plain edit failed: {}", plain_error)
                        raise
        except Exception as e:
            self.logger.warning("Stream overflow edit failed: {}", e)
            raise

        async def send_chunk(markdown: str, html: str) -> Any:
            try:
                return await self._call_with_retry(
                    app.bot.send_message,
                    chat_id=chat_id, text=html, parse_mode="HTML", **thread_kwargs,
                )
            except BadRequest as e:
                self.logger.warning(
                    "Stream overflow HTML send failed, falling back to plain text: {}", e
                )
                return await self._call_with_retry(
                    app.bot.send_message,
                    chat_id=chat_id, text=markdown, **thread_kwargs,
                )

        for markdown, html in chunks[1:-1]:
            await send_chunk(markdown, html)
        markdown_tail, tail_html = chunks[-1]
        sent = await send_chunk(markdown_tail, tail_html)
        buf.message_id = sent.message_id
        buf.text = markdown_tail

    async def _on_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not update.message or not update.effective_user:
            return

        user = update.effective_user
        sender_id = self._sender_id(user)
        if not self.is_allowed(sender_id):
            await self._send_pairing_code_if_private(sender_id, update.message, user)
            return
        await update.message.reply_text(
            f"👋 Hi {user.first_name}! I'm nanobot.\n\n"
            "Send me a message and I'll respond!\n"
            "Type /help to see available commands."
        )

    async def _on_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not update.message or not update.effective_user:
            return
        user = update.effective_user
        sender_id = self._sender_id(user)
        if not self.is_allowed(sender_id):
            await self._send_pairing_code_if_private(sender_id, update.message, user)
            return
        await update.message.reply_text(_telegram_command_text(build_help_text()))

    @staticmethod
    def _sender_id(user: User) -> str:
        """Build sender_id with username for allowlist matching."""
        sid = str(user.id)
        return f"{sid}|{user.username}" if user.username else sid

    async def _send_pairing_code_if_private(
        self, sender_id: str, message: Message, user: User
    ) -> None:
        if message.chat.type != "private":
            return
        await self._handle_message(
            sender_id=sender_id,
            chat_id=str(message.chat_id),
            content="",
            metadata=self._build_message_metadata(message, user),
            is_dm=True,
        )

    @staticmethod
    def _derive_topic_session_key(message: Message) -> str | None:
        """Derive topic-scoped session key for Telegram chats with threads."""
        message_thread_id = getattr(message, "message_thread_id", None)
        if message_thread_id is None:
            return None
        return f"telegram:{message.chat_id}:topic:{message_thread_id}"

    @staticmethod
    def _build_message_metadata(message: Message, user: User) -> dict[str, Any]:
        """Build common Telegram inbound metadata payload."""
        reply_to = getattr(message, "reply_to_message", None)
        return {
            "message_id": message.message_id,
            "user_id": user.id,
            "username": user.username,
            "first_name": user.first_name,
            "is_group": message.chat.type != "private",
            "message_thread_id": getattr(message, "message_thread_id", None),
            "is_forum": bool(getattr(message.chat, "is_forum", False)),
            "reply_to_message_id": getattr(reply_to, "message_id", None) if reply_to else None,
        }

    async def _extract_reply_context(self, message: Message) -> str | None:
        reply = getattr(message, "reply_to_message", None)
        if not reply:
            return None
        text = getattr(reply, "text", None) or getattr(reply, "caption", None) or ""
        if len(text) > TELEGRAM_REPLY_CONTEXT_MAX_LEN:
            text = text[:TELEGRAM_REPLY_CONTEXT_MAX_LEN] + "..."

        if not text:
            return None

        bot_id, _ = await self._ensure_bot_identity()
        reply_user = getattr(reply, "from_user", None)

        if bot_id and reply_user and getattr(reply_user, "id", None) == bot_id:
            return f"[Reply to bot: {text}]"
        elif reply_user and getattr(reply_user, "username", None):
            return f"[Reply to @{reply_user.username}: {text}]"
        elif reply_user and getattr(reply_user, "first_name", None):
            return f"[Reply to {reply_user.first_name}: {text}]"
        else:
            return f"[Reply to: {text}]"

    async def _download_message_media(
        self, msg: Message, *, add_failure_content: bool = False
    ) -> tuple[list[str], list[str]]:
        media_file = None
        media_type = None
        if getattr(msg, "photo", None):
            media_file = msg.photo[-1]
            media_type = "image"
        elif getattr(msg, "voice", None):
            media_file = msg.voice
            media_type = "voice"
        elif getattr(msg, "audio", None):
            media_file = msg.audio
            media_type = "audio"
        elif getattr(msg, "document", None):
            media_file = msg.document
            media_type = "file"
        elif getattr(msg, "video", None):
            media_file = msg.video
            media_type = "video"
        elif getattr(msg, "video_note", None):
            media_file = msg.video_note
            media_type = "video"
        elif getattr(msg, "animation", None):
            media_file = msg.animation
            media_type = "animation"
        if not media_file or not self._app:
            return [], []
        try:
            file = await self._app.bot.get_file(media_file.file_id)
            ext = self._get_extension(
                cast(str, media_type),
                getattr(media_file, "mime_type", None),
                getattr(media_file, "file_name", None),
            )
            media_dir = get_media_dir("telegram")
            unique_id = getattr(media_file, "file_unique_id", media_file.file_id)
            file_path = media_dir / f"{unique_id}{ext}"
            await file.download_to_drive(str(file_path))
            path_str = str(file_path)
            if media_type in ("voice", "audio"):
                transcription = await self.transcribe_audio(file_path)
                if transcription:
                    self.logger.info("Transcribed {}: {}...", media_type, transcription[:50])
                    return [path_str], [f"[transcription: {transcription}]"]
                return [path_str], [f"[{media_type}: {path_str}]"]
            return [path_str], [f"[{media_type}: {path_str}]"]
        except Exception as e:
            self.logger.warning("Failed to download message media: {}", e)
            if add_failure_content:
                return [], [f"[{media_type}: download failed]"]
            return [], []

    async def _ensure_bot_identity(self) -> tuple[int | None, str | None]:
        if self._bot_user_id is not None or self._bot_username is not None:
            return self._bot_user_id, self._bot_username
        if not self._app:
            return None, None
        bot_info = await self._app.bot.get_me()
        self._bot_user_id = getattr(bot_info, "id", None)
        self._bot_username = getattr(bot_info, "username", None)
        return self._bot_user_id, self._bot_username

    @staticmethod
    def _has_mention_entity(
        text: str,
        entities: list[MessageEntity] | None,
        bot_username: str,
        bot_id: int | None,
    ) -> bool:
        """Check Telegram mention entities against the bot username."""
        handle = f"@{bot_username}".lower()
        for entity in entities or []:
            entity_type = getattr(entity, "type", None)
            if entity_type == "text_mention":
                user = getattr(entity, "user", None)
                if user is not None and bot_id is not None and getattr(user, "id", None) == bot_id:
                    return True
                continue
            if entity_type != "mention":
                continue
            offset = getattr(entity, "offset", None)
            length = getattr(entity, "length", None)
            if offset is None or length is None:
                continue
            if text[offset : offset + length].lower() == handle:
                return True
        return handle in text.lower()

    async def _is_group_message_for_bot(self, message: Message) -> bool:
        if message.chat.type == "private" or self.config.group_policy == "open":
            return True

        bot_id, bot_username = await self._ensure_bot_identity()
        if bot_username:
            text = message.text or ""
            caption = message.caption or ""
            if self._has_mention_entity(
                text,
                getattr(message, "entities", None),
                bot_username,
                bot_id,
            ):
                return True
            if self._has_mention_entity(
                caption,
                getattr(message, "caption_entities", None),
                bot_username,
                bot_id,
            ):
                return True

        reply_user = getattr(getattr(message, "reply_to_message", None), "from_user", None)
        return bool(bot_id and reply_user and reply_user.id == bot_id)

    def _remember_thread_context(self, message: Message) -> None:
        message_thread_id = getattr(message, "message_thread_id", None)
        if message_thread_id is None:
            return
        key = (str(message.chat_id), message.message_id)
        self._message_threads[key] = message_thread_id
        if len(self._message_threads) > 1000:
            self._message_threads.pop(next(iter(self._message_threads)))

    @staticmethod
    def _queue_key_for_message(message: Message) -> str:
        """Return the final nanobot session key used for ordered Telegram ingress."""
        return TelegramChannel._derive_topic_session_key(message) or f"telegram:{message.chat_id}"

    @staticmethod
    def _sort_key_for_update(update: Update) -> tuple[int, int]:
        """Sort by chat message id first, then Telegram update id."""
        message = getattr(update, "message", None)
        message_id = int(getattr(message, "message_id", 0) or 0)
        update_id = int(getattr(update, "update_id", 0) or 0)
        return (message_id, update_id)

    def _enqueue_ordered_update(
        self,
        *,
        kind: Literal["command", "message"],
        update: Update,
    ) -> None:
        message = update.message
        if message is None:
            return
        key = self._queue_key_for_message(message)
        self._inbound_buffers.setdefault(key, []).append(
            _QueuedTelegramUpdate(
                kind=kind,
                update=update,
                sort_key=self._sort_key_for_update(update),
            )
        )
        if key not in self._inbound_workers:
            self._inbound_workers[key] = asyncio.create_task(
                self._drain_ordered_updates(key)
            )

    async def _drain_ordered_updates(self, key: str) -> None:
        try:
            while self._running:
                await asyncio.sleep(0.2)
                batch = self._inbound_buffers.get(key, [])
                if not batch:
                    break
                self._inbound_buffers[key] = []
                batch.sort(key=lambda item: item.sort_key)
                for item in batch:
                    try:
                        if item.kind == "command":
                            await self._process_forward_command(item.update)
                        else:
                            await self._process_message_update(item.update)
                    except Exception as e:
                        self.logger.warning(
                            "Telegram queued update handling failed for {}: {}",
                            key,
                            e,
                        )
            if not self._inbound_buffers.get(key):
                self._inbound_buffers.pop(key, None)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            self.logger.warning("Telegram ordered update worker failed for {}: {}", key, e)
        finally:
            if not self._inbound_buffers.get(key):
                self._inbound_workers.pop(key, None)

    async def _forward_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not update.message or not update.effective_user:
            return
        if not self._running:
            await self._process_forward_command(update)
            return
        self._enqueue_ordered_update(kind="command", update=update)

    async def _process_forward_command(self, update: Update) -> None:
        message = update.message
        user = update.effective_user
        if message is None or user is None:
            return
        sender_id = self._sender_id(user)
        if not self.is_allowed(sender_id):
            await self._send_pairing_code_if_private(sender_id, message, user)
            return
        self._remember_thread_context(message)

        content = message.text or ""
        if content.startswith("/"):
            command = content.split(maxsplit=1)[0]
            content = command.split("@", 1)[0] + content[len(command):]
        content = self._normalize_telegram_command(content)

        await self._handle_message(
            sender_id=sender_id,
            chat_id=str(message.chat_id),
            content=content,
            metadata=self._build_message_metadata(message, user),
            session_key=self._derive_topic_session_key(message),
            is_dm=message.chat.type == "private",
        )

    async def _on_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not update.message or not update.effective_user:
            return
        if not self._running:
            await self._process_message_update(update)
            return
        self._enqueue_ordered_update(kind="message", update=update)

    async def _process_message_update(self, update: Update) -> None:

        message = update.message
        user = update.effective_user
        if message is None or user is None:
            return
        chat_id = message.chat_id
        sender_id = self._sender_id(user)
        if not self.is_allowed(sender_id):
            await self._send_pairing_code_if_private(sender_id, message, user)
            return
        self._remember_thread_context(message)

        if not await self._is_group_message_for_bot(message):
            return

        content_parts: list[str] = []
        media_paths: list[str] = []

        if message.text:
            content_parts.append(message.text)
        if message.caption:
            content_parts.append(message.caption)

        if message.location:
            lat = message.location.latitude
            lon = message.location.longitude
            content_parts.append(f"[location: {lat}, {lon}]")

        current_media_paths, current_media_parts = await self._download_message_media(
            message, add_failure_content=True
        )
        media_paths.extend(current_media_paths)
        content_parts.extend(current_media_parts)
        if current_media_paths:
            self.logger.debug("Downloaded message media to {}", current_media_paths[0])

        reply = getattr(message, "reply_to_message", None)
        if reply is not None:
            reply_ctx = await self._extract_reply_context(message)
            reply_media, reply_media_parts = await self._download_message_media(reply)
            if reply_media:
                media_paths = reply_media + media_paths
                self.logger.debug("Attached replied-to media: {}", reply_media[0])
            tag = reply_ctx or (f"[Reply to: {reply_media_parts[0]}]" if reply_media_parts else None)
            if tag:
                content_parts.insert(0, tag)
        content = "\n".join(content_parts) if content_parts else "[empty message]"

        self.logger.debug("message from {}: {}...", sender_id, content[:50])

        str_chat_id = str(chat_id)
        metadata = self._build_message_metadata(message, user)
        session_key = self._derive_topic_session_key(message)

        if media_group_id := getattr(message, "media_group_id", None):
            key = f"{str_chat_id}:{media_group_id}"
            if key not in self._media_group_buffers:
                self._media_group_buffers[key] = {
                    "sender_id": sender_id, "chat_id": str_chat_id,
                    "contents": [], "media": [],
                    "metadata": metadata,
                    "session_key": session_key,
                }
                self._start_typing(str_chat_id)
                await self._add_reaction(str_chat_id, message.message_id, self.config.react_emoji)
            buf = self._media_group_buffers[key]
            if content and content != "[empty message]":
                buf["contents"].append(content)
            buf["media"].extend(media_paths)
            if key not in self._media_group_tasks:
                self._media_group_tasks[key] = asyncio.create_task(self._flush_media_group(key))
            return

        self._start_typing(str_chat_id)
        await self._add_reaction(str_chat_id, message.message_id, self.config.react_emoji)

        await self._handle_message(
            sender_id=sender_id,
            chat_id=str_chat_id,
            content=content,
            media=media_paths,
            metadata=metadata,
            session_key=session_key,
        )

    async def _flush_media_group(self, key: str) -> None:
        try:
            await asyncio.sleep(0.6)
            if not (buf := self._media_group_buffers.pop(key, None)):
                return
            content = "\n".join(buf["contents"]) or "[empty message]"
            await self._handle_message(
                sender_id=buf["sender_id"], chat_id=buf["chat_id"],
                content=content, media=list(dict.fromkeys(buf["media"])),
                metadata=buf["metadata"],
                session_key=buf.get("session_key"),
            )
        finally:
            self._media_group_tasks.pop(key, None)

    def _start_typing(self, chat_id: str) -> None:
        self._stop_typing(chat_id)
        self._typing_tasks[chat_id] = asyncio.create_task(self._typing_loop(chat_id))

    def _stop_typing(self, chat_id: str) -> None:
        task = self._typing_tasks.pop(chat_id, None)
        if task and not task.done():
            task.cancel()

    async def _add_reaction(self, chat_id: str, message_id: int, emoji: str) -> None:
        if not self._app or not emoji:
            return
        try:
            await self._app.bot.set_message_reaction(
                chat_id=int(chat_id),
                message_id=message_id,
                reaction=[ReactionTypeEmoji(emoji=emoji)],
            )
        except Exception as e:
            self.logger.debug("reaction failed: {}", e)

    async def _remove_reaction(self, chat_id: str, message_id: int) -> None:
        if not self._app:
            return
        try:
            await self._app.bot.set_message_reaction(
                chat_id=int(chat_id),
                message_id=message_id,
                reaction=[],
            )
        except Exception as e:
            self.logger.debug("reaction removal failed: {}", e)

    async def _typing_loop(self, chat_id: str) -> None:
        try:
            with suppress(asyncio.CancelledError):
                while self._app:
                    await self._app.bot.send_chat_action(chat_id=int(chat_id), action="typing")
                    await asyncio.sleep(4)
        except Exception as e:
            self.logger.debug("Typing indicator stopped for {}: {}", chat_id, e)

    @staticmethod
    def _format_telegram_error(exc: Exception | None) -> str:
        """Return a short, readable error summary for logs."""
        if exc is None:
            return "None"
        text = str(exc).strip()
        if text:
            return text
        if exc.__cause__ is not None:
            cause = exc.__cause__
            cause_text = str(cause).strip()
            if cause_text:
                return f"{exc.__class__.__name__} ({cause_text})"
            return f"{exc.__class__.__name__} ({cause.__class__.__name__})"
        return exc.__class__.__name__

    def _on_polling_error(self, exc: Exception) -> None:
        summary = self._format_telegram_error(exc)
        if isinstance(exc, (NetworkError, TimedOut)):
            self.logger.warning("polling network issue: {}", summary)
        else:
            self.logger.error("polling error: {}", summary)

    async def _on_error(self, update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        summary = self._format_telegram_error(context.error)

        if isinstance(context.error, (NetworkError, TimedOut)):
            self.logger.warning("network issue: {}", summary)
        else:
            self.logger.error("error: {}", summary)

    def _get_extension(
        self,
        media_type: str,
        mime_type: str | None,
        filename: str | None = None,
    ) -> str:
        if mime_type:
            ext_map = {
                "image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif",
                "image/webp": ".webp",
                "audio/ogg": ".ogg", "audio/mpeg": ".mp3", "audio/mp4": ".m4a",
                "video/mp4": ".mp4", "video/quicktime": ".mov", "video/webm": ".webm",
                "video/x-matroska": ".mkv", "video/3gpp": ".3gp",
            }
            if mime_type in ext_map:
                return ext_map[mime_type]

        type_map = {"image": ".jpg", "voice": ".ogg", "audio": ".mp3", "video": ".mp4", "file": ""}
        if ext := type_map.get(media_type, ""):
            return ext

        if filename:
            return "".join(Path(filename).suffixes)

        return ""

    def _build_keyboard(self, buttons: list[list[str]]) -> InlineKeyboardMarkup | None:
        if not buttons or not self.config.inline_keyboards:
            return None
        keyboard = [
            [InlineKeyboardButton(label, callback_data=self._safe_callback_data(label)) for label in row]
            for row in buttons
        ]
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def _safe_callback_data(label: str) -> str:
        # Telegram caps callback_data at 64 bytes UTF-8; truncate at a char boundary so the keyboard still sends.
        encoded = label.encode("utf-8")
        if len(encoded) <= 64:
            return label
        return encoded[:64].decode("utf-8", errors="ignore")

    @staticmethod
    def _buttons_as_text(buttons: list[list[str]]) -> str:
        # Buttons are semantic options; when we can't render a keyboard, the user still needs to see them.
        return "\n".join(" ".join(f"[{label}]" for label in row) for row in buttons if row)

    async def _on_callback_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not update.callback_query or not update.effective_user:
            return
        query = update.callback_query
        user = update.effective_user
        query_message = query.message
        chat_id = query_message.chat.id if query_message else None
        sender_id = self._sender_id(user)
        if not chat_id:
            self.logger.warning("Callback query without chat_id")
            return
        if not self.is_allowed(sender_id):
            return
        button_label = query.data or ""
        await query.answer()
        if isinstance(query_message, Message):
            with suppress(Exception):
                await query_message.edit_reply_markup(reply_markup=None)
        self.logger.debug("Inline button tap from {}: {}", sender_id, button_label)
        self._start_typing(str(chat_id))
        await self._handle_message(
            sender_id=sender_id,
            chat_id=str(chat_id),
            content=button_label,
            metadata={
                "callback_query_id": query.id,
                "button_label": button_label,
                "user_id": user.id,
                "username": user.username,
                "first_name": user.first_name,
                "is_callback": True,
            },
        )
