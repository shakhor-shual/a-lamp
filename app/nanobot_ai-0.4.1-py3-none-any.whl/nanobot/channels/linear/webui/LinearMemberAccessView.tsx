import { useEffect, useId, useState } from "react";
import { Check, ChevronDown, Info, RefreshCw, Search } from "lucide-react";
import { useTranslation } from "react-i18next";

import { channelTranslator } from "@/channel-plugins/i18n";
import { ToggleButton } from "@/components/ui/toggle-button";
import { SETTINGS_SEARCH_INPUT_CLASS, SettingsGroup, SettingsRow } from "@/components/settings/shared/SettingsControls";
import { SettingsHint } from "@/components/settings/shared/SettingsHint";
import { SkeletonStatus } from "@/components/settings/shared/SkeletonStatus";
import { Button } from "@/components/ui/button";
import { DisclosureContent } from "@/components/ui/disclosure";
import { SearchInput } from "@/components/ui/input";
import { cn } from "@/lib/utils";

import { LinearAvatar } from "./LinearAvatar";

import type { LinearMembersPayload } from "./types";

export type LinearMemberSave = { status: "saving" | "saved" } | { status: "error"; message: string };
export interface LinearMemberAccessSnapshot {
  payload: LinearMembersPayload | null;
  loading: boolean;
  error: string | null;
  saves: Record<string, LinearMemberSave>;
}

export function LinearMemberAccessView({ snapshot, disabled = false, onLoad, onSetAllowed }: {
  snapshot: LinearMemberAccessSnapshot;
  disabled?: boolean;
  onLoad: (force?: boolean) => void;
  onSetAllowed: (userId: string, allowed: boolean, unconfirmedMessage: string) => void;
}) {
  const { t } = useTranslation();
  const tx = channelTranslator(t, "linear");
  const panelId = useId();
  const [expanded, setExpanded] = useState(false);
  const [search, setSearch] = useState("");
  const { payload, loading, error, saves } = snapshot;
  const members = payload?.members ?? [];
  const saving = Object.values(saves).some((save) => save.status === "saving");

  useEffect(() => {
    if (expanded && !disabled) onLoad();
  }, [onLoad, expanded, disabled]);

  const prefetch = () => { if (!disabled) onLoad(); };
  const needle = search.trim().toLocaleLowerCase();
  const visible = members.filter((member) => [member.name, member.id]
    .some((value) => value.toLocaleLowerCase().includes(needle)));
  const names = new Set<string>();
  const duplicateNames = new Set<string>();
  for (const member of members) {
    if (names.has(member.name)) duplicateNames.add(member.name);
    names.add(member.name);
  }

  return (
    <section className="w-full border-t border-border/50 bg-settings-surface">
      <button type="button" aria-expanded={expanded} aria-controls={panelId}
        disabled={disabled} onMouseEnter={prefetch} onFocus={prefetch}
        className="settings-list-inset flex min-h-12 w-full items-center justify-between gap-3 py-2 text-start text-[12px] font-medium settings-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring disabled:opacity-50"
        onClick={() => setExpanded(!expanded)}>
        <span className="shrink-0">{tx("members.title", "Member access")}</span>
        <span className="flex min-w-0 items-center gap-2">
          <span role="status" aria-live="polite" className="text-end text-[11px] font-normal text-muted-foreground">
            {payload ? !expanded ? tx("members.summary", "{{allowed}} enabled", {
              allowed: members.filter((member) => member.allowed).length,
            }) : null : loading ? tx("members.loading", "Finding members…") : null}
          </span>
          <ChevronDown className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 motion-reduce:transition-none", expanded && "rotate-180")} aria-hidden />
        </span>
      </button>
      <span role="status" aria-live="polite" className="sr-only">
        {payload && loading ? tx("members.refreshing", "Checking for updates…") : null}
      </span>
      <DisclosureContent id={panelId} open={expanded} className="space-y-3 pb-2">
        {payload?.legacy_allow_all ? <p className="settings-list-inset rounded-control bg-muted py-2 text-[12px] leading-5">
          {tx("members.allowAll", "Advanced settings currently allow all members (*), including new members. Individual off switches still take precedence. Remove * to require approval for new members.")}
        </p> : null}
        <div className="settings-list-inset flex items-center gap-2">
          <div className="relative min-w-0 flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <SearchInput value={search} onChange={(event) => setSearch(event.target.value)}
              aria-label={tx("members.search", "Search members")}
              placeholder={tx("members.search", "Search members")}
              className={cn(SETTINGS_SEARCH_INPUT_CLASS, "pl-9 text-[13px]")} />
          </div>
          <Button type="button" variant="ghost" size="icon" disabled={disabled || loading || saving}
            onClick={() => onLoad(true)} aria-label={tx("members.refresh", "Refresh members")}
            title={tx("members.refresh", "Refresh members")}>
            <RefreshCw className="h-4 w-4 text-muted-foreground" aria-hidden />
          </Button>
          <SettingsHint description={tx("members.help", "Enable members to use nanobot without a pairing code. Linear's existing authorization still applies. This does not grant access to the nanobot admin UI. Turning access off blocks new requests, not tasks already running.")}>
            <span className="flex h-9 w-9 items-center justify-center text-muted-foreground">
              <Info className="h-4 w-4" aria-hidden />
              <span className="sr-only">{tx("members.details", "About member access")}</span>
            </span>
          </SettingsHint>
        </div>
        {error ? <p role="alert" className="settings-list-inset break-words text-[12px] leading-5 text-destructive">
          {error} {tx("members.retry", "Refresh members to check the current state and try again.")}
        </p> : null}
        {payload && !error && visible.length === 0 ? <p className="settings-list-inset py-3 text-[12px] text-muted-foreground">
          {tx("members.empty", "No matching active members.")}
        </p> : null}
        {expanded && loading && !payload ? <SkeletonStatus label={tx("members.loading", "Finding members…")} className="space-y-0">
          {[0, 1, 2].map((index) => <div key={index} data-member-skeleton-row className="settings-disclosure-row">
            <div className="flex min-w-0 items-center gap-3">
              <div className="h-8 w-8 shrink-0 rounded-full bg-muted-foreground/20" />
              <div className="flex min-w-0 flex-1 flex-col justify-center gap-1.5"><div className="h-3 w-24 rounded bg-muted-foreground/20" /></div>
            </div>
            <div className="h-5 w-[38px] rounded-full bg-muted-foreground/20" />
          </div>)}
        </SkeletonStatus> : <SettingsGroup>
          <ul className="max-h-80 overflow-y-auto" aria-label={tx("members.title", "Member access")}>
            {visible.map((member) => {
              const save = saves[member.id];
              const statusId = `${panelId}-${member.id}-status`;
              return <li key={member.id}>
                <SettingsRow title={<div className="flex min-w-0 items-center gap-3">
                  <LinearAvatar name={member.name} url={member.avatar_url} />
                  <div className="min-w-0">
                    <p className="truncate" title={member.id}>{member.name}</p>
                    <div className="flex flex-wrap items-center gap-x-2 text-[12px] font-normal leading-4 text-muted-foreground">
                      <span id={save?.status === "error" ? undefined : statusId} role="status" aria-live="polite" className="inline-flex items-center gap-1">
                        {save?.status === "saving" ? tx("members.working", "Saving…") : null}
                        {save?.status === "saved" ? <><Check className="h-3 w-3" aria-hidden />{tx("members.saved", "Saved")}</> : null}
                      </span>
                    </div>
                    {duplicateNames.has(member.name) ?
                      <p className="break-all text-[11px] font-normal text-muted-foreground">{member.id}</p> : null}
                  </div>
                </div>}>
                  <ToggleButton checked={member.allowed}
                    disabled={disabled || save?.status === "saving" || save?.status === "error"}
                    aria-describedby={save ? statusId : undefined} aria-invalid={save?.status === "error" || undefined}
                    label={tx("members.allow", "Allow {{name}} to use nanobot", { name: member.name })}
                    onChange={(allowed) => onSetAllowed(member.id, allowed,
                      tx("members.saveUnconfirmed", "Access was not confirmed. Refresh members before trying again."))} />
                </SettingsRow>
                {save?.status === "error" ? <p id={statusId} role="alert" className="settings-list-inset break-words pb-3 text-[12px] leading-5 text-destructive">
                  {save.message} {tx("members.retry", "Refresh members to check the current state and try again.")}
                </p> : null}
              </li>;
            })}
          </ul>
        </SettingsGroup>}
      </DisclosureContent>
    </section>
  );
}
