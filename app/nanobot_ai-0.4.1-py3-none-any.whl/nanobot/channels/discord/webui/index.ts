import type { ChannelUiContribution } from "@/channel-plugins/types";
import { chatAppGuideUrl } from "@/channel-plugins/catalog";

export default {
  presentation: {
    logoUrl: "https://discord.com/favicon.ico",
    displayName: "Discord",
    initials: "DC",
    color: "#5865F2",
    setup: {
      mode: "credentials",
      docsUrl: chatAppGuideUrl("discord"),
      fields: [
        { key: "channels.discord.token", section: "credentials" },
        { key: "channels.discord.useProxy", section: "connection", control: "switch" },
        { key: "channels.discord.allowFrom", section: "access" },
        { key: "channels.discord.allowChannels", section: "access" },
        { key: "channels.discord.groupPolicy", section: "behavior" },
      ],
    },
  },
} satisfies ChannelUiContribution;
