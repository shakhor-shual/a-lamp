import { lazy } from "react";

import type { ChannelUiContribution } from "@/channel-plugins/types";
import { chatAppGuideUrl } from "@/channel-plugins/catalog";

const FeishuAssistantsPanel = lazy(() =>
  import("./FeishuAssistantsPanel").then(({ FeishuAssistantsPanel: component }) => ({
    default: component,
  })),
);

export default {
  Panel: FeishuAssistantsPanel,
  aliases: {
    lark: {
      displayName: "Lark",
      initials: "LK",
    },
  },
  presentation: {
    logoUrl: "https://www.larksuite.com/favicon.ico",
    logoLayout: "tile",
    displayName: "Feishu",
    initials: "FS",
    color: "#3370FF",
    setup: {
      mode: "connect",
      command: "nanobot channels login feishu",
      docsUrl: chatAppGuideUrl("feishu"),
      manualFields: [
        { key: "channels.feishu.appId" },
        { key: "channels.feishu.appSecret" },
        { key: "channels.feishu.domain" },
        { key: "channels.feishu.groupPolicy" },
        { key: "channels.feishu.allowFrom" },
      ],
    },
  },
} satisfies ChannelUiContribution;
