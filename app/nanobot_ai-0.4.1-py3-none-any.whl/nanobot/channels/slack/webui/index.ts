import type { ChannelUiContribution } from "@/channel-plugins/types";
import { chatAppGuideUrl } from "@/channel-plugins/catalog";

const SLACK_SOCKET_MODE_MANIFEST = `display_information:
  name: nanobot
features:
  app_home:
    home_tab_enabled: false
    messages_tab_enabled: true
    messages_tab_read_only_enabled: false
  bot_user:
    display_name: nanobot
oauth_config:
  scopes:
    bot:
      - app_mentions:read
      - channels:history
      - channels:read
      - chat:write
      - files:read
      - files:write
      - groups:history
      - groups:read
      - im:history
      - im:write
      - mpim:history
      - reactions:write
      - users:read
settings:
  event_subscriptions:
    bot_events:
      - app_mention
      - message.channels
      - message.groups
      - message.im
      - message.mpim
  socket_mode_enabled: true
  interactivity:
    is_enabled: true`;

export default {
  presentation: {
    logoUrl: "https://slack.com/favicon.ico",
    displayName: "Slack",
    initials: "SL",
    color: "#4A154B",
    setup: {
      mode: "credentials",
      docsUrl: chatAppGuideUrl("slack"),
      actions: [
        {
          id: "slack-manifest",
          copyText: SLACK_SOCKET_MODE_MANIFEST,
        },
      ],
      fields: [
        { key: "channels.slack.appToken", section: "credentials" },
        { key: "channels.slack.botToken", section: "credentials" },
        { key: "channels.slack.useProxy", section: "connection", control: "switch" },
        { key: "channels.slack.groupPolicy", section: "behavior" },
      ],
    },
  },
} satisfies ChannelUiContribution;
