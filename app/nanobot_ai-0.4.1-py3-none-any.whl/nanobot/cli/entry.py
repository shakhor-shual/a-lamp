from __future__ import annotations

import os
import sys
from contextlib import suppress

from nanobot.cli.process_identity import set_cli_process_identity
from nanobot.installation_lock import InstallationBusyError, installation_access

_ROOT_OPTIONS = frozenset(
    {
        "-h",
        "--help",
        "-v",
        "--version",
        "--install-completion",
        "--show-completion",
        "--home",
    }
)


def _agent_invocation_args(args: list[str]) -> list[str] | None:
    if not args:
        return []
    if args[0] == "agent":
        return args[1:]
    if args[0].startswith("-") and args[0].split("=", 1)[0] not in _ROOT_OPTIONS:
        return args
    return None


def _native_tui_candidate(args: list[str]) -> bool:
    if not args or args[0] != "agent":
        return False
    for argument in args[1:]:
        if argument in {"--classic", "--no-tui", "-m", "--message"}:
            return False
        if argument.startswith("--message=") or (
            argument.startswith("-m") and not argument.startswith("--")
        ):
            return False
    return True


def configure_windows_console() -> None:
    """Keep multilingual output usable for CLI and protected gateway startup."""
    if sys.platform != "win32" or sys.stdout.encoding == "utf-8":
        return
    os.environ["PYTHONIOENCODING"] = "utf-8"
    with suppress(Exception):
        for stream in (sys.stdout, sys.stderr):
            reconfigure = getattr(stream, "reconfigure", None)
            if callable(reconfigure):
                reconfigure(encoding="utf-8", errors="replace")


def _run_agent(args: list[str], *, prog_name: str) -> None:
    from nanobot.utils.log_config import configure_console_logging

    configure_console_logging(sys.stderr)
    import typer

    from nanobot.cli.agent import agent

    agent_app = typer.Typer(add_completion=False)
    agent_app.command()(agent)
    command = typer.main.get_command(agent_app)
    command.main(args=args, prog_name=prog_name)


def _command_args(args: list[str]) -> list[str]:
    position = 0
    while position < len(args):
        argument = args[position]
        if argument == "--home":
            position += 2
        elif argument.startswith("--home="):
            position += 1
        else:
            return args[position:]
    return []


def main() -> None:
    """Acquire a runtime lease before loading application code."""
    args = _command_args(sys.argv[1:])
    saved_update = args[:1] == ["update"] and any(argument.split("=", 1)[0] == "--job" for argument in args[1:])
    if args[:1] == ["update"] and not saved_update:
        # The update entrypoint takes its own exclusive lease only for execution.
        # Saved pre-mutation recovery instead owns a read lease before imports;
        # its detached worker can replace files only after this process exits.
        _dispatch()
        return
    try:
        # Keep the repair/stop path usable after an interrupted older updater.
        # These commands still take a lease and cannot run during a live install.
        diagnostics = args[:1] in (["--help"], ["-h"], ["--version"], ["-v"])
        stop_or_inspect = args[:2] in (["gateway", "stop"], ["gateway", "status"], ["gateway", "logs"])
        with installation_access(allow_incomplete=diagnostics or stop_or_inspect):
            _dispatch()
    except InstallationBusyError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1) from exc


def _dispatch() -> None:
    from nanobot.utils.rotating_output import configure_background_output_from_env

    configure_background_output_from_env()
    raw_args = sys.argv[1:]
    # Installed completion scripts call ``nanobot`` without positional arguments
    # and pass the request through this environment variable. Keep those requests
    # on the root command so subcommands remain discoverable.
    shell_completion = bool(os.environ.get("_NANOBOT_COMPLETE"))
    agent_args = None if shell_completion else _agent_invocation_args(raw_args)
    dispatch_args = ["agent", *agent_args] if agent_args is not None else raw_args
    set_cli_process_identity(dispatch_args)
    configure_windows_console()
    if not shell_completion and raw_args[:1] == ["update"]:
        import typer

        from nanobot.cli.update import update

        update_app = typer.Typer(add_completion=False)
        update_app.command()(update)
        typer.main.get_command(update_app).main(args=raw_args[1:], prog_name="nanobot update")
        return
    if not shell_completion and not raw_args:
        from nanobot.cli.desktop_target import dispatch_bare_desktop_target

        desktop_exit = dispatch_bare_desktop_target(raw_args)
        if desktop_exit is not None:
            if desktop_exit:
                raise SystemExit(desktop_exit)
            return
    root_agent_alias = agent_args is not None and raw_args[:1] != ["agent"]
    if agent_args is not None and (
        root_agent_alias or _native_tui_candidate(dispatch_args)
    ):
        prog_name = "nanobot" if root_agent_alias else "nanobot agent"
        _run_agent(agent_args, prog_name=prog_name)
        return

    from nanobot.cli.commands import app

    app()
