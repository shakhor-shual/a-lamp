from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal

from nanobot.bus.delivery import DeliveryRequest

if TYPE_CHECKING:
    from nanobot.events import AgentEvent

# Optional ``OutboundMessage.metadata`` key for structured, channel-agnostic UI
# payloads. Value is JSON-serializable with at least ``kind``; rich clients may
# render it and other channels may ignore unknown keys.
OUTBOUND_META_AGENT_UI = "_agent_ui"

# Internal-only inbound metadata minted by trusted transports and runtime
# services. Never accept these keys verbatim from an untrusted client.
INBOUND_META_RUNTIME_CONTROL = "_runtime_control"
INBOUND_META_USER_SHELL = "_user_shell"
RUNTIME_CONTROL_SESSION_DISCARD = "session_discard"

# Transport-provided turn correlation; the persisted spelling is retained for clients.
INBOUND_META_TURN_ID = "webui_turn_id"
INBOUND_META_LOCAL_MEDIA = "local_media_paths"


@dataclass
class InboundMessage:
    """Message received from a chat channel."""

    channel: str
    sender_id: str
    chat_id: str
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    media: list[str] = field(default_factory=list)  # Media paths or URLs
    metadata: dict[str, Any] = field(default_factory=dict)
    session_key_override: str | None = None  # Optional override for thread-scoped sessions
    require_existing_session: bool = False
    input_role: Literal["user", "system"] | None = None
    session_generation: str | None = None  # Trusted identity assigned at session admission

    @property
    def session_key(self) -> str:
        """Unique key for session identification."""
        return self.session_key_override or f"{self.channel}:{self.chat_id}"

    @property
    def is_user_input(self) -> bool:
        """Whether this message should enter the conversation as user input."""
        if self.input_role is not None:
            return self.input_role == "user"
        return self.channel != "system"


@dataclass
class OutboundMessage:
    """Message to send to a chat channel.

    ``event`` carries internal runtime/UI semantics. ``metadata`` is reserved
    for channel routing context (``message_id``, thread ids, etc.) and optional
    ``OUTBOUND_META_AGENT_UI`` blobs for rich clients.
    """

    channel: str
    chat_id: str
    content: str
    reply_to: str | None = None
    media: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    buttons: list[list[str]] = field(default_factory=list)
    event: "AgentEvent | None" = None
    delivery: DeliveryRequest | None = None
    delivery_id: str | None = None
