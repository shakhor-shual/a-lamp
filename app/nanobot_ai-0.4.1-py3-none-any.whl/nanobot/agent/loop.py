from __future__ import annotations

import asyncio
import dataclasses
import os
import time
import weakref
from collections.abc import Coroutine, Iterable, Mapping
from contextlib import AbstractContextManager, AsyncExitStack, ExitStack, nullcontext, suppress
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Any, Awaitable, Callable, TypeVar, cast

from loguru import logger

from nanobot.agent import context as agent_context
from nanobot.agent import model_presets as preset_helpers
from nanobot.agent.autocompact import AutoCompact
from nanobot.agent.context import ContextBuilder, PersistedPromptContextResolver, TranscriptInput
from nanobot.agent.cron_turns import CronTurnCoordinator
from nanobot.agent.execution_policy import ExecutionControlError, ExecutionPolicy, ExecutionScope
from nanobot.agent.hook import AgentHook, AgentTurnHookFactory
from nanobot.agent.memory import Consolidator
from nanobot.agent.model_runtime import ModelRuntimeResolver
from nanobot.agent.runner import AgentRunner, AgentRunResult, AgentRunSpec
from nanobot.agent.subagent import SubagentManager
from nanobot.agent.tools.context import RequestContext, bind_request_context, reset_request_context
from nanobot.agent.tools.exec_session import ExecSessionManager
from nanobot.agent.tools.file_state import FileStateStore, bind_file_states, reset_file_states
from nanobot.agent.tools.message import capture_message_deliveries
from nanobot.agent.tools.registry import ToolRegistry
from nanobot.agent.tools.runtime_control import AgentRuntimeControl
from nanobot.agent.turn_delivery import (
    TurnDelivery,
    TurnDeliveryFactory,
)
from nanobot.agent.turn_delivery import TurnRoute as TurnRoute
from nanobot.agent.turn_hooks import AgentTurnHookSpec, build_agent_turn_hook
from nanobot.bus.events import (
    INBOUND_META_LOCAL_MEDIA,
    INBOUND_META_RUNTIME_CONTROL,
    INBOUND_META_TURN_ID,
    INBOUND_META_USER_SHELL,
    RUNTIME_CONTROL_SESSION_DISCARD,
    InboundMessage,
    OutboundMessage,
)
from nanobot.bus.outbound_events import (
    StreamDeltaEvent,
    StreamedResponseEvent,
    StreamEndEvent,
)
from nanobot.bus.queue import MessageBus
from nanobot.command import CommandContext, CommandRouter
from nanobot.command.builtin import register_core_commands
from nanobot.command.router import CommandExpansion, command_text
from nanobot.config.network import NetworkConfig
from nanobot.config.schema import AgentDefaults, ModelPresetConfig
from nanobot.events import NO_EVENTS, AgentEvent, EventSink
from nanobot.llm_usage.context import source_from_request
from nanobot.providers.base import LLMProvider, LLMUsage, ProviderConversationState
from nanobot.providers.factory import ProviderSnapshot
from nanobot.runtime_admission import RuntimeMaintenanceError
from nanobot.runtime_context import (
    RUNTIME_CONTEXT_HISTORY_META,
    RUNTIME_CONTEXT_MESSAGE_META,
    RuntimeContextBlock,
    RuntimeContextProvider,
    append_runtime_context,
    resolve_runtime_context,
    runtime_context_blocks_from_metadata,
)
from nanobot.security.workspace_access import (
    WORKSPACE_SCOPE_METADATA_KEY,
    WorkspaceScopeResolver,
    bind_workspace_scope,
    reset_workspace_scope,
)
from nanobot.session import turn_continuation
from nanobot.session.automation_turns import automation_history_overrides
from nanobot.session.history_visibility import HIDDEN_HISTORY_META
from nanobot.session.keys import UNIFIED_SESSION_KEY, remember_last_channel
from nanobot.session.manager import SESSION_CACHE_MAX_SIZE, Session, SessionManager, SessionPolicy
from nanobot.session.model_selection import (
    SESSION_MODEL_PRESET_METADATA_KEY,
    model_preset_from_metadata,
)
from nanobot.session.recovery import (
    PENDING_FOLLOWUP_ID_KEY,
    RECOVERY_INBOUND_METADATA_KEY,
    REQUEST_ORIGIN_METADATA_KEY,
    RecoveryAdmission,
    RequestOrigin,
    pending_followups,
    request_origin_from_metadata,
    restore_pending_interruption,
    restore_runtime_checkpoint,
)
from nanobot.session.sqlite_store import SessionConflictError
from nanobot.session.state import SessionOperationQueueFullError
from nanobot.session.summary import (
    SessionSummary,
    SessionSummaryCheckpoint,
)
from nanobot.triggers.local_turns import LocalTriggerTurnCoordinator
from nanobot.utils.cancellation import task_is_cancelling
from nanobot.utils.document import reference_non_image_attachments
from nanobot.utils.helpers import image_placeholder_text
from nanobot.utils.llm_runtime import LLMRuntime
from nanobot.utils.progress_events import output_events
from nanobot.utils.runtime import (
    EMPTY_FINAL_RESPONSE_MESSAGE,
)

if TYPE_CHECKING:
    from nanobot.config.schema import (
        ChannelsConfig,
        Config,
        ToolsConfig,
    )
    from nanobot.cron.service import CronService
    from nanobot.triggers.local_store import LocalTriggerStore

_T = TypeVar("_T")
_SUBAGENT_PROVIDER_TASK_META = "subagent_provider_task_id"
_SUBAGENT_TERMINAL_WAIT_SECONDS = 300.0


def _prompt_scope_metadata(metadata: Mapping[str, Any]) -> dict[str, Any]:
    key = WORKSPACE_SCOPE_METADATA_KEY
    return {key: deepcopy(metadata[key])} if key in metadata else {}


class TurnKind(Enum):
    USER = auto()
    SYSTEM = auto()


@dataclass
class TurnContext:
    msg: InboundMessage
    session_key: str
    turn_id: str
    runtime: LLMRuntime | None
    kind: TurnKind
    delivery: TurnDelivery
    original_user_text: str | None = None
    session: Session | None = None

    history: list[dict[str, Any]] = field(default_factory=list)
    transcript_input: TranscriptInput | None = None
    provider_state: ProviderConversationState | None = field(default=None, repr=False)
    request_context: RequestContext | None = None
    runtime_context_blocks: list[RuntimeContextBlock] = field(default_factory=list)
    attributes: dict[str, Any] = field(default_factory=dict)

    final_content: str | None = None
    all_messages: list[dict[str, Any]] = field(default_factory=list)
    stop_reason: str = ""
    failure_error_kind: str | None = None
    streamed_content: bool = False

    input_persisted_early: bool = False
    save_skip: int = 0

    outbound: OutboundMessage | None = None
    suppress_response: bool = False

    events: EventSink = NO_EVENTS
    streaming: bool = False
    on_runtime_admitted: Callable[[LLMRuntime], Awaitable[None]] | None = None

    pending_queue: asyncio.Queue[InboundMessage] | None = None
    pending_summary: SessionSummary | None = None
    summary_checkpoint: SessionSummaryCheckpoint | None = None
    provider_compaction_applied: bool = False

    ephemeral: bool = False
    # SDK temporary turns use an isolated draft; gateway temporary chats retain owner state.
    commit_session: bool = True
    run_extra_hooks_for_ephemeral: bool = False
    hooks: list[AgentHook] = field(default_factory=list)
    hook_factories: list[AgentTurnHookFactory] = field(default_factory=list)
    tools: ToolRegistry | None = None

    turn_wall_started_at: float = field(default_factory=time.time)
    run_started_at: float = field(init=False, repr=False)
    turn_latency_ms: int | None = None
    usage: LLMUsage | None = None

    def require_runtime(self) -> LLMRuntime:
        """Return the runtime established by the BUILD stage."""
        if self.runtime is None:
            raise RuntimeError("turn runtime is not initialized; BUILD must run before this stage")
        return self.runtime

    def require_session(self) -> Session:
        """Return the session established by the RESTORE stage."""
        if self.session is None:
            raise RuntimeError("turn session is not initialized; RESTORE must run before this stage")
        return self.session


class AgentLoop:
    """
    The agent loop is the core processing engine.

    It:
    1. Receives messages from the bus
    2. Builds context with history, memory, skills
    3. Calls the LLM
    4. Executes tool calls
    5. Sends responses back
    """

    @property
    def tool_names(self) -> list[str]:
        return self.tools.tool_names

    @property
    def provider(self) -> LLMProvider:
        """Provider selected for future turn admissions."""
        return self.runtime_resolver.runtime.provider

    @property
    def model(self) -> str:
        """Model selected for future turn admissions."""
        return self.runtime_resolver.runtime.model

    @property
    def context_window_tokens(self) -> int:
        """Context limit selected for future turn admissions."""
        return self.runtime_resolver.runtime.context_window_tokens

    @property
    def model_presets(self) -> Mapping[str, ModelPresetConfig]:
        """Configured model presets exposed for selection and display."""
        return self.runtime_resolver.model_presets

    @property
    def model_preset(self) -> str | None:
        return self.runtime_resolver.model_preset

    @model_preset.setter
    def model_preset(self, name: str | None) -> None:
        self.set_model_preset(name)

    def llm_runtime(self) -> LLMRuntime:
        """Resolve the immutable default used to admit the next turn."""
        previous = self.runtime_resolver.runtime
        runtime = self.runtime_resolver.admit()
        if (
            runtime.model != previous.model
            or runtime.model_preset != previous.model_preset
            or runtime.snapshot_signature != previous.snapshot_signature
        ):
            self._publish_runtime_selection(runtime)
        return runtime

    def dream_runtime(self) -> LLMRuntime | None:
        """Resolve the optional preset used for Dream without changing defaults."""
        if not self.dream_model_preset:
            return None
        return self.runtime_resolver.resolve_preset(self.dream_model_preset)

    _RUNTIME_CHECKPOINT_KEY = "runtime_checkpoint"
    _PENDING_USER_TURN_KEY = "pending_user_turn"
    _PROVIDER_STATE_CHECKPOINT_VERSION_KEY = "provider_state_checkpoint_version"
    _PROVIDER_STATE_CHECKPOINT_VERSION = "v1"

    def __init__(
        self,
        bus: MessageBus,
        provider: LLMProvider,
        workspace: Path,
        model: str | None = None,
        max_iterations: int | None = None,
        max_concurrent_subagents: int | None = None,
        context_window_tokens: int | None = None,
        max_tool_result_chars: int | None = None,
        provider_retry_mode: str = "standard",
        cron_service: CronService | None = None,
        restrict_to_workspace: bool = False,
        session_manager: SessionManager | None = None,
        tool_registry: ToolRegistry | None = None,
        channels_config: ChannelsConfig | None = None,
        timezone: str | None = None,
        session_ttl_minutes: int = 0,
        hooks: list[AgentHook] | None = None,
        hook_factories: list[AgentTurnHookFactory] | None = None,
        unified_session: bool = False,
        disabled_skills: list[str] | None = None,
        tools_config: ToolsConfig | None = None,
        network_config: NetworkConfig | None = None,
        provider_snapshot_loader: Callable[..., ProviderSnapshot] | None = None,
        provider_signature: tuple[object, ...] | None = None,
        model_presets: dict[str, ModelPresetConfig] | None = None,
        preset_catalog_loader: preset_helpers.PresetCatalogLoader | None = None,
        model_preset: str | None = None,
        dream_model_preset: str | None = None,
        preset_snapshot_loader: preset_helpers.PresetSnapshotLoader | None = None,
        turn_delivery_factory: TurnDeliveryFactory | None = None,
        runtime_model_publisher: Callable[[str, str | None], None] | None = None,
        restart_mode: str = "auto",
        local_trigger_store: LocalTriggerStore | None = None,
        idle_compact_check_interval_seconds: int = 0,
        recovery_admission: RecoveryAdmission | None = None,
        builtin_assembly: Callable[[SessionManager, MessageBus, ToolRegistry, CommandRouter], ExecutionPolicy] | None = None,
    ):
        from nanobot.config.schema import ToolsConfig

        _tc = tools_config or ToolsConfig()
        defaults = AgentDefaults()
        self.bus = bus
        self.execution_policy: ExecutionPolicy | None = None
        self._recovery_admission = recovery_admission
        if turn_delivery_factory is not None:
            if turn_delivery_factory.bus is not bus:
                raise ValueError("turn delivery factory must use the agent message bus")
            self.turn_delivery_factory = turn_delivery_factory
        else:
            self.turn_delivery_factory = TurnDeliveryFactory(bus)
        self.runtime_event_publisher = self.turn_delivery_factory.runtime_event_publisher
        self.channels_config = channels_config
        self.restart_mode = restart_mode
        self._runtime_model_publisher = runtime_model_publisher
        self.workspace = workspace
        initial_model = model or provider.get_default_model()
        self.max_iterations = (
            max_iterations if max_iterations is not None else defaults.max_tool_iterations
        )
        initial_context_window = (
            context_window_tokens
            if context_window_tokens is not None
            else defaults.context_window_tokens
        )
        configured_presets = model_presets or {}
        self.runtime_resolver = ModelRuntimeResolver(
            LLMRuntime.capture(
                provider,
                initial_model,
                context_window_tokens=initial_context_window,
                snapshot_signature=provider_signature,
            ),
            model_presets=configured_presets,
            preset_catalog_loader=preset_catalog_loader,
            configured_default_preset=model_preset,
            provider_snapshot_loader=provider_snapshot_loader,
            preset_snapshot_loader=preset_snapshot_loader,
        )
        self.dream_model_preset = dream_model_preset
        self.max_tool_result_chars = (
            max_tool_result_chars
            if max_tool_result_chars is not None
            else defaults.max_tool_result_chars
        )
        self.provider_retry_mode = provider_retry_mode
        self.tools_config = _tc
        self.network_config = network_config or NetworkConfig()
        self.web_config = _tc.web
        self.exec_config = _tc.exec
        self.cron_service = cron_service
        self.local_trigger_store = local_trigger_store
        self.restrict_to_workspace = restrict_to_workspace
        self.workspace_scopes = WorkspaceScopeResolver(
            default_workspace=workspace,
            default_restrict_to_workspace=restrict_to_workspace,
        )
        self._start_time = time.time()
        self._extra_hooks: list[AgentHook] = hooks or []
        self._hook_factories: list[AgentTurnHookFactory] = hook_factories or []

        self.context = ContextBuilder(workspace, timezone=timezone, disabled_skills=disabled_skills)
        self.sessions = session_manager or SessionManager(workspace)
        # One file-read/write tracker per logical session. The tool registry is
        # shared by this loop, so tools resolve the active state via contextvars.
        self._file_state_store = FileStateStore(max_sessions=SESSION_CACHE_MAX_SIZE)
        # SessionManager owns every durable deletion entrypoint, including the
        # WebUI and fork rollback paths.  Observe that boundary once instead of
        # duplicating cleanup in each consumer.
        self.sessions.set_delete_observer(self._file_state_store.discard)
        self.tools = tool_registry if tool_registry is not None else ToolRegistry()
        self._exec_session_manager = ExecSessionManager()
        self.runner = AgentRunner()
        self.consolidator = Consolidator(
            store=self.context.memory,
            sessions=self.sessions,
            build_messages=self.context.build_messages,
            get_tool_definitions=self.tools.get_definitions,
            resolve_prompt_context=PersistedPromptContextResolver(
                workspace_scopes=self.workspace_scopes,
                unified_session=unified_session,
            ),
        )
        self.subagents = SubagentManager(
            workspace=workspace,
            bus=bus,
            tools_config=_tc,
            network_config=self.network_config,
            max_tool_result_chars=self.max_tool_result_chars,
            restrict_to_workspace=restrict_to_workspace,
            disabled_skills=disabled_skills,
            max_iterations=self.max_iterations,
            max_concurrent_subagents=max_concurrent_subagents,
            consolidator=self.consolidator,
            session_manager=self.sessions,
        )
        self._unified_session = unified_session
        self._running = False
        self._runtime_context_providers: list[RuntimeContextProvider] = []
        self._active_tasks: dict[str, set[asyncio.Task[Any]]] = {}
        self._discarding_sessions: set[str] = set()
        self._background_tasks: set[asyncio.Task[Any]] = set()
        self._close_lock = asyncio.Lock()
        self._session_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = (
            weakref.WeakValueDictionary()
        )
        # A queue is installed before its single session worker is scheduled.
        # It remains the only admission path until that worker atomically
        # observes the queue empty and removes it.
        self._pending_queues: dict[str, asyncio.Queue[InboundMessage]] = {}
        self._preserve_inflight_turns_on_shutdown = False
        self._deferred_automation_turns: dict[str, list[InboundMessage]] = {}
        self._cron_turns = CronTurnCoordinator(
            enqueue=self._enqueue_session_message,
            deferred_queues=self._deferred_automation_turns,
        )
        self._local_trigger_turns = LocalTriggerTurnCoordinator(
            enqueue=self._enqueue_session_message,
            deferred_queues=self._deferred_automation_turns,
        )
        self._automation_turn_coordinators = (
            self._cron_turns,
            self._local_trigger_turns,
        )
        # NANOBOT_MAX_CONCURRENT_REQUESTS: unset or <=0 means unlimited.
        _max = int(os.environ.get("NANOBOT_MAX_CONCURRENT_REQUESTS", "0"))
        self._concurrency_gate: asyncio.Semaphore | None = (
            asyncio.Semaphore(_max) if _max > 0 else None
        )
        self.auto_compact = AutoCompact(
            sessions=self.sessions,
            consolidator=self.consolidator,
            session_ttl_minutes=session_ttl_minutes,
            bind_events=self._idle_events,
            session_lock=self._get_session_lock,
        )
        self._idle_compact_check_interval_s = idle_compact_check_interval_seconds
        self._next_idle_compact_check_at = time.monotonic()
        self._idle_compact_check_running = False
        if model_preset:
            self.set_model_preset(model_preset, publish_update=False)
        self.commands = CommandRouter()
        register_core_commands(self.commands)
        if builtin_assembly is not None:
            self.execution_policy = builtin_assembly(self.sessions, self.bus, self.tools, self.commands)
        self._register_default_tools(provider_snapshot_loader=provider_snapshot_loader)

    @classmethod
    def from_config(
        cls,
        config: Config,
        bus: MessageBus | None = None,
        *,
        tool_registry: ToolRegistry,
        **extra: Any,
    ) -> AgentLoop:
        """Create an AgentLoop from config with the common parameter set.

        The tool registry is caller-owned so application composition can share
        it with infrastructure such as an ``MCPProvider``.

        Extra keyword arguments are forwarded to ``AgentLoop.__init__``,
        allowing callers to override or extend the standard config-derived
        parameters (e.g. ``cron_service``, ``session_manager``).
        """
        from nanobot.providers.factory import make_provider

        if bus is None:
            bus = MessageBus()
        defaults = config.agents.defaults
        if "session_manager" not in extra:
            data_dir = config.runtime_data_dir
            extra["session_manager"] = SessionManager(
                config.workspace_path,
                sessions_root=data_dir / "sessions" if data_dir is not None else None,
            )
        provider = extra.pop("provider", None) or make_provider(config)
        resolved = config.resolve_preset()
        model = extra.pop("model", None) or resolved.model
        context_window_tokens = extra.pop("context_window_tokens", None) or resolved.context_window_tokens
        provider_snapshot_loader = extra.pop("provider_snapshot_loader", None)
        preset_snapshot_loader = extra.pop("preset_snapshot_loader", None) or preset_helpers.make_preset_snapshot_loader(
            config,
            provider_snapshot_loader,
        )
        return cls(
            bus=bus,
            provider=provider,
            workspace=config.workspace_path,
            model=model,
            max_iterations=defaults.max_tool_iterations,
            max_concurrent_subagents=defaults.max_concurrent_subagents,
            context_window_tokens=context_window_tokens,
            max_tool_result_chars=defaults.max_tool_result_chars,
            provider_retry_mode=defaults.provider_retry_mode,
            restrict_to_workspace=config.tools.restrict_to_workspace,
            channels_config=config.channels,
            timezone=defaults.timezone,
            unified_session=defaults.unified_session,
            disabled_skills=defaults.disabled_skills,
            session_ttl_minutes=defaults.session_ttl_minutes,
            idle_compact_check_interval_seconds=defaults.idle_compact_check_interval_seconds,
            tools_config=config.tools,
            network_config=config.network,
            model_presets=preset_helpers.configured_model_presets(config),
            model_preset=defaults.model_preset,
            dream_model_preset=defaults.dream.model_override,
            restart_mode=config.gateway.restart_mode,
            provider_snapshot_loader=provider_snapshot_loader,
            preset_snapshot_loader=preset_snapshot_loader,
            tool_registry=tool_registry,
            **extra,
        )

    def _sync_subagent_runtime_limits(self) -> None:
        self.subagents.max_iterations = self.max_iterations

    def set_runtime_max_iterations(self, value: int) -> None:
        self.max_iterations = value
        self._sync_subagent_runtime_limits()

    def invalidate_runtime_config(self) -> None:
        """Invalidate runtime config for lazy refresh at the next admission."""
        self.runtime_resolver.invalidate()

    def refresh_runtime_config(self) -> LLMRuntime:
        """Refresh runtime config now and publish the canonical selection."""
        self.runtime_resolver.invalidate()
        runtime = self.runtime_resolver.admit()
        self._publish_runtime_selection(runtime)
        return runtime

    def _resolve_session_runtime(
        self,
        session: Session,
        *,
        recover_removed: bool,
    ) -> LLMRuntime | None:
        name = model_preset_from_metadata(session.metadata)
        if name is None:
            return self.llm_runtime()
        try:
            return self.runtime_resolver.resolve_preset(name)
        except KeyError:
            if not recover_removed or name in self.runtime_resolver.model_presets:
                raise
            logger.warning(
                "Session '{}' references removed model preset '{}'; falling back to default",
                session.key,
                name,
            )
            session.metadata.pop(SESSION_MODEL_PRESET_METADATA_KEY, None)
            return None

    async def runtime_for_session(
        self,
        session: Session,
        *,
        recover_removed: bool = True,
    ) -> LLMRuntime:
        """Resolve a session runtime without blocking on recovery persistence."""
        runtime = self._resolve_session_runtime(session, recover_removed=recover_removed)
        if runtime is not None:
            return runtime
        await self.sessions.state.update_metadata(
            session.key,
            {},
            remove=(SESSION_MODEL_PRESET_METADATA_KEY,),
            expected_generation=session.generation,
        )
        return self.llm_runtime()

    async def set_session_model_preset(
        self,
        session_key: str,
        name: str,
    ) -> LLMRuntime:
        """Validate and persist one session's preset selection without blocking."""
        runtime = self.runtime_resolver.resolve_preset(name)
        await self.sessions.state.update_metadata(
            session_key,
            {SESSION_MODEL_PRESET_METADATA_KEY: runtime.model_preset},
            create_if_missing=True,
        )
        return runtime

    def _publish_runtime_selection(
        self,
        runtime: LLMRuntime,
        *,
        publish_update: bool = True,
    ) -> None:
        if not publish_update:
            return
        if self._runtime_model_publisher is not None:
            self._runtime_model_publisher(runtime.model, runtime.model_preset)
        self.runtime_event_publisher.runtime_model_changed(
            runtime.model,
            runtime.model_preset,
        )

    def set_model_preset(
        self,
        name: str | None,
        *,
        publish_update: bool = True,
    ) -> LLMRuntime:
        """Select a named default runtime for future turns."""
        old_model = self.model
        runtime = self.runtime_resolver.select_preset(name)
        self._publish_runtime_selection(runtime, publish_update=publish_update)
        logger.info(
            "Runtime model switched for next turn: {} -> {}",
            old_model,
            runtime.model,
        )
        return runtime

    def set_runtime_model(self, model: str) -> LLMRuntime:
        """Select a model on the current provider for future turns."""
        return self.runtime_resolver.select_model(model)

    def set_runtime_context_window(self, context_window_tokens: int) -> LLMRuntime:
        """Select a context limit for future turns."""
        return self.runtime_resolver.select_context_window(context_window_tokens)

    def _register_default_tools(
        self,
        *,
        provider_snapshot_loader: Callable[..., ProviderSnapshot] | None,
    ) -> None:
        from nanobot.agent.tools.context import ToolContext
        from nanobot.agent.tools.loader import ToolLoader

        runtime_control = AgentRuntimeControl(self)
        self.register_runtime_context_provider(runtime_control.workspace_context)
        self.register_runtime_context_provider(
            partial(turn_continuation.iteration_limit_context, self.sessions.state),
        )
        ctx = ToolContext(
            config=self.tools_config,
            network=self.network_config,
            workspace=str(self.workspace),
            bus=self.bus,
            subagent_manager=self.subagents,
            cron_service=self.cron_service,
            exec_session_manager=self._exec_session_manager,
            sessions=self.sessions,
            provider_snapshot_loader=provider_snapshot_loader,
            timezone=self.context.timezone or "UTC",
            workspace_sandbox=self.workspace_scopes.sandbox_status,
            runtime_control=runtime_control,
        )
        loader = ToolLoader()
        registered = loader.load(ctx, self.tools)

        logger.info("Registered {} tools: {}", len(registered), registered)

    def register_runtime_context_provider(
        self,
        provider: RuntimeContextProvider,
    ) -> Callable[[], None]:
        """Register a per-turn context provider and return an unsubscribe callback."""
        if provider in self._runtime_context_providers:
            return lambda: None
        self._runtime_context_providers.append(provider)

        def _unsubscribe() -> None:
            with suppress(ValueError):
                self._runtime_context_providers.remove(provider)

        return _unsubscribe

    async def submit_cron_turn(self, msg: InboundMessage) -> OutboundMessage | None:
        return await self._cron_turns.submit(msg)

    async def submit_local_trigger_turn(self, msg: InboundMessage) -> OutboundMessage | None:
        return await self._local_trigger_turns.submit(msg)

    def pending_cron_job_ids_for_session(self, session_key: str) -> set[str]:
        return self._cron_turns.pending_job_ids_for_session(session_key)

    def pending_local_trigger_ids_for_session(self, session_key: str) -> set[str]:
        return self._local_trigger_turns.pending_trigger_ids_for_session(session_key)

    @staticmethod
    def _input_history_extra(msg: InboundMessage) -> dict[str, Any]:
        """Keep input admission separate from the run that eventually consumes it."""
        extra: dict[str, Any] = {"timestamp": msg.timestamp.isoformat()}
        turn_id = msg.metadata.get(INBOUND_META_TURN_ID)
        if isinstance(turn_id, str) and turn_id:
            extra[INBOUND_META_TURN_ID] = turn_id
        local_media = msg.metadata.get(INBOUND_META_LOCAL_MEDIA)
        if isinstance(local_media, list) and local_media:
            extra[INBOUND_META_LOCAL_MEDIA] = [path for path in cast(list[object], local_media) if isinstance(path, str)]
        return extra

    async def _persist_user_message_early(
        self,
        msg: InboundMessage,
        session: Session,
        runtime_context_blocks: list[RuntimeContextBlock] | None = None,
        **kwargs: Any,
    ) -> bool:
        if not turn_continuation.should_persist_user_message(msg.metadata):
            return False
        media_paths = [
            path
            for path in (msg.media or [])
            if isinstance(cast(object, path), str) and path
        ]
        content_value = cast(object, msg.content)
        has_text = isinstance(content_value, str) and content_value.strip()
        if has_text or media_paths or runtime_context_blocks:
            extra = self._input_history_extra(msg) | ({"media": list(media_paths)} if media_paths else {}) | agent_context.session_extra(msg.metadata)
            extra.update(kwargs)
            if HIDDEN_HISTORY_META in msg.metadata:
                extra[HIDDEN_HISTORY_META] = msg.metadata[HIDDEN_HISTORY_META]
            text = content_value if isinstance(content_value, str) else ""
            text_override, automation_extra = automation_history_overrides(msg.metadata)
            if text_override is not None:
                text = text_override
            extra.update(automation_extra)
            text, runtime_context_meta = append_runtime_context(
                text,
                runtime_context_blocks or (),
            )
            if runtime_context_meta is not None:
                extra[RUNTIME_CONTEXT_HISTORY_META] = runtime_context_meta
            session.add_message("user", text, **extra)
            self._mark_pending_user_turn(session)
            followup_id = msg.metadata.get(PENDING_FOLLOWUP_ID_KEY)
            if isinstance(followup_id, str) and followup_id:
                session.consumed_followup_ids |= {followup_id}
            await self.sessions.state.prepare_input(session)
            return True
        return False

    def _build_transcript_input(self, ctx: TurnContext) -> TranscriptInput:
        assert ctx.session is not None
        return TranscriptInput(
            history=ctx.history,
            current_message=ctx.msg.content,
            media=ctx.msg.media if ctx.kind is TurnKind.USER and ctx.msg.media else None,
            session_summary=ctx.pending_summary,
            runtime_context_blocks=ctx.runtime_context_blocks,
        )

    async def _request_context_for_turn(self, ctx: TurnContext) -> RequestContext:
        assert ctx.session is not None
        origin: RequestOrigin = {
            "message_id": ctx.msg.metadata.get("message_id"),
            "turn_id": ctx.delivery.route.turn_id or ctx.turn_id,
        }
        if turn_continuation.internal_continuation_inbound(ctx.msg.metadata):
            origin = request_origin_from_metadata(ctx.msg.metadata) or origin
        if origin != request_origin_from_metadata(ctx.session.metadata):
            ctx.session.metadata[REQUEST_ORIGIN_METADATA_KEY] = origin
            if ctx.original_user_text is None:
                # No new user row will persist this turn's owner before execution.
                await self.sessions.state.update_metadata(
                    ctx.session.key,
                    {REQUEST_ORIGIN_METADATA_KEY: origin},
                    expected_generation=ctx.session.generation,
                )
        scope = await self.runner.prepare_prompt(
            self.workspace_scopes.for_turn,
            channel=ctx.delivery.route.channel,
            message_metadata=_prompt_scope_metadata(ctx.msg.metadata),
            session_metadata=_prompt_scope_metadata(ctx.session.metadata),
        )
        return RequestContext(
            channel=ctx.delivery.route.channel,
            chat_id=ctx.delivery.route.chat_id,
            message_id=origin["message_id"],
            session_key=ctx.session_key,
            session_generation=ctx.session.generation,
            original_user_text=ctx.original_user_text,
            runtime=ctx.runtime,
            metadata=dict(ctx.msg.metadata or {}),
            attributes=dict(ctx.attributes),
            sender_id=ctx.msg.sender_id,
            turn_id=origin["turn_id"],
            workspace=scope.project_path,
            workspace_scope=scope,
            log_content=ctx.session.policy.log_content and not ctx.ephemeral,
            persist_session=ctx.session.policy.persist and not ctx.ephemeral,
            can_receive_background_results=self._running,
        )

    async def _resolve_runtime_context_for_turn(
        self,
        ctx: TurnContext,
    ) -> list[RuntimeContextBlock]:
        assert ctx.request_context is not None
        return await self._resolve_runtime_context_for_request(
            ctx.request_context,
            ctx.tools if ctx.tools is not None else self.tools,
        )

    async def _resolve_runtime_context_for_request(
        self,
        request: RequestContext,
        tools: ToolRegistry,
    ) -> list[RuntimeContextBlock]:
        providers = [
            *tools.get_runtime_context_providers(),
            *self._runtime_context_providers,
        ]
        blocks = runtime_context_blocks_from_metadata(request.metadata)
        blocks.extend(await resolve_runtime_context(providers, request))
        text = request.original_user_text or ""
        skill_context = (
            await self.runner.prepare_prompt(self.context.skills.build_explicit_skill_runtime_context, text)
            if "$" in text else None
        )
        if skill_context is not None and skill_context not in blocks:
            blocks.append(skill_context)
        return blocks

    async def _prepare_command_expansion(
        self, ctx: CommandContext, result: CommandExpansion,
    ) -> InboundMessage | OutboundMessage:
        session = ctx.session
        if session is None:
            if ctx.msg.require_existing_session or ctx.msg.session_generation is not None:
                session = await self.sessions.state.read(ctx.key)
                if session is None:
                    raise SessionConflictError("command session no longer exists")
            else:
                session = await self.sessions.state.get(ctx.key)
        if ctx.msg.session_generation is not None and session.generation != ctx.msg.session_generation:
            raise SessionConflictError("command belongs to a replaced session")
        if result.temporary_session_error is not None and not session.policy.persist:
            return OutboundMessage(
                channel=ctx.msg.channel,
                chat_id=ctx.msg.chat_id,
                content=result.temporary_session_error,
                metadata={**dict(ctx.msg.metadata or {}), "render_as": "text"},
            )
        session.add_message("user", ctx.msg.content, _command=True, media=list(ctx.msg.media))
        await self.sessions.state.prepare_input(session)
        return result.message

    async def _dispatch_command_inline(
        self,
        msg: InboundMessage,
        key: str,
        raw: str,
        dispatch_fn: Callable[
            [CommandContext], Awaitable[CommandExpansion | InboundMessage | OutboundMessage | None],
        ],
    ) -> None:
        if self.commands.requires_session_queue(raw):
            await self._enqueue_session_message(msg)
            return

        async def dispatch_and_publish() -> None:
            _, automation_metadata = automation_history_overrides(msg.metadata)
            ctx = CommandContext(
                msg=msg, session=None, key=key, raw=raw, loop=self,
                is_user_turn=(
                    msg.is_user_input and msg.channel != "system"
                    and msg.sender_id != "subagent" and not automation_metadata
                    and not turn_continuation.internal_continuation_inbound(msg.metadata)
                ),
            )
            result = await dispatch_fn(ctx)
            if isinstance(result, CommandExpansion):
                result = await self._prepare_command_expansion(ctx, result)
            if isinstance(result, InboundMessage):
                await self._enqueue_session_message(result)
            elif result is not None:
                await self.bus.publish_outbound(result)

        # A shell command may run for up to the configured exec timeout. Keep
        # the inbound consumer responsive when it runs beside an active turn.
        if (msg.metadata or {}).get(INBOUND_META_USER_SHELL) is True:
            self.schedule_background(dispatch_and_publish())
            return
        await dispatch_and_publish()

    def _track_active_task(self, key: str, task: asyncio.Task[Any]) -> None:
        tasks = self._active_tasks.setdefault(key, set())
        tasks.add(task)
        task.add_done_callback(partial(self._active_task_done, key, tasks))

    def _active_task_done(
        self,
        key: str,
        tasks: set[asyncio.Task[Any]],
        task: asyncio.Task[Any],
    ) -> None:
        tasks.discard(task)
        if not tasks and self._active_tasks.get(key) is tasks:
            self._active_tasks.pop(key, None)

    async def _cancel_active_tasks(self, key: str) -> int:
        pending = self._pending_queues.get(key)
        tasks = tuple(self._active_tasks.pop(key, set()))
        cancelled = sum(1 for t in tasks if not t.done() and t.cancel())
        journal_session = await self.sessions.state.read(key)
        journaled_followup_ids = (
            tuple(
                followup_id
                for followup in pending_followups(journal_session)
                if isinstance(
                    followup_id := followup.metadata.get(PENDING_FOLLOWUP_ID_KEY),
                    str,
                )
            )
            if journal_session is not None
            else ()
        )
        for t in tasks:
            try:
                await t
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
        if tasks and pending is not None and self._pending_queues.get(key) is pending:
            # A task cancelled before its first step never enters the worker's
            # cleanup handler. Only reclaim that worker's original inbox.
            self._pending_queues.pop(key, None)
            await self._cancel_pending_messages(key, pending, asyncio.CancelledError())
        if journaled_followup_ids and journal_session is not None:
            # Explicit session cancellation owns the follow-ups accepted before
            # it began. Gateway shutdown uses aclose() directly and keeps this
            # journal intact for startup recovery.
            await self.sessions.state.acknowledge_followups(key, journaled_followup_ids)
        sub_cancelled = await self.subagents.cancel_by_session(key)
        exec_cancelled = await self._exec_session_manager.terminate_by_owner(key)
        return cancelled + sub_cancelled + exec_cancelled

    async def discard_session(self, key: str) -> None:
        """Stop active work for *key* and forget its cached session."""
        with self.bus.admission.activity():
            self._discarding_sessions.add(key)
            try:
                await self.sessions.state.discard(key)
                await self._cancel_active_tasks(key)
            finally:
                self.discard_session_file_state(key)
                self._discarding_sessions.discard(key)

    def discard_session_file_state(self, key: str) -> None:
        """Forget ephemeral file-read state for a reset or removed session."""
        self._file_state_store.discard(key)

    def _effective_session_key(self, msg: InboundMessage) -> str:
        if self._unified_session and not msg.session_key_override:
            return UNIFIED_SESSION_KEY
        return msg.session_key

    def _can_inject_message(self, msg: InboundMessage) -> bool:
        if turn_continuation.internal_continuation_inbound(msg.metadata) or any(
            coordinator.owns_turn(msg) for coordinator in self._automation_turn_coordinators
        ):
            return False
        return msg.channel == "system" or not self.commands.is_dispatchable_command(
            command_text(msg)
        )

    def _idle_events(
        self,
        session_key: str,
    ) -> EventSink:
        session = self.sessions.state.peek_header(session_key)
        if session is None:
            return NO_EVENTS
        return self.turn_delivery_factory.session_events(
            session_key, session.metadata, generation=session.generation,
        )

    def _remember_session_route(
        self,
        session: Session,
        msg: InboundMessage,
        *,
        delivery: TurnDelivery,
        is_user_turn: bool,
    ) -> None:
        if (
            not is_user_turn
            or msg.channel in {"cli", "system"}
            or msg.sender_id == "subagent"
        ):
            return
        _, automation_metadata = automation_history_overrides(msg.metadata)
        if automation_metadata:
            return
        delivery.remember_session_route(session.metadata)
        if self._unified_session and session.key == UNIFIED_SESSION_KEY:
            remember_last_channel(session.metadata, msg.channel, msg.chat_id)

    async def _run_agent_loop(
        self,
        transcript_input: TranscriptInput,
        events: EventSink = NO_EVENTS,
        streaming: bool = False,
        *,
        runtime: LLMRuntime,
        session: Session | None = None,
        pending_queue: asyncio.Queue[InboundMessage] | None = None,
        ephemeral: bool = False,
        run_extra_hooks_for_ephemeral: bool = False,
        hooks: list[AgentHook] | None = None,
        hook_factories: list[AgentTurnHookFactory] | None = None,
        tools: ToolRegistry | None = None,
        request_context: RequestContext | None = None,
        provider_state: ProviderConversationState | None = None,
        initial_message: InboundMessage | None = None,
        commit_session: bool = True,
    ) -> AgentRunResult:
        self._sync_subagent_runtime_limits()

        ephemeral = ephemeral or (session is not None and not session.policy.persist)
        # Detached SDK turns can share a durable key without owning that session.
        retain_session_state = (
            commit_session and session is not None and (not ephemeral or not session.policy.persist)
        )

        async def _checkpoint(payload: dict[str, Any]) -> None:
            if session is None or not retain_session_state:
                return
            public_payload = dict(payload)
            preceding = Session(key=session.key)
            self._save_turn(preceding, public_payload["preceding_messages"], skip=0)
            public_payload["preceding_messages"] = preceding.messages
            public_payload["consumed_followup_ids"] = sorted(preceding.consumed_followup_ids)
            private_state = public_payload.pop("provider_state", None)
            previous_state = session.provider_state
            public_payload.pop(self._PROVIDER_STATE_CHECKPOINT_VERSION_KEY, None)
            if "provider_state" in payload and (
                private_state is None
                or isinstance(private_state, ProviderConversationState)
            ):
                session.provider_state = private_state
                public_payload[self._PROVIDER_STATE_CHECKPOINT_VERSION_KEY] = (
                    self._PROVIDER_STATE_CHECKPOINT_VERSION
                )
            try:
                await self._set_runtime_checkpoint(session, public_payload)
            except BaseException:
                session.provider_state = previous_state
                raise

        async def _drain_pending(
            *,
            first_msg: InboundMessage | None = None,
        ) -> list[dict[str, Any]]:
            if pending_queue is None:
                return []

            # Capture the boundary before converting any message. Conversion
            # resolves runtime context and may await, so reading until QueueEmpty
            # afterwards would let later arrivals leak into this model step.
            pending_messages: list[InboundMessage] = []
            if first_msg is not None:
                pending_messages.append(first_msg)
            snapshot_size = pending_queue.qsize()
            for _ in range(snapshot_size):
                try:
                    pending_messages.append(pending_queue.get_nowait())
                except asyncio.QueueEmpty:
                    break

            async def _to_user_message(pending_msg: InboundMessage) -> dict[str, Any] | None:
                content = pending_msg.content
                image_paths = pending_msg.media if pending_msg.media else None
                if image_paths:
                    content, image_paths = reference_non_image_attachments(
                        content,
                        image_paths,
                    )
                    image_paths = image_paths or None
                user_content = self.context.build_user_content(
                    content,
                    image_paths=image_paths,
                )
                row: dict[str, Any] = {
                    "role": "user", "content": user_content,
                    "_meta": self._input_history_extra(pending_msg),
                }
                if HIDDEN_HISTORY_META in pending_msg.metadata:
                    row[HIDDEN_HISTORY_META] = pending_msg.metadata[HIDDEN_HISTORY_META]
                metadata_value = cast(object, pending_msg.metadata)
                metadata = (
                    pending_msg.metadata
                    if isinstance(metadata_value, dict)
                    else {}
                )
                if pending_msg.is_user_input:
                    scope = await self.runner.prepare_prompt(
                        self.workspace_scopes.for_turn,
                        channel=pending_msg.channel,
                        message_metadata=_prompt_scope_metadata(metadata),
                        session_metadata=_prompt_scope_metadata(session.metadata) if session is not None else None,
                    )
                    # A follow-up cannot inherit another input's tool authority.
                    # Leave it for the FIFO worker to run with its own scope.
                    if scope != effective_scope:
                        return None
                    pending_request = RequestContext(
                        channel=pending_msg.channel,
                        chat_id=pending_msg.chat_id,
                        message_id=metadata.get("message_id"),
                        session_key=active_session_key,
                        session_generation=session.generation if session is not None else None,
                        original_user_text=pending_msg.content,
                        runtime=runtime,
                        metadata=dict(metadata),
                        attributes=dict(request_ctx.attributes),
                        sender_id=pending_msg.sender_id,
                        turn_id=request_ctx.turn_id,
                        workspace=scope.project_path,
                        # Injected input continues the active run's tool policy.
                        workspace_scope=effective_scope,
                        log_content=request_ctx.log_content,
                    )
                    blocks = await self._resolve_runtime_context_for_request(
                        pending_request,
                        effective_tools,
                    )
                    row["content"], runtime_marker = append_runtime_context(
                        user_content,
                        blocks,
                    )
                    if runtime_marker is not None:
                        row["_meta"][RUNTIME_CONTEXT_MESSAGE_META] = runtime_marker
                if (
                    pending_msg.sender_id == "subagent"
                    and metadata.get("injected_event") == "subagent_result"
                ):
                    subagent_marker: dict[str, Any] = {"kind": "subagent_result"}
                    task_id = metadata.get("subagent_task_id")
                    if isinstance(task_id, str) and task_id:
                        subagent_marker["subagent_task_id"] = task_id
                        row["subagent_task_id"] = task_id
                    row[HIDDEN_HISTORY_META] = subagent_marker
                    row["injected_event"] = "subagent_result"
                followup_id = metadata.get(PENDING_FOLLOWUP_ID_KEY)
                if isinstance(followup_id, str) and followup_id:
                    row[PENDING_FOLLOWUP_ID_KEY] = followup_id
                return row

            consumed = 0
            try:
                converted: list[dict[str, Any]] = []
                consumed_inputs: list[InboundMessage] = []
                for pending_msg in pending_messages:
                    # Independent turns are FIFO barriers. Their worker path
                    # owns completion, command dispatch, and control metadata.
                    if not self._can_inject_message(pending_msg):
                        break
                    row = await _to_user_message(pending_msg)
                    if row is None:
                        break
                    converted.append(row)
                    consumed_inputs.append(pending_msg)
                if execution_scope is not None:
                    try:
                        execution_scope.consume_inputs(consumed_inputs)
                    except Exception as exc:
                        raise ExecutionControlError("could not accept consumed inputs") from exc
                consumed = len(converted)
                return converted
            finally:
                # Commit only a successfully converted prefix. On failure or
                # cancellation, return the whole snapshot ahead of later arrivals.
                unconsumed = pending_messages[consumed:]
                if unconsumed:
                    later = [pending_queue.get_nowait() for _ in range(pending_queue.qsize())]
                    for pending_msg in [*unconsumed, *later]:
                        pending_queue.put_nowait(pending_msg)

        terminal_wait_deadline: float | None = None

        async def _wait_for_pending() -> list[dict[str, Any]]:
            nonlocal terminal_wait_deadline

            items = await _drain_pending()
            if (
                items
                or pending_queue is None
                or session is None
                or self.subagents.get_running_count_by_session(session.key) == 0
            ):
                return items

            now = asyncio.get_running_loop().time()
            if terminal_wait_deadline is None:
                terminal_wait_deadline = now + _SUBAGENT_TERMINAL_WAIT_SECONDS
            remaining = terminal_wait_deadline - now
            if remaining <= 0:
                return []

            try:
                msg = await asyncio.wait_for(pending_queue.get(), timeout=remaining)
            except asyncio.TimeoutError:
                logger.warning(
                    "Timeout waiting for sub-agent completion before session {} exits",
                    session.key,
                )
                return []

            return await _drain_pending(first_msg=msg)

        request_ctx = request_context or RequestContext(
            channel="cli",
            chat_id="direct",
            session_key=session.key if session is not None else None,
            runtime=runtime,
            can_receive_background_results=self._running,
        )
        active_session_key = session.key if session else request_ctx.session_key
        consolidation_session_key = active_session_key or "agent:transient"
        request_metadata = request_ctx.metadata
        effective_scope = await self.runner.prepare_prompt(
            self.workspace_scopes.for_turn,
            channel=request_ctx.channel,
            message_metadata=_prompt_scope_metadata(request_metadata),
            session_metadata=_prompt_scope_metadata(session.metadata) if session is not None else None,
        )
        transcript_builder = partial(
            self.context.build_transcript,
            channel=request_ctx.channel,
            workspace=effective_scope.project_path,
            include_memory=session.policy.persist if session is not None else True,
        )
        if request_context is None:
            request_ctx = dataclasses.replace(
                request_ctx,
                workspace=effective_scope.project_path,
            )
        request_ctx = dataclasses.replace(
            request_ctx,
            workspace_scope=effective_scope,
            session_generation=(
                session.generation if session is not None else request_ctx.session_generation
            ),
            log_content=(
                request_ctx.log_content and not ephemeral
                and (session is None or session.policy.log_content)
            ),
            persist_session=(
                request_ctx.persist_session and not ephemeral
                and (session is None or session.policy.persist)
            ),
        )
        effective_tools = tools if tools is not None else self.tools
        file_state_token = bind_file_states(self._file_state_store.for_session(active_session_key))
        request_token = bind_request_context(request_ctx)
        workspace_token = bind_workspace_scope(effective_scope)
        turn_scope_stack = ExitStack()
        execution_scope: ExecutionScope | None = None
        try:
            if self.execution_policy is not None:
                execution_scope = turn_scope_stack.enter_context(self.execution_policy.scope(
                    active_session_key,
                    session.generation if session is not None else request_ctx.session_generation,
                    persistent=request_ctx.persist_session,
                ))
                if initial_message is not None:
                    execution_scope.consume_inputs((initial_message,))

            hook = build_agent_turn_hook(AgentTurnHookSpec(
                events=events,
                streaming=streaming,
                channel=request_ctx.channel,
                chat_id=request_ctx.chat_id,
                message_id=request_ctx.message_id,
                metadata=request_metadata,
                attributes=dict(request_ctx.attributes),
                session_key=active_session_key,
                workspace=effective_scope.project_path,
                registered_hook_factories=self._hook_factories,
                turn_hook_factories=list(hook_factories or []),
                registered_hooks=self._extra_hooks,
                turn_hooks=list(hooks or []),
                ephemeral=ephemeral,
                run_extra_hooks_for_ephemeral=run_extra_hooks_for_ephemeral,
                log_content=request_ctx.log_content,
            ))
            result = await self.runner.run(AgentRunSpec(
                initial_messages=None,
                tools=effective_tools,
                runtime=runtime,
                max_iterations=self.max_iterations,
                max_tool_result_chars=self.max_tool_result_chars,
                transcript_input=transcript_input,
                transcript_builder=transcript_builder,
                hook=hook,
                concurrent_tools=True,
                # Temporary turns use the governor's bounded in-memory results;
                # never create durable spill files, even before discard/cancellation.
                workspace=None if ephemeral else effective_scope.project_path,
                session_key=session.key if session else None,
                provider_retry_mode=self.provider_retry_mode,
                checkpoint_callback=_checkpoint,
                consolidate_history=partial(
                    self.consolidator.summarize_transcript,
                    runtime=runtime,
                    session_key=consolidation_session_key,
                    tools=effective_tools.get_definitions(),
                    persist=session is not None and not ephemeral,
                ),
                consolidate_provider_compaction=partial(
                    self.consolidator.summarize_provider_compaction,
                    runtime=runtime,
                    session_key=consolidation_session_key,
                    tools=effective_tools.get_definitions(),
                    persist=session is not None and not ephemeral,
                ),
                injection_callback=_drain_pending,
                terminal_injection_callback=_wait_for_pending,
                continuation_callback=(
                    execution_scope.continuation_prompt if execution_scope is not None else None
                ),
                provider_state=provider_state,
                llm_usage_source=source_from_request(
                    active_session_key,
                    channel=request_ctx.channel,
                    metadata=request_metadata,
                ),
                events=events,
            ))
        finally:
            turn_scope_stack.close()
            reset_workspace_scope(workspace_token)
            reset_request_context(request_token)
            reset_file_states(file_state_token)
        if session is not None and retain_session_state:
            session.provider_state = result.provider_state
        if result.stop_reason == "max_iterations":
            logger.warning("Max iterations ({}) reached", self.max_iterations)
        if result.stop_reason == "max_iterations" or result.pending_stream_content is not None:
            # Push final content through stream so streaming channels (e.g. Feishu)
            # update the card instead of leaving it empty.
            if events.publish is not None and streaming:
                stream_content = (
                    result.pending_stream_content
                    if result.pending_stream_content is not None
                    else result.final_content or ""
                )
                await events.publish(StreamDeltaEvent(content=stream_content))
                await events.publish(StreamEndEvent())
        elif result.stop_reason == "error":
            logger.error(
                "LLM returned error: {}",
                (result.final_content or "")[:200] if request_ctx.log_content else "[content hidden]",
            )
        return result

    def _idle_compact_check_due(self, now: float) -> bool:
        return (
            self.auto_compact.enabled
            and not self.bus.admission.paused
            and not self._idle_compact_check_running
            and now >= self._next_idle_compact_check_at
        )

    async def _check_expired_sessions_if_due(self) -> None:
        now = time.monotonic()
        if not self._idle_compact_check_due(now):
            return
        self._next_idle_compact_check_at = now + self._idle_compact_check_interval_s
        self._idle_compact_check_running = True
        try:
            with self.bus.admission.activity():
                await self.auto_compact.check_expired(
                    self.schedule_background,
                    self.runtime_for_session,
                    active_session_keys=self._pending_queues.keys(),
                )
        except SessionOperationQueueFullError:
            logger.debug("Skipping idle archival while session storage is busy")
        finally:
            self._idle_compact_check_running = False

    async def run(self) -> None:
        """Run the agent loop, dispatching messages as tasks to stay responsive to /stop."""
        self._running = True
        try:
            logger.info("Agent loop started")

            while self._running:
                try:
                    # Keep dequeue and admission in this task. wait_for would
                    # dequeue in another task, leaving a false-idle handoff gap.
                    async with asyncio.timeout(1.0):
                        msg = await self.bus.consume_inbound()
                except asyncio.TimeoutError:
                    # Storage may wait behind a turn that /stop needs to cancel.
                    if self._idle_compact_check_due(time.monotonic()):
                        self.schedule_background(self._check_expired_sessions_if_due())
                    continue
                except asyncio.CancelledError:
                    # Preserve real task cancellation so shutdown can complete cleanly.
                    # Only ignore non-task CancelledError signals that may leak from integrations.
                    if not self._running or task_is_cancelling():
                        raise
                    logger.warning(
                        "Ignoring leaked CancelledError while consuming inbound messages"
                    )
                    continue
                except Exception as e:
                    logger.warning("Error consuming inbound message: {}, continuing...", e)
                    continue

                with self.bus.admission.activity():
                    try:
                        await self._dispatch_inbound(msg)
                    except (SessionOperationQueueFullError, SessionConflictError, ExecutionControlError) as exc:
                        key = self._effective_session_key(msg)
                        logger.warning("Session input rejected for {}: {}", key, exc)
                        if msg.is_user_input:
                            delivery = self.turn_delivery_factory.unrouted(msg, key)
                            await delivery.fail(publish_completion=key not in self._pending_queues)
        finally:
            await self.aclose()

    async def _dispatch_inbound(self, msg: InboundMessage) -> None:
        raw = command_text(msg)
        effective_key = self._effective_session_key(msg)
        if msg.metadata.get(INBOUND_META_RUNTIME_CONTROL) == RUNTIME_CONTROL_SESSION_DISCARD:
            await self.discard_session(msg.session_key)
            return
        if (
            msg.require_existing_session
            and await self.sessions.state.read_metadata(effective_key) is None
        ):
            return
        if msg.is_user_input:
            await self.runtime_event_publisher.user_input_accepted(msg, effective_key)
        if msg.channel != "system" and self.commands.is_priority(raw):
            await self._dispatch_command_inline(
                msg, effective_key, raw,
                self.commands.dispatch_priority,
            )
            return
        routed_msg = msg
        if effective_key != msg.session_key:
            routed_msg = dataclasses.replace(
                msg,
                session_key_override=effective_key,
            )
        # Mid-turn injection bypasses _dispatch_one, so admit before joining
        # an active queue. Admission may cancel its worker and release the queue.
        if (
            effective_key in self._pending_queues
            and self._recovery_admission is not None
            and not await self._recovery_admission.admit(routed_msg)
        ):
            return
        # If this session already has an active pending queue (i.e. a task
        # is processing this session), route the message there for mid-turn
        # injection instead of creating a competing task.
        if effective_key in self._pending_queues:
            if msg.channel != "system" and self.commands.is_dispatchable_command(raw):
                await self._dispatch_command_inline(
                    msg, effective_key, raw,
                    self.commands.dispatch,
                )
                return
        await self._enqueue_session_message(routed_msg)

    def maintenance(self) -> AbstractContextManager[None]:
        """Close task intake only when this runtime's accepted work is finished.

        The gateway shares the bus gate with cron and local trigger intake.
        This does not stop other processes or channel/configuration writes;
        those must be shut down before an updater takes a data backup.
        """
        return self.bus.admission.pause_if_idle(self._has_pending_work)

    def _has_pending_work(self) -> bool:
        return bool(
            self.bus.inbound_size or self._pending_queues or self._deferred_automation_turns
            or self.bus.has_pending_events or self._active_tasks or self._background_tasks
            or self._close_lock.locked()
            or self.subagents.has_pending_work or self._exec_session_manager.has_pending_work
        )

    def preserve_inflight_turns_on_shutdown(self) -> None:
        """Keep durable checkpoints when the owning gateway exits.

        Normal cancellation intentionally materializes partial output so a
        user-stopped turn leaves a readable conversation.  Gateway lifecycle
        shutdown is different: RecoveryCoordinator needs the checkpoint intact
        to safely offer the unfinished turn for explicit continuation later.
        """
        self._preserve_inflight_turns_on_shutdown = True

    async def _journal_pending_message(
        self,
        session_key: str,
        msg: InboundMessage,
    ) -> InboundMessage:
        if not self._can_inject_message(msg):
            return msg
        followup_id = await self.sessions.state.queue_followup(session_key, msg)
        if followup_id is None:
            return msg
        pending_msg = dataclasses.replace(
            msg,
            metadata={
                **msg.metadata,
                PENDING_FOLLOWUP_ID_KEY: followup_id,
            },
        )
        return pending_msg

    async def _enqueue_session_message(self, msg: InboundMessage) -> None:
        self.bus.admission.check()
        session_key = self._effective_session_key(msg)
        if not self.subagents.accepts_result(msg, session_key):
            return
        if session_key != msg.session_key:
            msg = dataclasses.replace(msg, session_key_override=session_key)

        for coordinator in self._automation_turn_coordinators:
            if coordinator.defer_if_active(
                msg,
                session_key=session_key,
                active_session_keys=self._pending_queues.keys(),
            ):
                return

        if session_key in self._pending_queues:
            msg = await self._journal_pending_message(session_key, msg)
        pending = self._pending_queues.get(session_key)
        if pending is not None:
            pending.put_nowait(msg)
            return

        new_pending: asyncio.Queue[InboundMessage] = asyncio.Queue()
        new_pending.put_nowait(msg)
        self._pending_queues[session_key] = new_pending
        task = asyncio.create_task(self._run_session_queue(session_key, new_pending))
        self._track_active_task(session_key, task)

    async def _run_session_queue(
        self,
        session_key: str,
        pending: asyncio.Queue[InboundMessage],
    ) -> None:
        try:
            while self._pending_queues.get(session_key) is pending:
                try:
                    item = pending.get_nowait()
                except asyncio.QueueEmpty:
                    # Idle-only automation follows all accepted user input on
                    # this same worker, including before the bus loop starts.
                    deferred = self._deferred_automation_turns.get(session_key)
                    if not deferred:
                        break
                    item = deferred.pop(0)
                    if not deferred:
                        self._deferred_automation_turns.pop(session_key)
                session = self.sessions.state.peek_header(session_key)
                log_content = session is None or (
                    session.policy.persist and session.policy.log_content
                )
                try:
                    await self._dispatch_one(item, pending)
                except asyncio.CancelledError as exc:
                    for coordinator in self._automation_turn_coordinators:
                        coordinator.complete(item, error=exc)
                    raise
                except Exception:
                    logger.opt(exception=log_content).error(
                        "Session worker failed one message for {}; continuing FIFO",
                        session_key,
                    )
        except asyncio.CancelledError as exc:
            await self._cancel_pending_messages(session_key, pending, exc)
            raise
        finally:
            owns_queue = self._pending_queues.get(session_key) is pending
            if owns_queue:
                self._pending_queues.pop(session_key, None)

    async def _cancel_pending_messages(
        self,
        session_key: str,
        pending: asyncio.Queue[InboundMessage],
        error: asyncio.CancelledError,
    ) -> None:
        for msg in self._deferred_automation_turns.pop(session_key, []):
            pending.put_nowait(msg)
        while not pending.empty():
            item = pending.get_nowait()
            for coordinator in self._automation_turn_coordinators:
                coordinator.complete(item, error=error)
            if item.channel != "system" and self.commands.requires_session_queue(command_text(item)):
                delivery = self.turn_delivery_factory.unrouted(item, session_key)
                await delivery.complete(None, publish_completion=True)

    async def _dispatch_one(
        self,
        msg: InboundMessage,
        pending: asyncio.Queue[InboundMessage],
    ) -> None:
        session_key = self._effective_session_key(msg)
        # The request context is reset before errors reach this boundary, and
        # discard may evict the session while a turn is still unwinding.
        session = self.sessions.state.peek_header(session_key)
        log_content = session is None or (
            session.policy.persist and session.policy.log_content
        )
        recovery_task_registered = False
        recovery_admission = self._recovery_admission
        current_task: asyncio.Task[Any] | None = None
        lock = self._get_session_lock(session_key)
        gate = self._concurrency_gate or nullcontext()

        delivery = self.turn_delivery_factory.unrouted(msg, session_key)
        processing = False
        skip_idle = False
        try:
            async with AsyncExitStack() as execution:
                try:
                    if recovery_admission is not None:
                        recovery_id = msg.metadata.get(RECOVERY_INBOUND_METADATA_KEY)
                        if isinstance(recovery_id, str) and recovery_id:
                            current_task = asyncio.current_task()
                            if current_task is not None:
                                recovery_admission.register_recovery_task(session_key, current_task)
                                recovery_task_registered = True
                        if not await recovery_admission.admit(msg):
                            logger.info("Skipped stale recovery for session {}", session_key)
                            return
                    await execution.enter_async_context(lock)
                    await execution.enter_async_context(gate)
                    processing = True
                    await self.sessions.state.read(session_key)
                    delivery = self.turn_delivery_factory.create(
                        msg,
                        session_key,
                        enable_stream=True,
                    )
                    response = await self._process_message(
                        msg,
                        pending_queue=pending,
                        delivery=delivery,
                    )
                    await delivery.complete(response, publish_completion=True)
                    for coordinator in self._automation_turn_coordinators:
                        coordinator.complete(msg, response=response)
                except asyncio.CancelledError as exc:
                    logger.info("Task cancelled for session {}", session_key)
                    if not processing:
                        if self.commands.requires_session_queue(command_text(msg)):
                            await delivery.complete(None, publish_completion=True)
                        raise
                    if delivery.completed:
                        raise exc
                    try:
                        await delivery.abort_stream()
                    except Exception:
                        logger.opt(exception=log_content).debug(
                            "Could not close stream for cancelled session {}",
                            session_key,
                        )
                    # An explicit turn stop materializes partial context so
                    # the next prompt can see completed tool results.  Gateway
                    # shutdown keeps the durable checkpoint untouched instead,
                    # allowing RecoveryCoordinator to offer Continue safely.
                    if (
                        session_key in self._discarding_sessions
                        or self._preserve_inflight_turns_on_shutdown
                    ):
                        raise exc
                    key = self._effective_session_key(msg)
                    generation = delivery.delivery_message.session_generation
                    try:
                        session = await self.sessions.state.read(key)
                        if session is None or (generation is not None and session.generation != generation):
                            self.runtime_event_publisher.clear_turn(session_key, run_id=delivery.run_id)
                            skip_idle = True
                            raise exc
                        restore_runtime_checkpoint(session)
                        await self.sessions.state.finish_turn(session)
                        logger.info("Saved cancelled turn for session {}", key)
                    except SessionConflictError:
                        current = await self.sessions.state.read_header(key)
                        if current is None or (generation is not None and current.generation != generation):
                            self.runtime_event_publisher.clear_turn(session_key, run_id=delivery.run_id)
                            skip_idle = True
                            raise asyncio.CancelledError() from None
                        logger.opt(exception=log_content).debug(
                            "Could not finalize cancelled turn for session {}", session_key,
                        )
                    except Exception:
                        logger.opt(exception=log_content).debug(
                            "Could not finalize cancelled turn for session {}",
                            session_key,
                        )
                    await delivery.cancelled()
                    raise exc
                except Exception as exc:
                    if isinstance(exc, SessionConflictError):
                        current = await self.sessions.state.read_header(session_key)
                        generation = delivery.delivery_message.session_generation
                        if current is None or (generation is not None and current.generation != generation):
                            self.runtime_event_publisher.clear_turn(session_key, run_id=delivery.run_id)
                            skip_idle = True
                            return
                    logger.opt(exception=log_content).error(
                        "Error processing message for session {}", session_key,
                    )
                    await delivery.fail(publish_completion=True)
                    for coordinator in self._automation_turn_coordinators:
                        coordinator.complete(msg, error=exc)
                finally:
                    if (processing or delivery.completed) and not skip_idle:
                        await delivery.idle()
        finally:
            if (
                recovery_task_registered
                and current_task is not None
                and recovery_admission is not None
            ):
                recovery_admission.unregister_recovery_task(session_key, current_task)

    async def aclose(self) -> None:
        """Stop active work, then close resources owned by the agent loop.

        Resource teardown must still run if cancellation interrupts task draining.
        Gateway shutdown deliberately bounds this coroutine, so keeping the cleanup
        phase in ``finally`` prevents a timed-out background task from leaving
        subprocess transports alive after the event loop closes.
        """
        # The loop closes itself from ``run()`` while application shutdown also
        # performs a guaranteed final close. Serialize those owners so they cannot
        # tear down the same resources concurrently.
        close_lock = getattr(self, "_close_lock", None)
        if close_lock is None:
            close_lock = self._close_lock = asyncio.Lock()
        async with close_lock:
            await self._aclose_unlocked()

    async def _aclose_unlocked(self) -> None:
        errors: list[BaseException] = []
        active_task_groups = getattr(self, "_active_tasks", {})
        current_task = asyncio.current_task()
        pending_queues = {
            key: self._pending_queues[key]
            for key, tasks in active_task_groups.items()
            if key in self._pending_queues and any(task is not current_task for task in tasks)
        }
        active_tasks = tuple({task for tasks in active_task_groups.values() for task in tasks})
        active_task_groups.clear()
        active_tasks = tuple(task for task in active_tasks if task is not current_task)
        for task in active_tasks:
            if not task.done():
                task.cancel()
        try:
            if active_tasks:
                await asyncio.gather(*active_tasks, return_exceptions=True)
            for key, pending in pending_queues.items():
                if self._pending_queues.get(key) is pending:
                    self._pending_queues.pop(key)
                    await self._cancel_pending_messages(key, pending, asyncio.CancelledError())
            # A scan can schedule archival while shutdown waits for it.
            while self._background_tasks:
                await asyncio.gather(*self._background_tasks, return_exceptions=True)
        except BaseException as exc:
            errors.append(exc)
        finally:
            self._background_tasks.clear()

        cleanup_steps = (
            self.subagents.close,
            self._exec_session_manager.close_all,
            self.runtime_resolver.aclose,
            self.sessions.state.aclose,
        )
        for cleanup in cleanup_steps:
            try:
                await cleanup()
            except BaseException as exc:
                errors.append(exc)
        if len(errors) == 1:
            raise errors[0]
        if errors:
            raise BaseExceptionGroup("failed to close agent resources", errors)

    def _background_task_done(self, task: asyncio.Task[Any]) -> None:
        self._background_tasks.discard(task)
        if task.cancelled():
            return
        exception = task.exception()
        if exception is not None:
            logger.opt(exception=exception).error(
                "Background task '{}' failed",
                task.get_name(),
            )

    def schedule_background(self, coro: Coroutine[Any, Any, Any]) -> None:
        """Schedule a coroutine as a tracked background task (drained on shutdown)."""
        try:
            self.bus.admission.check()
        except RuntimeMaintenanceError:
            coro.close()
            raise
        task = asyncio.create_task(coro)
        self._background_tasks.add(task)
        task.add_done_callback(self._background_task_done)

    def stop(self) -> None:
        """Stop the agent loop."""
        self._running = False
        logger.info("Agent loop stopping")

    async def _process_message(
        self,
        msg: InboundMessage,
        session_key: str | None = None,
        on_progress: Callable[..., Awaitable[None]] | None = None,
        on_stream: Callable[[str], Awaitable[None]] | None = None,
        on_stream_end: Callable[..., Awaitable[None]] | None = None,
        pending_queue: asyncio.Queue[InboundMessage] | None = None,
        ephemeral: bool = False,
        run_extra_hooks_for_ephemeral: bool = False,
        hooks: list[AgentHook] | None = None,
        hook_factories: list[AgentTurnHookFactory] | None = None,
        tools: ToolRegistry | None = None,
        runtime: LLMRuntime | None = None,
        delivery: TurnDelivery | None = None,
        on_runtime_admitted: Callable[[LLMRuntime], Awaitable[None]] | None = None,
        attributes: Mapping[str, Any] | None = None,
        session: Session | None = None,
    ) -> OutboundMessage | None:
        kind = TurnKind.USER if msg.is_user_input else TurnKind.SYSTEM
        if kind is TurnKind.SYSTEM:
            destination = (
                msg.chat_id.split(":", 1) if ":" in msg.chat_id else ("cli", msg.chat_id)
            )
            key = session_key or msg.session_key_override or f"{destination[0]}:{destination[1]}"
        else:
            key = session_key or msg.session_key
        if not self.subagents.accepts_result(msg, key):
            return None
        commit_session = session is None or session.policy.persist
        if session is None:
            session = (await self.sessions.state.read(key)
                       if msg.require_existing_session or msg.session_generation is not None
                       else await self.sessions.state.get(key))
        if msg.require_existing_session and session is None:
            raise RuntimeError("required session is not active")
        if msg.session_generation is not None and (
            session is None or session.generation != msg.session_generation
        ):
            raise RuntimeError("required session generation was replaced")
        if delivery is None:
            delivery = self.turn_delivery_factory.create(msg, key)
        elif delivery.session_key != key:
            raise ValueError("turn delivery session does not match the processing session")
        t0 = time.time()
        ctx = TurnContext(
            msg=msg,
            session=session,
            session_key=key,
            turn_id=f"{key}:{time.time_ns()}",
            runtime=runtime,
            kind=kind,
            delivery=delivery,
            original_user_text=(
                None
                if kind is TurnKind.SYSTEM
                or turn_continuation.internal_continuation_inbound(msg.metadata)
                else msg.content
            ),
            turn_wall_started_at=t0,
            events=output_events(
                default=delivery.events,
                on_progress=on_progress,
                on_stream=on_stream,
                on_stream_end=on_stream_end,
            ),
            streaming=on_stream is not None or delivery.streaming,
            on_runtime_admitted=on_runtime_admitted,
            pending_queue=pending_queue,
            ephemeral=ephemeral,
            commit_session=commit_session,
            run_extra_hooks_for_ephemeral=run_extra_hooks_for_ephemeral,
            hooks=list(hooks or []),
            hook_factories=list(hook_factories or []),
            tools=tools,
            attributes=dict(attributes or {}),
        )
        # A streaming callback may be present even when the final text comes from a
        # non-streaming recovery. Only the last completed segment can suppress the
        # regular outbound message.
        if ctx.streaming:
            publish = ctx.events.publish
            segment_streamed_content = False

            async def track_output(event: AgentEvent) -> None:
                nonlocal segment_streamed_content
                if isinstance(event, StreamDeltaEvent) and event.content:
                    segment_streamed_content = True
                elif isinstance(event, StreamEndEvent):
                    ctx.streamed_content = segment_streamed_content
                    segment_streamed_content = False
                if publish is not None:
                    await publish(event)

            ctx.events = EventSink(track_output, ctx.events.accepts)

        with logger.contextualize(turn_id=ctx.turn_id, session_key=ctx.session_key):
            await self._run_turn_stage(ctx, "restore", self._restore_turn)
            await self._run_turn_stage(ctx, "compact", self._compact_session)
            if await self._run_turn_stage(ctx, "command", self._dispatch_command):
                self._log_turn_completion(ctx, outcome="command")
                return ctx.outbound
            await self._run_turn_stage(ctx, "build", self._build_turn)
            await self._run_turn_stage(ctx, "run", self._run_turn)
            await self._run_turn_stage(ctx, "save", self._persist_turn)
            await self._run_turn_stage(ctx, "respond", self._prepare_outbound)
            self._log_turn_completion(ctx)
            return ctx.outbound

    async def _run_turn_stage(
        self,
        ctx: TurnContext,
        name: str,
        handler: Callable[[TurnContext], Awaitable[_T]],
    ) -> _T:
        started_at = time.perf_counter()
        try:
            result = await handler(ctx)
        except Exception:
            duration_ms = (time.perf_counter() - started_at) * 1000
            log_content = not ctx.ephemeral and (
                ctx.session is None
                or (ctx.session.policy.persist and ctx.session.policy.log_content)
            )
            logger.opt(exception=log_content).bind(
                event="turn_stage",
                stage=name,
                outcome="error",
                duration_ms=round(duration_ms, 1),
            ).error(
                "Stage {} failed after {:.1f}ms",
                name,
                duration_ms,
            )
            raise
        duration_ms = (time.perf_counter() - started_at) * 1000
        logger.bind(
            event="turn_stage",
            stage=name,
            outcome="success",
            duration_ms=round(duration_ms, 1),
        ).debug(
            "Stage {} completed in {:.1f}ms",
            name,
            duration_ms,
        )
        return result

    def _log_turn_completion(self, ctx: TurnContext, *, outcome: str | None = None) -> None:
        duration_ms = ctx.turn_latency_ms
        if duration_ms is None:
            duration_ms = max(0, round((time.time() - ctx.turn_wall_started_at) * 1000))
        runtime = ctx.runtime
        provider = runtime.provider.provider_name if runtime is not None else None
        model = runtime.model if runtime is not None else None
        response_preview = "[content hidden]"
        if (
            ctx.kind is TurnKind.USER
            and ctx.session is not None
            and not ctx.ephemeral
            and ctx.session.policy.persist
            and ctx.session.policy.log_content
            and ctx.final_content is not None
        ):
            response_preview = (
                f"{ctx.final_content[:120]}..."
                if len(ctx.final_content) > 120
                else ctx.final_content
            )
        final_outcome = outcome or ctx.stop_reason or "completed"
        logger.bind(
            event="turn_completed",
            outcome=final_outcome,
            duration_ms=duration_ms,
            provider=provider,
            model=model,
            channel=ctx.msg.channel,
            chat_id=ctx.msg.chat_id,
        ).info(
            "Turn completed channel={} chat_id={} outcome={} duration_ms={} "
            "provider={} model={} response={}",
            ctx.msg.channel,
            ctx.msg.chat_id,
            final_outcome,
            duration_ms,
            provider or "-",
            model or "-",
            response_preview,
        )

    def _assemble_outbound(
        self,
        msg: InboundMessage,
        final_content: str,
        stop_reason: str,
        streamed_content: bool,
        *,
        turn_latency_ms: int | None = None,
    ) -> OutboundMessage | None:
        event = None
        meta = dict(msg.metadata or {})
        if streamed_content and stop_reason not in {"error", "tool_error"}:
            event = StreamedResponseEvent()
        if turn_latency_ms is not None:
            meta["latency_ms"] = int(turn_latency_ms)

        return OutboundMessage(
            channel=msg.channel,
            chat_id=msg.chat_id,
            content=final_content,
            event=event,
            metadata=meta,
        )

    async def _restore_turn(self, ctx: TurnContext) -> None:
        msg = ctx.msg

        if ctx.kind is TurnKind.USER and msg.media:
            new_content, image_paths = reference_non_image_attachments(
                msg.content,
                msg.media,
            )
            ctx.msg = dataclasses.replace(msg, content=new_content, media=image_paths)
            msg = ctx.msg

        if ctx.session is None:
            if msg.require_existing_session or msg.session_generation is not None:
                ctx.session = await self.sessions.state.read(ctx.session_key)
                if ctx.session is None:
                    raise RuntimeError("required session is not active")
                if (
                    msg.session_generation is not None
                    and ctx.session.generation != msg.session_generation
                ):
                    raise RuntimeError("required session generation was replaced")
            else:
                ctx.session = await self.sessions.state.get(ctx.session_key)
        session = ctx.session
        await ctx.delivery.bind_session_generation(session.generation)
        ctx.ephemeral = ctx.ephemeral or not session.policy.persist
        tools = ctx.tools if ctx.tools is not None else self.tools
        if session.policy.disabled_tools:
            restricted = ToolRegistry()
            for name in tools.tool_names:
                tool = tools.get(name)
                if name not in session.policy.disabled_tools and tool:
                    restricted.register(tool)
            tools = restricted
        ctx.tools = tools

        if ctx.kind is TurnKind.SYSTEM:
            logger.info("Processing system message from {}", msg.sender_id)
        elif session.policy.log_content and not ctx.ephemeral:
            preview = msg.content[:80] + "..." if len(msg.content) > 80 else msg.content
            logger.info("Processing message from {}:{}: {}", msg.channel, msg.sender_id, preview)
        else:
            logger.info("Processing message from {}:{}: [content hidden]", msg.channel, msg.sender_id)

        self._remember_session_route(
            session,
            msg,
            delivery=ctx.delivery,
            is_user_turn=ctx.original_user_text is not None,
        )
        await ctx.delivery.started()
        if ctx.kind is TurnKind.USER:
            self.workspace_scopes.persist_message_scope(session, msg)

        if restore_runtime_checkpoint(session) and ctx.commit_session:
            await self.sessions.state.restore_interruption(session)
        if (
            RECOVERY_INBOUND_METADATA_KEY not in msg.metadata
            and restore_pending_interruption(session)
            and ctx.commit_session
        ):
            await self.sessions.state.restore_interruption(session)

    async def _compact_session(self, ctx: TurnContext) -> None:
        if not ctx.commit_session:
            return
        session = ctx.require_session()
        ctx.session, pending = await self.auto_compact.prepare_session(
            session,
            ctx.session_key,
        )
        ctx.pending_summary = pending

    async def _dispatch_command(self, ctx: TurnContext) -> bool:
        if ctx.kind is TurnKind.SYSTEM or ctx.msg.channel == "system":
            return False
        session = ctx.require_session()
        raw = command_text(ctx.msg)
        _, automation_metadata = automation_history_overrides(ctx.msg.metadata)
        is_user_turn = (
            ctx.original_user_text is not None
            and not automation_metadata
            and ctx.msg.channel != "system"
            and ctx.msg.sender_id != "subagent"
        )
        cmd_ctx = CommandContext(
            msg=ctx.msg,
            session=session,
            key=ctx.session_key,
            raw=raw,
            loop=self,
            runtime=ctx.runtime,
            is_user_turn=is_user_turn,
        )
        command_matched = self.commands.command_name(raw) is not None
        result = await self.commands.dispatch(cmd_ctx)
        if isinstance(result, CommandExpansion):
            result = await self._prepare_command_expansion(cmd_ctx, result)
        if isinstance(result, InboundMessage):
            ctx.msg = result
            result = None
            command_matched = False
        if result is not None:
            ctx.outbound = result
            if cmd_ctx.raw.lower() == "/new":
                current = await self.sessions.state.get_header(ctx.session_key)
                await ctx.delivery.bind_session_generation(current.generation)
            # Shortcut commands skip BUILD and SAVE, so we must persist the
            # turn here so WebUI history hydration after turn_end sees the
            # message.  Mark messages with _command so get_history can filter
            # them out of LLM context.  /new is excluded because it
            # intentionally clears the session.
            if cmd_ctx.raw.lower() != "/new" and ctx.commit_session:
                ctx.input_persisted_early = await self._persist_user_message_early(
                    ctx.msg, session, _command=True
                )
                session.add_message(
                    "assistant", result.content, _command=True
                )
                self._clear_pending_user_turn(session)
                await self.sessions.state.prepare_input(session)
                if not ctx.ephemeral:
                    await self.runtime_event_publisher.session_turn_persisted(
                        ctx.msg,
                        ctx.session_key,
                        turn_id=ctx.turn_id,
                        attributes=ctx.attributes,
                    )
            return True
        return command_matched

    async def _build_turn(self, ctx: TurnContext) -> None:
        session = ctx.require_session()
        runtime = ctx.runtime
        if runtime is None:
            runtime = await self.runtime_for_session(session)
            ctx.runtime = runtime
        if ctx.session_key.startswith("dream:"):
            logger.info(
                "Dream run using model={} (preset={})",
                runtime.model,
                runtime.model_preset or "default",
            )
        if ctx.on_runtime_admitted is not None:
            await ctx.on_runtime_admitted(runtime)
        is_subagent = ctx.kind is TurnKind.SYSTEM and ctx.msg.sender_id == "subagent"

        ctx.history = await self.runner.prepare_prompt(
            session.get_history, extend_to_user=is_subagent,
        )
        stored_state = session.provider_state
        subagent_followup_persisted = False
        if is_subagent:
            # Keep the durable internal delivery as an assistant record, but
            # present this completion to the model as fresh follow-up input.
            # Providers without assistant-prefill support drop trailing
            # assistant messages, so using the persisted record as the current
            # prompt would hide an independently dispatched subagent result.
            subagent_followup_persisted = self._persist_subagent_followup(
                session,
                ctx.msg,
            )
            if subagent_followup_persisted:
                logger.debug("Subagent result persisted for session {}", ctx.session_key)
                # Establish a durable, replay-safe baseline before any fallible
                # provider compatibility or prompt assembly work. A compatible
                # staged state replaces this in a second atomic save below.
                session.provider_state = None
                await self.sessions.state.prepare_input(session)
            ctx.input_persisted_early = True
        await ctx.delivery.runtime_admitted(runtime)

        ctx.request_context = await self._request_context_for_turn(ctx)
        if ctx.kind is TurnKind.USER:
            ctx.runtime_context_blocks = await self._resolve_runtime_context_for_turn(ctx)
        staged_provider_state = False
        if stored_state is not None and runtime.provider.can_resume_conversation_state(
            stored_state,
            runtime.model,
        ):
            current_provider_message = self.context.build_current_message(
                ctx.msg.content,
                media=ctx.msg.media if ctx.kind is TurnKind.USER and ctx.msg.media else None,
                runtime_context_blocks=ctx.runtime_context_blocks,
            )
            task_id = ctx.msg.metadata.get("subagent_task_id") if is_subagent else None
            already_staged = False
            if isinstance(task_id, str) and task_id:
                internal_meta = current_provider_message.get("_meta")
                current_provider_message["_meta"] = {
                    **(
                        cast(dict[str, Any], internal_meta)
                        if isinstance(internal_meta, dict)
                        else {}
                    ),
                    _SUBAGENT_PROVIDER_TASK_META: task_id,
                }
                already_staged = any(
                    isinstance(message.get("_meta"), dict)
                    and cast(dict[str, Any], message["_meta"]).get(
                        _SUBAGENT_PROVIDER_TASK_META
                    )
                    == task_id
                    for message in stored_state.pending_messages
                )
            ctx.provider_state = (
                stored_state
                if already_staged
                else stored_state.with_pending_messages([
                    *stored_state.pending_messages,
                    current_provider_message,
                ])
            )
            if (
                (not ctx.ephemeral or not session.policy.persist)
                and (ctx.kind is TurnKind.USER or subagent_followup_persisted)
            ):
                session.provider_state = ctx.provider_state
                staged_provider_state = True
        elif stored_state is not None:
            session.provider_state = None
        if ctx.kind is TurnKind.USER and ctx.commit_session:
            ctx.input_persisted_early = await self._persist_user_message_early(
                ctx.msg,
                session,
                runtime_context_blocks=ctx.runtime_context_blocks,
            )
            if staged_provider_state and not ctx.input_persisted_early:
                session.provider_state = stored_state
        elif subagent_followup_persisted and staged_provider_state:
            # Upgrade the replay-safe baseline to the resumable state before
            # prompt assembly and the first model checkpoint.
            await self.sessions.state.prepare_input(session)
        if not session.persisted and ctx.commit_session:
            await self.sessions.state.prepare_input(session)
        ctx.transcript_input = self._build_transcript_input(ctx)


    async def _run_turn(self, ctx: TurnContext) -> None:
        runtime = ctx.require_runtime()
        ctx.run_started_at = time.time()
        await ctx.delivery.running(started_at=ctx.run_started_at)
        assert ctx.transcript_input is not None
        with capture_message_deliveries() as message_sends:
            result = await self._run_agent_loop(
                ctx.transcript_input,
                runtime=runtime,
                streaming=ctx.streaming,
                session=ctx.session,
                pending_queue=ctx.pending_queue,
                ephemeral=ctx.ephemeral,
                run_extra_hooks_for_ephemeral=ctx.run_extra_hooks_for_ephemeral,
                hooks=ctx.hooks,
                hook_factories=ctx.hook_factories,
                tools=ctx.tools,
                request_context=ctx.request_context,
                provider_state=ctx.provider_state,
                initial_message=ctx.msg,
                events=ctx.events,
                commit_session=ctx.commit_session,
            )
        ctx.final_content = result.final_content
        ctx.all_messages = result.messages
        ctx.summary_checkpoint = result.summary_checkpoint
        ctx.provider_compaction_applied = result.provider_compaction_applied
        ctx.stop_reason = result.stop_reason
        ctx.failure_error_kind = result.failure_error_kind
        if (
            ctx.kind is TurnKind.USER
            and (ctx.delivery.route.channel, ctx.delivery.route.chat_id) in message_sends
            and (not result.had_injections or result.stop_reason == "empty_final_response")
        ):
            ctx.suppress_response = True
        ctx.usage = result.usage
        ctx.delivery.record_usage(result.round_usages)

    async def _persist_turn(self, ctx: TurnContext) -> None:
        session = ctx.require_session()

        if (
            ctx.kind is TurnKind.USER
            and (ctx.final_content is None or not ctx.final_content.strip())
            and not ctx.suppress_response
        ):
            ctx.final_content = EMPTY_FINAL_RESPONSE_MESSAGE

        latency_started_at = (
            ctx.run_started_at
            if ctx.kind is TurnKind.SYSTEM or turn_continuation.internal_continuation_inbound(ctx.msg.metadata)
            else ctx.turn_wall_started_at
        )
        ctx.turn_latency_ms = max(0, int((time.time() - latency_started_at) * 1000))
        ctx.delivery.record_latency(ctx.turn_latency_ms)
        assert ctx.transcript_input is not None
        ctx.save_skip = turn_continuation.save_skip_for_turn(
            message_metadata=ctx.msg.metadata,
            initial_message_count=ctx.transcript_input.message_count,
            input_persisted_early=ctx.input_persisted_early,
        )
        if ctx.usage is not None and not ctx.ephemeral:
            session.metadata["_last_usage"] = ctx.usage.to_dict()
        if ctx.kind is TurnKind.USER and not ctx.ephemeral:
            turn_continuation.record_iteration_limit(
                session.metadata, ctx.stop_reason,
            )
        self._save_turn(
            session, ctx.all_messages, ctx.save_skip,
            turn_latency_ms=ctx.turn_latency_ms,
            summary_checkpoint=None if ctx.ephemeral else ctx.summary_checkpoint,
            input_persisted_early=ctx.input_persisted_early,
        )
        if (
            not ctx.ephemeral
            and ctx.provider_compaction_applied
            and ctx.summary_checkpoint is not None
        ):
            # The next request must rebuild from the portable checkpoint;
            # the opaque continuation predates that transcript rewrite.
            session.provider_state = None
        self._clear_pending_user_turn(session)
        self._clear_runtime_checkpoint(session)
        if ctx.commit_session:
            await self.sessions.state.finish_turn(session)
        if not ctx.ephemeral:
            await self.runtime_event_publisher.session_turn_persisted(
                ctx.msg,
                ctx.session_key,
                turn_id=ctx.turn_id,
                attributes=ctx.attributes,
            )

    async def _prepare_outbound(self, ctx: TurnContext) -> None:
        ctx.delivery.record_stop_reason(
            ctx.stop_reason,
            failure_error_kind=ctx.failure_error_kind,
        )
        if ctx.suppress_response:
            ctx.outbound = None
            return
        if ctx.kind is TurnKind.SYSTEM:
            ctx.outbound = ctx.delivery.background_response(
                ctx.final_content,
                stop_reason=ctx.stop_reason,
                streamed=ctx.streamed_content,
                latency_ms=ctx.turn_latency_ms,
            )
            return
        ctx.outbound = self._assemble_outbound(
            ctx.delivery.delivery_message,
            cast(str, ctx.final_content),
            ctx.stop_reason,
            ctx.streamed_content,
            turn_latency_ms=ctx.turn_latency_ms,
        )
        if ctx.ephemeral and ctx.outbound is not None:
            ctx.outbound.metadata["_stop_reason"] = ctx.stop_reason

    def _sanitize_persisted_blocks(
        self,
        content: list[object],
    ) -> list[object]:
        filtered: list[object] = []
        for block in content:
            if not isinstance(block, dict):
                filtered.append(block)
                continue

            block_data = cast(dict[str, Any], block)
            image_url = cast(dict[str, Any], block_data.get("image_url", {}))
            if block_data.get("type") == "image_url" and str(
                image_url.get("url", "")
            ).startswith("data:image/"):
                internal_meta = cast(dict[str, Any], block_data.get("_meta") or {})
                path = cast(str, internal_meta.get("path", ""))
                reference = {"type": "text", "text": image_placeholder_text(path)}
                if not filtered or filtered[-1] != reference:
                    filtered.append(reference)
                continue

            filtered.append(block_data)

        return filtered

    @staticmethod
    def _validated_checkpoint_boundary(
        checkpoint: SessionSummaryCheckpoint | None,
        *,
        skip: int,
        message_count: int,
        session_key: str,
    ) -> int | None:
        """Return a checkpoint boundary only when it belongs to this turn."""
        if checkpoint is None:
            return None
        boundary = checkpoint.transcript_boundary
        if skip - 1 <= boundary <= message_count:
            return boundary
        logger.warning(
            "Ignoring invalid summary boundary {} outside [{}, {}] for {}",
            boundary,
            skip - 1,
            message_count,
            session_key,
        )
        return None

    def _save_turn(
        self,
        session: Session,
        messages: list[dict[str, Any]],
        skip: int,
        *,
        turn_latency_ms: int | None = None,
        summary_checkpoint: SessionSummaryCheckpoint | None = None,
        input_persisted_early: bool = False,
    ) -> None:
        declared_tool_call_ids = {
            str(tc["id"])
            for m in session.messages
            if m.get("role") == "assistant"
            for tc_value in cast(Iterable[object], m.get("tool_calls") or [])
            if isinstance(tc_value, dict)
            for tc in (cast(dict[str, Any], tc_value),)
            if tc.get("id")
        }
        fulfilled_tool_call_ids = {
            str(m["tool_call_id"])
            for m in session.messages
            if m.get("role") == "tool" and m.get("tool_call_id")
        }
        last_assistant_idx: int | None = None
        saved_followup_ids: set[str] = set()
        checkpoint_boundary = self._validated_checkpoint_boundary(
            summary_checkpoint,
            skip=skip,
            message_count=len(messages),
            session_key=session.key,
        )

        # The trigger input may already be the session tail while still being
        # the first message after the replacement checkpoint.
        if summary_checkpoint is not None and checkpoint_boundary == skip - 1:
            insert_at = len(session.messages) - (1 if input_persisted_early else 0)
            session.commit_summary_checkpoint(
                summary_checkpoint.summary,
                insert_at=insert_at,
            )

        for message_index, message in enumerate(messages[skip:], start=skip):
            # Insert against the raw transcript index before filtering the
            # message so persistence cleanup cannot shift the H/Δ boundary.
            if summary_checkpoint is not None and checkpoint_boundary == message_index:
                session.commit_summary_checkpoint(summary_checkpoint.summary)

            entry = dict(message)
            followup_id = entry.pop(PENDING_FOLLOWUP_ID_KEY, None)
            internal_meta = cast(object, entry.pop("_meta", None))
            runtime_context_meta = (
                cast(dict[str, Any], internal_meta).get(
                    RUNTIME_CONTEXT_MESSAGE_META
                )
                if isinstance(internal_meta, dict)
                else None
            )
            role, content = entry.get("role"), entry.get("content")
            if role == "assistant" and not content and not entry.get("tool_calls"):
                continue  # skip empty assistant messages — they poison session context
            if role == "tool":
                tool_call_id = entry.get("tool_call_id")
                tool_call_id_str = str(tool_call_id) if tool_call_id else ""
                if (
                    not tool_call_id_str
                    or tool_call_id_str not in declared_tool_call_ids
                    or tool_call_id_str in fulfilled_tool_call_ids
                ):
                    # Undeclared tool results corrupt future provider requests.
                    logger.warning(
                        "Dropping invalid tool result {} from session {} during persistence",
                        tool_call_id_str or "(missing id)",
                        session.key,
                    )
                    continue
                fulfilled_tool_call_ids.add(tool_call_id_str)
                # Preserve model-visible text for replay; redact only inline images.
                if isinstance(content, list):
                    filtered = self._sanitize_persisted_blocks(
                        cast(list[object], content),
                    )
                    if not filtered:
                        # Preserve the tool_call/result pair after block filtering.
                        filtered = [
                            {"type": "text", "text": "[tool result omitted during persistence]"}
                        ]
                    entry["content"] = filtered
            elif role == "user":
                if isinstance(content, list):
                    filtered = self._sanitize_persisted_blocks(
                        cast(list[object], content),
                    )
                    if not filtered:
                        continue
                    entry["content"] = filtered
                if isinstance(runtime_context_meta, dict):
                    entry[RUNTIME_CONTEXT_HISTORY_META] = runtime_context_meta
                if isinstance(internal_meta, dict):
                    for key in ("timestamp", INBOUND_META_TURN_ID):
                        value = cast(dict[str, Any], internal_meta).get(key)
                        if isinstance(value, str) and value:
                            entry[key] = value
            entry.setdefault("timestamp", datetime.now().isoformat())
            session.messages.append(entry)
            if role == "user" and isinstance(followup_id, str) and followup_id:
                saved_followup_ids.add(followup_id)
            if role == "assistant":
                last_assistant_idx = len(session.messages) - 1
                declared_tool_call_ids.update(
                    str(tc["id"])
                    for tc_value in cast(
                        Iterable[object],
                        entry.get("tool_calls") or [],
                    )
                    if isinstance(tc_value, dict)
                    for tc in (cast(dict[str, Any], tc_value),)
                    if tc.get("id")
                )
        if summary_checkpoint is not None and checkpoint_boundary == len(messages):
            session.commit_summary_checkpoint(summary_checkpoint.summary)
        if turn_latency_ms is not None and last_assistant_idx is not None:
            session.messages[last_assistant_idx]["latency_ms"] = int(turn_latency_ms)
        session.consumed_followup_ids |= saved_followup_ids
        session.updated_at = datetime.now()

    def _persist_subagent_followup(self, session: Session, msg: InboundMessage) -> bool:
        if not msg.content:
            return False
        metadata_value = cast(object, msg.metadata)
        task_id = (
            msg.metadata.get("subagent_task_id")
            if isinstance(metadata_value, dict)
            else None
        )
        if task_id and any(
            m.get("injected_event") == "subagent_result" and m.get("subagent_task_id") == task_id
            for m in session.messages
        ):
            return False
        session.add_message(
            "assistant",
            msg.content,
            sender_id=msg.sender_id,
            injected_event="subagent_result",
            subagent_task_id=task_id,
        )
        return True

    async def _set_runtime_checkpoint(
        self,
        session: Session,
        payload: dict[str, Any],
    ) -> None:
        await self.sessions.state.checkpoint_view(session, payload)

    def _mark_pending_user_turn(self, session: Session) -> None:
        session.metadata[self._PENDING_USER_TURN_KEY] = True

    def _clear_pending_user_turn(self, session: Session) -> None:
        session.metadata.pop(self._PENDING_USER_TURN_KEY, None)

    def _clear_runtime_checkpoint(self, session: Session) -> None:
        if self._RUNTIME_CHECKPOINT_KEY in session.metadata:
            session.metadata.pop(self._RUNTIME_CHECKPOINT_KEY, None)

    async def process_direct(
        self,
        content: str,
        session_key: str = "cli:direct",
        channel: str = "cli",
        chat_id: str = "direct",
        sender_id: str = "user",
        media: list[str] | None = None,
        on_progress: Callable[..., Awaitable[None]] | None = None,
        on_stream: Callable[[str], Awaitable[None]] | None = None,
        on_stream_end: Callable[..., Awaitable[None]] | None = None,
        ephemeral: bool = False,
        _run_extra_hooks_for_ephemeral: bool = False,
        hooks: list[AgentHook] | None = None,
        hook_factories: list[AgentTurnHookFactory] | None = None,
        tools: ToolRegistry | None = None,
        persist_user_message: bool = True,
        runtime: LLMRuntime | None = None,
        on_runtime_admitted: Callable[[LLMRuntime], Awaitable[None]] | None = None,
        attributes: Mapping[str, Any] | None = None,
        _session_policy: SessionPolicy | None = None,
    ) -> OutboundMessage | None:
        """Process an external message directly and return the outbound payload.

        ``ephemeral`` skips Memory journaling and extra hooks. SDK temporary
        turns also supply a non-persistent policy for a detached session.
        """
        if channel == "system":
            raise ValueError("channel 'system' is reserved for internal messages")
        metadata: dict[str, Any] = {}
        if not persist_user_message:
            metadata[turn_continuation.SKIP_USER_PERSIST_META] = True
        msg = InboundMessage(
            channel=channel, sender_id=sender_id, chat_id=chat_id,
            content=content, media=media or [], metadata=metadata,
        )
        # Share the dispatch lock so direct calls serialize with bus turns.
        lock = self._get_session_lock(session_key)
        with self.bus.admission.activity():
            temporary_parent = False
            delivery: TurnDelivery | None = None
            try:
                async with lock:
                    kwargs: dict[str, Any] = {
                        "session_key": session_key,
                        "on_progress": on_progress,
                        "on_stream": on_stream,
                        "on_stream_end": on_stream_end,
                        "ephemeral": ephemeral,
                    }
                    if _session_policy is not None:
                        # Isolate per-run state before any early save or checkpoint;
                        # the cached conversation must survive a temporary SDK turn.
                        session = (await self.sessions.state.read(session_key) or Session(key=session_key)
                                   if not _session_policy.persist
                                   else await self.sessions.state.get(session_key))
                        temporary_parent = not _session_policy.persist and not session.persisted
                        session.policy = SessionPolicy(
                            persist=session.policy.persist and _session_policy.persist,
                            log_content=session.policy.log_content and _session_policy.log_content,
                            disabled_tools=session.policy.disabled_tools | _session_policy.disabled_tools,
                        )
                        kwargs["session"] = session
                    if _run_extra_hooks_for_ephemeral:
                        kwargs["run_extra_hooks_for_ephemeral"] = True
                    if hooks is not None:
                        kwargs["hooks"] = hooks
                    if hook_factories is not None:
                        kwargs["hook_factories"] = hook_factories
                    if tools is not None:
                        kwargs["tools"] = tools
                    if runtime is not None:
                        kwargs["runtime"] = runtime
                    if on_runtime_admitted is not None:
                        kwargs["on_runtime_admitted"] = on_runtime_admitted
                    if attributes is not None:
                        kwargs["attributes"] = dict(attributes)
                    delivery = self.turn_delivery_factory.create(msg, session_key)
                    kwargs["delivery"] = delivery
                    try:
                        return await self._process_message(msg, **kwargs)
                    finally:
                        if temporary_parent:
                            parent = self.sessions.state.peek_header(session_key)
                            if parent is not None and not parent.policy.persist:
                                await self.sessions.state.delete(session_key, expected_generation=parent.generation)
            finally:
                await self.runtime_event_publisher.run_status_changed(msg, session_key, "idle")
                if delivery is not None:
                    self.runtime_event_publisher.clear_turn(session_key, run_id=delivery.run_id)

    def _get_session_lock(self, session_key: str) -> asyncio.Lock:
        lock = self._session_locks.get(session_key)
        if lock is None:
            lock = asyncio.Lock()
            self._session_locks[session_key] = lock
        return lock
