"""
Provider Registry — single source of truth for LLM provider metadata.

Adding a new provider:
  1. Add a ProviderSpec to PROVIDERS below.
  2. Add a field to ProvidersConfig in config/schema.py.
  Done. Env vars, config matching, status display all derive from here.

Order matters — it controls match priority and fallback. Gateways first.
Every entry writes out all fields so you can copy-paste as a template.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pydantic.alias_generators import to_snake

from nanobot.providers.model_api import ModelAPICapabilities as ModelAPICapabilities
from nanobot.providers.model_api import ProviderAPI as ProviderAPI
from nanobot.providers.model_api import RequestAPI as RequestAPI
from nanobot.providers.model_api import ResponsesCapabilities as ResponsesCapabilities
from nanobot.providers.model_api import hosted_web_search_enabled as hosted_web_search_enabled
from nanobot.providers.model_api import is_direct_openai_base as is_direct_openai_base
from nanobot.providers.model_api import is_hosted_web_search_tool as is_hosted_web_search_tool
from nanobot.providers.model_api import is_hosted_web_search_type as is_hosted_web_search_type


@dataclass(frozen=True)
class ProviderModelSpec:
    """Curated model metadata used for fixed catalogs or online fallback."""

    id: str
    label: str = ""
    description: str = ""
    owned_by: str = ""
    context_window: int | None = None
    reasoning_efforts: tuple[str, ...] = ()
    supports_backend_search: bool = False
    api: ModelAPICapabilities | None = None
    aliases: tuple[str, ...] = ()
    max_output_tokens: int | None = None
    input_modalities: tuple[str, ...] = ()
    output_modalities: tuple[str, ...] = ()
    default_reasoning_effort: str | None = None


@dataclass(frozen=True)
class ProviderSpec:
    """One LLM provider's metadata. See PROVIDERS below for real examples.

    Placeholders in env_extras values:
      {api_key}  — the user's API key
      {api_base} — api_base from config, or this spec's default_api_base
    """

    name: str  # config field name, e.g. "dashscope"
    keywords: tuple[str, ...]  # model-name keywords for matching (lowercase)
    env_key: str  # env var for API key, e.g. "DASHSCOPE_API_KEY"
    # Request formats available through this provider's adapters. Remote model
    # support is separate: an adapter does not guarantee endpoint support.
    request_apis: tuple[ProviderAPI, ...]
    display_name: str = ""  # shown in `nanobot status`
    model_catalog: str = "auto"  # WebUI model-list source, including builtin/hybrid
    builtin_models: tuple[ProviderModelSpec, ...] = ()
    settings_alias_for: str = ""  # compatibility alias grouped under this provider in Settings

    # "openai_compat" | "anthropic" | "azure_openai" | "openai_codex" | "xai_grok"
    # | "github_copilot" | "bedrock"
    backend: str = "openai_compat"

    # extra env vars / request headers supplied by the provider integration.
    env_extras: tuple[tuple[str, str], ...] = ()
    default_extra_headers: tuple[tuple[str, str], ...] = ()

    is_gateway: bool = False  # routes any model (OpenRouter, AiHubMix)
    is_local: bool = False  # local deployment (vLLM, Ollama)
    detect_by_key_prefix: str = ""  # match api_key prefix, e.g. "sk-or-"
    detect_by_base_keyword: str = ""  # match substring in api_base URL
    default_api_base: str = ""

    strip_model_prefix: bool = False  # strip "provider/" before sending to gateway
    strip_model_prefixes: tuple[str, ...] = ()  # strip only when the first model segment matches
    supports_max_completion_tokens: bool = False

    model_overrides: tuple[tuple[str, dict[str, Any]], ...] = ()

    # OAuth-based providers (e.g., OpenAI Codex) don't use API keys
    is_oauth: bool = False

    # Direct providers skip API-key validation (user supplies everything)
    is_direct: bool = False

    # Provider is listed for shared credentials but cannot serve chat completions.
    is_transcription_only: bool = False

    # Provider supports cache_control on content blocks (e.g. Anthropic prompt caching)
    supports_prompt_caching: bool = False

    # How to inject the thinking on/off toggle into extra_body.
    # ""              — no extra_body needed (default)
    # "thinking_type" — {"thinking": {"type": "enabled"/"disabled"}}
    #                   (DeepSeek, VolcEngine, BytePlus)
    # "enable_thinking" — {"enable_thinking": true/false}  (DashScope)
    # "reasoning_split" — {"reasoning_split": true/false}  (MiniMax)
    thinking_style: str = ""

    # Gateway-native reasoning control to pair with model-level thinking styles.
    # "reasoning_effort" — {"reasoning": {"effort": <none|minimal|...>}}
    #                      (OpenRouter)
    gateway_reasoning_style: str = ""

    # When True, treat the "reasoning" response field as formal content
    # when "content" is empty.  Only set this for providers (e.g. StepFun)
    # whose API returns the actual answer in "reasoning" instead of "content".
    reasoning_as_content: bool = False

    # Map user-supplied reasoning_effort (OpenAI vocab: minimal/low/medium/high)
    # to the value this provider accepts on the wire. Set when the provider's
    # accepted set differs from OpenAI's. An empty mapped value omits the kwarg.
    # Mistral: only "high"/"none" — low/minimal map to "none", medium maps to "high".
    reasoning_effort_remap: tuple[tuple[str, str], ...] = ()

    # Models whose API rejects the reasoning_effort kwarg because reasoning is
    # implicit (Magistral always reasons; sending the kwarg returns HTTP 400).
    # Substring match against the wire model name (lowercased).
    implicit_reasoning_models: tuple[str, ...] = ()

    # Capabilities for providers/models served through the shared Responses path.
    responses: ResponsesCapabilities | None = None

    # When the model returns content as a list of {"type":"thinking",...} +
    # {"type":"text",...} blocks, extract the thinking text into
    # reasoning_content. Mistral's Magistral / reasoning-enabled responses use
    # this shape.
    extract_thinking_blocks: bool = False

    # Strip ``reasoning_content`` from assistant history messages before
    # sending. Mistral validates its request schema strictly and 400s on
    # any extra fields; other providers (DeepSeek) require this key on the
    # wire to keep thinking-mode history intact.
    strip_history_reasoning_content: bool = False

    @property
    def label(self) -> str:
        return self.display_name or self.name.title()

    def request_model_name(self, model: str) -> str:
        """Remove only the provider prefixes owned by this adapter."""
        if "/" not in model:
            return model
        if self.strip_model_prefix:
            return model.rsplit("/", 1)[-1]
        prefix, routed_model = model.split("/", 1)
        prefix_key = to_snake(prefix.replace("-", "_")).lower()
        if any(
            to_snake(value.replace("-", "_")).lower() == prefix_key
            for value in self.strip_model_prefixes
        ):
            return routed_model
        return model

    def model_metadata(self, model: str) -> ProviderModelSpec | None:
        """Look up curated metadata without rewriting configured or wire model IDs."""
        model_id = model.rsplit("/", 1)[-1].lower()
        return next((
            entry for entry in self.builtin_models
            if model_id == entry.id or model_id in entry.aliases
        ), None)

    def default_model_api(
        self,
        model: str,
        reasoning_effort: str | None = None,
        *,
        api_base: str | None = None,
        extra_body: dict[str, Any] | None = None,
    ) -> ModelAPICapabilities:
        """Resolve automatic API defaults without constructing or probing a client."""
        if self.responses is None:
            return ModelAPICapabilities()
        return self.responses.default_model_api(
            self.request_model_name(model), reasoning_effort,
            api_base=api_base, default_api_base=self.default_api_base,
            extra_body=extra_body,
        )

    @property
    def provider_api_configurable(self) -> bool:
        return self.name == "openai" or (
            self.is_direct and self.backend == "openai_compat" and "anthropic_messages" in self.request_apis
        )

    def validate_model_api(self, api: ModelAPICapabilities) -> None:
        unsupported = set(api.supported_apis).difference(self.request_apis)
        if unsupported:
            raise ValueError(
                f"Provider '{self.label}' does not support {', '.join(sorted(unsupported))}. "
                f"Available request APIs: {', '.join(self.request_apis)}."
            )


# PROVIDERS — the registry. Order = priority. Copy any entry as template.

KIMI_K3_MODELS: frozenset[str] = frozenset({
    "kimi-k3",
    "kimi-k3.1-pro",
    "kimi-k3.1-pro-highspeed",
})

_DEEPSEEK_REASONING_EFFORTS = ("none", "low", "high", "max")

PROVIDERS: tuple[ProviderSpec, ...] = (
    ProviderSpec(
        name="custom",
        keywords=(),
        env_key="",
        request_apis=("chat_completions", "responses", "anthropic_messages"),
        display_name="Custom",
        backend="openai_compat",
        is_direct=True,
    ),

    ProviderSpec(
        name="azure_openai",
        keywords=("azure", "azure-openai"),
        env_key="",
        request_apis=("responses",),
        display_name="Azure OpenAI",
        backend="azure_openai",
        is_direct=True,
    ),
    ProviderSpec(
        name="bedrock",
        keywords=(
            "bedrock",
            "anthropic.claude",
            "amazon.nova",
            "meta.",
            "mistral.",
            "cohere.",
            "qwen.",
            "deepseek.",
            "openai.gpt-oss",
            "ai21.",
            "moonshot.",
            "writer.",
            "zai.",
        ),
        env_key="AWS_BEARER_TOKEN_BEDROCK",
        request_apis=("bedrock_converse",),
        display_name="AWS Bedrock",
        backend="bedrock",
        is_direct=True,
    ),
    # Gateways can route any model, so they win in fallback.
    ProviderSpec(
        name="openrouter",
        keywords=("openrouter",),
        env_key="OPENROUTER_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="OpenRouter",
        backend="openai_compat",
        is_gateway=True,
        detect_by_key_prefix="sk-or-",
        detect_by_base_keyword="openrouter",
        default_api_base="https://openrouter.ai/api/v1",
        supports_prompt_caching=True,
        gateway_reasoning_style="reasoning_effort",
    ),
    ProviderSpec(
        name="orcarouter",
        keywords=("orcarouter",),
        env_key="ORCAROUTER_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="OrcaRouter",
        backend="openai_compat",
        is_gateway=True,
        detect_by_key_prefix="sk-orca-",
        detect_by_base_keyword="orcarouter",
        default_api_base="https://api.orcarouter.ai/v1",
    ),
    # Eden AI: OpenAI-compatible gateway. Models use the "provider/model"
    # naming scheme (e.g. "anthropic/claude-sonnet-4-5"); the full id is sent upstream.
    ProviderSpec(
        name="edenai",
        keywords=("edenai",),
        env_key="EDENAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Eden AI",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="edenai",
        default_api_base="https://api.edenai.run/v3",
    ),
    # OpenCode Zen: OpenAI-compatible chat-completions gateway for coding models.
    # models.dev/OpenCode use provider id "opencode" and model ids like
    # "opencode/<model>"; send the bare model upstream.
    ProviderSpec(
        name="opencode",
        keywords=("opencode/", "opencode", "opencode-zen", "opencode_zen"),
        env_key="OPENCODE_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="OpenCode Zen",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="opencode.ai/zen",
        default_api_base="https://opencode.ai/zen/v1",
        strip_model_prefixes=("opencode", "opencode_zen", "opencode-zen"),
    ),
    # Compatibility alias for configs that already used providers.opencodeZen.
    ProviderSpec(
        name="opencode_zen",
        keywords=("opencode/", "opencode_zen", "opencode-zen"),
        env_key="OPENCODE_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="OpenCode Zen",
        settings_alias_for="opencode",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="opencode.ai/zen",
        default_api_base="https://opencode.ai/zen/v1",
        strip_model_prefixes=("opencode", "opencode_zen", "opencode-zen"),
    ),
    # OpenCode Go: low-cost gateway with model-specific request API routing.
    # OpenCode's own config uses "opencode-go/<model>"; send the bare model upstream.
    ProviderSpec(
        name="opencode_go",
        keywords=("opencode-go", "opencode_go"),
        env_key="OPENCODE_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="OpenCode Go",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="opencode.ai/zen/go",
        default_api_base="https://opencode.ai/zen/go/v1",
        strip_model_prefixes=("opencode-go", "opencode_go"),
        responses=ResponsesCapabilities(
            models=("muse-spark-1.2-contributor", "muse-spark-1.3-contributor"),
            allows_chat_fallback=False,
        ),
    ),
    ProviderSpec(
        name="huggingface",
        keywords=("huggingface", "hugging-face"),
        env_key="HF_TOKEN",
        request_apis=("chat_completions", "responses"),
        display_name="Hugging Face",
        backend="openai_compat",
        is_gateway=True,
        detect_by_key_prefix="hf_",
        detect_by_base_keyword="huggingface",
        default_api_base="https://router.huggingface.co/v1",
    ),
    ProviderSpec(
        name="skywork",
        keywords=("skywork", "skyclaw", "apifree"),
        env_key="SKYWORK_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Skywork",
        model_catalog="official",
        backend="openai_compat",
        env_extras=(("APIFREE_API_KEY", "{api_key}"),),
        is_gateway=True,
        detect_by_base_keyword="apifree.ai",
        default_api_base="https://api.apifree.ai/agent/v1",
    ),
    # strip_model_prefix=True: doesn't understand "anthropic/claude-3",
    # strips to bare "claude-3".
    ProviderSpec(
        name="aihubmix",
        keywords=("aihubmix",),
        env_key="OPENAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="AiHubMix",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="aihubmix",
        default_api_base="https://aihubmix.com/v1",
        strip_model_prefix=True,
    ),
    # SiliconFlow (硅基流动): OpenAI-compatible gateway, model names keep org prefix
    ProviderSpec(
        name="siliconflow",
        keywords=("siliconflow",),
        env_key="OPENAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="SiliconFlow",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="siliconflow",
        default_api_base="https://api.siliconflow.cn/v1",
    ),

    ProviderSpec(
        name="novita",
        keywords=("novita",),
        env_key="NOVITA_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Novita AI",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="novita",
        default_api_base="https://api.novita.ai/openai",
    ),

    ProviderSpec(
        name="volcengine",
        keywords=("volcengine", "volces", "ark"),
        env_key="OPENAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="VolcEngine",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="volces",
        default_api_base="https://ark.cn-beijing.volces.com/api/v3",
        thinking_style="thinking_type",
        supports_max_completion_tokens=True,
    ),

    # VolcEngine Coding Plan (火山引擎 Coding Plan): same key as volcengine
    ProviderSpec(
        name="volcengine_coding_plan",
        keywords=("volcengine-plan",),
        env_key="OPENAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="VolcEngine Coding Plan",
        backend="openai_compat",
        is_gateway=True,
        default_api_base="https://ark.cn-beijing.volces.com/api/coding/v3",
        strip_model_prefix=True,
        thinking_style="thinking_type",
        supports_max_completion_tokens=True,
    ),

    ProviderSpec(
        name="byteplus",
        keywords=("byteplus",),
        env_key="OPENAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="BytePlus",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="bytepluses",
        default_api_base="https://ark.ap-southeast.bytepluses.com/api/v3",
        strip_model_prefix=True,
        thinking_style="thinking_type",
    ),

    # BytePlus Coding Plan: same key as byteplus
    ProviderSpec(
        name="byteplus_coding_plan",
        keywords=("byteplus-plan",),
        env_key="OPENAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="BytePlus Coding Plan",
        backend="openai_compat",
        is_gateway=True,
        default_api_base="https://ark.ap-southeast.bytepluses.com/api/coding/v3",
        strip_model_prefix=True,
        thinking_style="thinking_type",
    ),


    ProviderSpec(
        name="anthropic",
        keywords=("anthropic", "claude"),
        env_key="ANTHROPIC_API_KEY",
        request_apis=("anthropic_messages",),
        display_name="Anthropic",
        backend="anthropic",
        supports_prompt_caching=True,
    ),
    # OpenAI: SDK default base URL (no override needed)
    ProviderSpec(
        name="openai",
        keywords=("openai", "gpt"),
        env_key="OPENAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="OpenAI",
        backend="openai_compat",
        supports_max_completion_tokens=True,
        responses=ResponsesCapabilities(
            model_prefixes=("gpt-5", "gpt-6", "o1", "o3", "o4"),
            route_reasoning=True,
            requires_direct_openai_base=True,
            reasoning_replay="encrypted",
            supports_native_compaction=True,
        ),
    ),
    ProviderSpec(
        name="openai_codex",
        keywords=("openai-codex",),
        env_key="",
        request_apis=("responses",),
        display_name="OpenAI Codex",
        model_catalog="hybrid",
        builtin_models=(
            ProviderModelSpec(
                id="openai-codex/gpt-5.6-sol",
                label="GPT-5.6-Sol",
                description="Latest frontier agentic coding model.",
                context_window=272_000,
                reasoning_efforts=("low", "medium", "high", "xhigh", "max", "ultra"),
            ),
            ProviderModelSpec(
                id="openai-codex/gpt-5.6-terra",
                label="GPT-5.6-Terra",
                description="Balanced agentic coding model for everyday work.",
                context_window=272_000,
                reasoning_efforts=("low", "medium", "high", "xhigh", "max", "ultra"),
            ),
            ProviderModelSpec(
                id="openai-codex/gpt-5.6-luna",
                label="GPT-5.6-Luna",
                description="Fast and affordable agentic coding model.",
                context_window=272_000,
                reasoning_efforts=("low", "medium", "high", "xhigh", "max"),
            ),
            ProviderModelSpec(
                id="openai-codex/gpt-5.5",
                label="GPT-5.5",
                description="Frontier model for complex coding, research, and real-world work.",
                context_window=272_000,
                reasoning_efforts=("low", "medium", "high", "xhigh"),
            ),
            ProviderModelSpec(
                id="openai-codex/gpt-5.4",
                label="GPT-5.4",
                description="Strong model for everyday coding.",
                context_window=272_000,
                reasoning_efforts=("low", "medium", "high", "xhigh"),
            ),
            ProviderModelSpec(
                id="openai-codex/gpt-5.4-mini",
                label="GPT-5.4-Mini",
                description="Small, fast, and cost-efficient model for simpler coding tasks.",
                context_window=272_000,
                reasoning_efforts=("low", "medium", "high", "xhigh"),
            ),
            ProviderModelSpec(
                id="openai-codex/gpt-5.3-codex-spark",
                label="GPT-5.3-Codex-Spark",
                description="Ultra-fast coding model.",
                context_window=128_000,
                reasoning_efforts=("low", "medium", "high", "xhigh"),
            ),
        ),
        backend="openai_codex",
        detect_by_base_keyword="codex",
        default_api_base="https://chatgpt.com/backend-api",
        is_oauth=True,
    ),
    # xAI subscription: OAuth-based, with capability-gated server-hosted X Search.
    ProviderSpec(
        name="xai_grok",
        keywords=("xai-grok", "xai_grok"),
        env_key="",
        request_apis=("responses",),
        display_name="xAI Grok",
        model_catalog="hybrid",
        builtin_models=(
            ProviderModelSpec(
                id="xai-grok/grok-4.6",
                label="Grok 4.6",
                description="Grok via xAI subscription; X Search is enabled when supported.",
                context_window=500_000,
            ),
            ProviderModelSpec(
                id="xai-grok/grok-4.5",
                label="Grok 4.5",
                description="Grok via xAI subscription; X Search is enabled when supported.",
                context_window=500_000,
            ),
        ),
        backend="xai_grok",
        default_api_base="https://cli-chat-proxy.grok.com/v1",
        is_oauth=True,
    ),
    ProviderSpec(
        name="github_copilot",
        keywords=("github_copilot", "copilot"),
        env_key="",
        request_apis=("chat_completions", "responses"),
        display_name="Github Copilot",
        model_catalog="hybrid",
        builtin_models=(
            ProviderModelSpec(
                id="github-copilot/gpt-5.4-mini",
                label="GPT-5.4 Mini",
                description="GitHub Copilot Responses model.",
            ),
            ProviderModelSpec(
                id="github-copilot/gpt-4.1",
                label="GPT-4.1",
                description="GitHub Copilot chat model.",
            ),
        ),
        backend="github_copilot",
        default_api_base="https://api.githubcopilot.com",
        strip_model_prefix=True,
        is_oauth=True,
        supports_max_completion_tokens=True,
        responses=ResponsesCapabilities(
            model_prefixes=("gpt-5", "gpt-6", "o1", "o3", "o4"),
            route_reasoning=True,
            reasoning_replay="encrypted",
            allows_chat_fallback=False,
        ),
    ),
    ProviderSpec(
        name="deepseek",
        keywords=("deepseek",),
        env_key="DEEPSEEK_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="DeepSeek",
        backend="openai_compat",
        default_api_base="https://api.deepseek.com",
        thinking_style="thinking_type",
        builtin_models=(
            ProviderModelSpec(
                id="deepseek-flash",
                aliases=("deepseek-v4-flash", "deepseek-v4-flash-vision-exp"),
                context_window=1_000_000,
                max_output_tokens=393_216,
                input_modalities=("text", "image"),
                output_modalities=("text",),
                reasoning_efforts=_DEEPSEEK_REASONING_EFFORTS,
                default_reasoning_effort="high",
            ),
            ProviderModelSpec(
                id="deepseek-v4-pro",
                context_window=1_000_000,
                max_output_tokens=393_216,
                input_modalities=("text",),
                output_modalities=("text",),
                reasoning_efforts=_DEEPSEEK_REASONING_EFFORTS,
                default_reasoning_effort="high",
            ),
        ),
        responses=ResponsesCapabilities(
            models=(
                "deepseek-v4-flash",
                "deepseek-v4-pro",
                "deepseek-v4-flash-vision-exp",
            ),
            endpoint_models=(("https://api.deepseek.com", ("deepseek-flash",)),),
            reasoning_replay="plaintext",
            supports_hosted_web_search=False,
        ),
    ),
    ProviderSpec(
        name="gemini",
        keywords=("gemini", "gemma"),
        env_key="GEMINI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Gemini",
        backend="openai_compat",
        default_api_base="https://generativelanguage.googleapis.com/v1beta/openai/",
    ),
    ProviderSpec(
        name="zhipu",
        keywords=("zhipu", "glm", "zai"),
        env_key="ZAI_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Zhipu AI",
        backend="openai_compat",
        env_extras=(("ZHIPUAI_API_KEY", "{api_key}"),),
        default_api_base="https://open.bigmodel.cn/api/paas/v4",
    ),
    ProviderSpec(
        name="dashscope",
        keywords=("qwen", "dashscope"),
        env_key="DASHSCOPE_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="DashScope",
        backend="openai_compat",
        default_api_base="https://dashscope.aliyuncs.com/compatible-mode/v1",
        thinking_style="enable_thinking",
    ),
    ProviderSpec(
        name="modelscope",
        keywords=("modelscope",),
        env_key="MODELSCOPE_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="ModelScope",
        backend="openai_compat",
        is_gateway=True,
        detect_by_base_keyword="modelscope",
        default_api_base="https://api-inference.modelscope.cn/v1",
        strip_model_prefixes=("modelscope",),
        thinking_style="enable_thinking",
    ),
    # Moonshot (月之暗面): Kimi K2.5/K2.6 choose temperature from thinking mode;
    # the OpenAI-compatible provider omits it. K2.7 models require 1.0.
    ProviderSpec(
        name="moonshot",
        keywords=("moonshot", "kimi"),
        env_key="MOONSHOT_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Moonshot",
        backend="openai_compat",
        default_api_base="https://api.moonshot.ai/v1",
        model_overrides=(
            ("kimi-k2.7", {"temperature": 1.0}),
            ("kimi-k2.7-code", {"temperature": 1.0}),
            ("kimi-k2.7-code-highspeed", {"temperature": 1.0}),
        ),
    ),
    # Kimi Coding Plan — Anthropic Messages API at api.kimi.com/coding
    # sk-kimi-* keys; requires User-Agent: claude-code/0.1.0 header.
    ProviderSpec(
        name="kimi_coding",
        keywords=("kimi-coding", "kimi_coding", "kimi-for-coding"),
        env_key="KIMI_CODING_API_KEY",
        request_apis=("anthropic_messages",),
        display_name="Kimi Coding",
        backend="anthropic",
        default_api_base="https://api.kimi.com/coding/v1",
        default_extra_headers=(("User-Agent", "claude-code/0.1.0"),),
    ),
    ProviderSpec(
        name="minimax",
        keywords=("minimax",),
        env_key="MINIMAX_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="MiniMax",
        backend="openai_compat",
        default_api_base="https://api.minimax.io/v1",
        thinking_style="reasoning_split",
        builtin_models=(
            ProviderModelSpec(
                id="MiniMax-M3.1-Flash",
                label="MiniMax-M3.1-Flash",
                aliases=("minimax-m3.1-flash",),
                context_window=1_000_000,
                reasoning_efforts=("low", "medium", "high", "xhigh", "max"),
                default_reasoning_effort="max",
                input_modalities=("text", "image"),
            ),
        ),
        reasoning_effort_remap=(
            ("none", "low"), ("minimal", "low"),
            ("low", "low"), ("medium", "medium"), ("high", "high"),
        ),
    ),
    # MiniMax Anthropic-compatible endpoint: supports thinking mode
    ProviderSpec(
        name="minimax_anthropic",
        keywords=("minimax_anthropic",),
        env_key="MINIMAX_API_KEY",
        request_apis=("anthropic_messages",),
        display_name="MiniMax (Anthropic)",
        backend="anthropic",
        default_api_base="https://api.minimax.io/anthropic",
    ),
    # Reasoning quirks:
    #   * mistral-medium-3-5 / mistral-vibe-cli-* accept reasoning_effort but
    #     only "high" or "none" — low/medium/minimal must be remapped.
    #   * Magistral-* models reason implicitly and reject the kwarg entirely.
    #   * Reasoning responses return content as a list of thinking + text
    #     blocks; thinking text gets extracted into reasoning_content.
    ProviderSpec(
        name="mistral",
        keywords=("mistral", "magistral", "ministral", "codestral", "devstral"),
        env_key="MISTRAL_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Mistral",
        backend="openai_compat",
        default_api_base="https://api.mistral.ai/v1",
        reasoning_effort_remap=(
            ("minimal", "none"),
            ("low", "none"),
            ("medium", "high"),
            ("high", "high"),
            ("none", "none"),
        ),
        implicit_reasoning_models=("magistral",),
        extract_thinking_blocks=True,
        strip_history_reasoning_content=True,
    ),
    ProviderSpec(
        name="stepfun",
        keywords=("stepfun", "step"),
        env_key="STEPFUN_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Step Fun",
        backend="openai_compat",
        default_api_base="https://api.stepfun.com/v1",
        reasoning_as_content=True,
    ),
    # Hosted API (api.xiaomimimo.com) accepts {"thinking": {"type": "enabled"|"disabled"}}
    # to toggle reasoning, matching the existing thinking_type style.
    ProviderSpec(
        name="xiaomi_mimo",
        keywords=("xiaomi_mimo", "mimo"),
        env_key="XIAOMIMIMO_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Xiaomi MIMO",
        backend="openai_compat",
        default_api_base="https://api.xiaomimimo.com/v1",
        thinking_style="thinking_type",
    ),
    ProviderSpec(
        name="longcat",
        keywords=("longcat",),
        env_key="LONGCAT_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="LongCat",
        backend="openai_compat",
        default_api_base="https://api.longcat.chat/openai/v1",
    ),
    ProviderSpec(
        name="ant_ling",
        keywords=("ant_ling", "ant-ling", "ling-", "ring-"),
        env_key="ANT_LING_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Ant Ling",
        backend="openai_compat",
        detect_by_base_keyword="ant-ling.com",
        default_api_base="https://api.ant-ling.com/v1",
    ),
    ProviderSpec(
        name="vllm",
        keywords=("vllm",),
        env_key="HOSTED_VLLM_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="vLLM",
        backend="openai_compat",
        is_local=True,
    ),
    ProviderSpec(
        name="ollama",
        keywords=("ollama", "nemotron"),
        env_key="OLLAMA_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Ollama",
        backend="openai_compat",
        is_local=True,
        detect_by_base_keyword="11434",
        default_api_base="http://localhost:11434/v1",
    ),
    ProviderSpec(
        name="lm_studio",
        keywords=("lm-studio", "lmstudio", "lm_studio"),
        env_key="LM_STUDIO_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="LM Studio",
        backend="openai_compat",
        is_local=True,
        detect_by_base_keyword="1234",
        default_api_base="http://localhost:1234/v1",
    ),
    ProviderSpec(
        name="atomic_chat",
        keywords=("atomic-chat", "atomic_chat", "atomicchat"),
        env_key="ATOMIC_CHAT_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Atomic Chat",
        backend="openai_compat",
        is_local=True,
        detect_by_base_keyword="1337",
        default_api_base="http://localhost:1337/v1",
    ),
    ProviderSpec(
        name="ovms",
        keywords=("openvino", "ovms"),
        env_key="",
        request_apis=("chat_completions", "responses"),
        display_name="OpenVINO Model Server",
        backend="openai_compat",
        is_direct=True,
        is_local=True,
        default_api_base="http://localhost:8000/v3",
    ),
    # Keys start with "nvapi-", base URL at integrate.api.nvidia.com
    ProviderSpec(
        name="nvidia",
        keywords=("nvidia", "nemotron", "nvapi"),
        env_key="NVIDIA_NIM_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="NVIDIA NIM",
        backend="openai_compat",
        is_gateway=False,
        detect_by_key_prefix="nvapi-",
        detect_by_base_keyword="nvidia.com",
        default_api_base="https://integrate.api.nvidia.com/v1",
    ),
    ProviderSpec(
        name="groq",
        keywords=("groq",),
        env_key="GROQ_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Groq",
        backend="openai_compat",
        default_api_base="https://api.groq.com/openai/v1",
    ),
    # AssemblyAI: voice transcription only. It appears in provider settings so
    # users can manage credentials, but WebUI excludes it from chat model pickers.
    ProviderSpec(
        name="assemblyai",
        keywords=("assemblyai",),
        env_key="ASSEMBLYAI_API_KEY",
        request_apis=("transcription",),
        display_name="AssemblyAI",
        backend="openai_compat",
        default_api_base="https://api.assemblyai.com/v2",
        is_transcription_only=True,
    ),
    ProviderSpec(
        name="qianfan",
        keywords=("qianfan", "ernie"),
        env_key="QIANFAN_API_KEY",
        request_apis=("chat_completions", "responses"),
        display_name="Qianfan",
        backend="openai_compat",
        default_api_base="https://qianfan.baidubce.com/v2"
    ),
)


def find_by_name(name: str) -> ProviderSpec | None:
    """Find a provider spec by config field name, e.g. "dashscope"."""
    normalized = to_snake(name.replace("-", "_"))
    for spec in PROVIDERS:
        if spec.name == normalized:
            return spec
    return None


def create_dynamic_spec(
    name: str,
    *,
    display_name: str = "",
    thinking_style: str = "",
) -> ProviderSpec:
    """Create a dynamic ProviderSpec for custom user-defined providers."""
    normalized = to_snake(name.replace("-", "_"))
    strip_prefixes = tuple(dict.fromkeys((name, normalized)))
    return ProviderSpec(
        name=normalized,
        keywords=(),
        env_key="",
        request_apis=("chat_completions", "responses", "anthropic_messages"),
        display_name=display_name or name.replace("-", " ").replace("_", " ").title(),
        backend="openai_compat",
        is_direct=True,
        strip_model_prefixes=strip_prefixes,
        thinking_style=thinking_style,
    )
