# How to Configure Web Search for a nanobot AI Agent

nanobot includes built-in web search and web fetch tools. Search uses DuckDuckGo by default and can be configured for API-backed or self-hosted providers.

## What you will build

- web tools enabled in nanobot
- one search provider selected in the WebUI or `config.json`
- optional web fetch settings for page reading

## When to use this

Configure web search when the agent needs current information, public web research, source discovery, or page fetching during a task.

## Before you start

Complete [Quick Start](../quick-start.md) if nanobot is not installed or cannot reply yet. If you already have a working WebUI or CLI session, continue here using that instance; no reinstall or second gateway is needed.

Web tools are enabled by default. Configure them only when you want a specific provider, API key, proxy, fetch behavior, or SSRF allowlist.

## Minimal working example

For local interactive setup:

1. Run `nanobot webui`.
2. Open **Settings → Capabilities → Web access**.
3. Enable web search, choose a provider, and enter its API key if required.
4. Save and restart when prompted.
5. Ask a question that requires current information and inspect the cited sources.

<details>
<summary>Manual configuration</summary>

For manual or deployment-managed config, use the default search provider:

```json
{
  "tools": {
    "web": {
      "enable": true,
      "search": {
        "provider": "duckduckgo"
      }
    }
  }
}
```

Or use an API-backed provider:

```json
{
  "tools": {
    "web": {
      "search": {
        "provider": "brave",
        "apiKey": "${BRAVE_API_KEY}"
      }
    }
  }
}
```

Ask a question that requires current information and inspect the tool activity in the WebUI or logs.

</details>

## Production notes

- Keep API keys in environment variables.
- Set `maxResults` when you need fewer or more search results per query.
- Set `tools.web.proxy` only to a proxy you trust.
- Use `fetch.useJinaReader: false` if you need local page conversion.

## Security notes

- Web fetch and HTTP MCP share an address check that prevents requests to private or internal network locations. Private, loopback, link-local, and cloud metadata addresses are blocked by default.
- With `useJinaReader` enabled (the default), fetched URLs are disclosed to the remote reader service. Credential-bearing URLs (userinfo or token/signature query parameters) are fetched locally instead; path-embedded secrets cannot be detected, so disable the remote reader when URLs must stay local.
- Add `tools.ssrfWhitelist` only for narrow trusted CIDRs. This setting exempts those address ranges from the private-address block; use the smallest range needed.
- Do not give public chat users unrestricted web and shell access without review.

## Troubleshooting

- If search returns no results, switch provider or check the provider API key.
- If fetch is blocked, inspect the target URL and SSRF whitelist.
- If a proxy changes network behavior, verify `NO_PROXY` and proxy settings.

## Related nanobot docs

- [Configuration: Web Tools](../configuration.md#web-tools)
- [Security](../configuration.md#security)
- [WebUI](../webui.md)
